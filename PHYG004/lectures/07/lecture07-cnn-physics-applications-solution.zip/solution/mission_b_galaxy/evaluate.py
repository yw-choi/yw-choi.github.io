"""
Evaluate the trained Galaxy CNN model.

Generates:
  - Confusion matrix
  - Sample predictions with images
  - Per-class metrics
"""

import numpy as np
import torch
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, classification_report
from train_cnn import GalaxyCNN
from torch.utils.data import DataLoader, TensorDataset, random_split

SEED = 42
device = torch.device("cpu")
CLASS_NAMES = ["Elliptical", "Spiral"]

# Load data (same split as training)
data = np.load("galaxy_subset.npz")
images = data["images"]
labels = data["labels"]

X = torch.tensor(images, dtype=torch.float32).permute(0, 3, 1, 2) / 255.0
y = torch.tensor(labels, dtype=torch.long)

n_total = len(X)
n_train = int(0.7 * n_total)
n_val = int(0.15 * n_total)
n_test = n_total - n_train - n_val

dataset = TensorDataset(X, y)
_, _, test_set = random_split(
    dataset, [n_train, n_val, n_test],
    generator=torch.Generator().manual_seed(SEED)
)
test_loader = DataLoader(test_set, batch_size=64)

# Load model
model = GalaxyCNN()
model.load_state_dict(torch.load("galaxy_cnn_model.pt", map_location=device, weights_only=True))
model.eval()

# Collect predictions
all_preds = []
all_labels = []
all_probs = []

with torch.no_grad():
    for X_batch, y_batch in test_loader:
        outputs = model(X_batch)
        probs = torch.softmax(outputs, dim=1)
        _, predicted = outputs.max(1)
        all_preds.extend(predicted.numpy())
        all_labels.extend(y_batch.numpy())
        all_probs.extend(probs.numpy())

all_preds = np.array(all_preds)
all_labels = np.array(all_labels)
all_probs = np.array(all_probs)

# Classification report
print("Classification Report:")
print(classification_report(all_labels, all_preds, target_names=CLASS_NAMES))

# Confusion matrix
cm = confusion_matrix(all_labels, all_preds)
fig, ax = plt.subplots(figsize=(6, 5))
im = ax.imshow(cm, cmap="Blues")
ax.set_xticks([0, 1])
ax.set_yticks([0, 1])
ax.set_xticklabels(CLASS_NAMES, fontsize=12)
ax.set_yticklabels(CLASS_NAMES, fontsize=12)
ax.set_xlabel("Predicted", fontsize=13)
ax.set_ylabel("True", fontsize=13)
ax.set_title("Confusion Matrix", fontsize=14)
for i in range(2):
    for j in range(2):
        color = "white" if cm[i, j] > cm.max() / 2 else "black"
        ax.text(j, i, str(cm[i, j]), ha="center", va="center", fontsize=16, color=color)
fig.colorbar(im)
plt.tight_layout()
plt.savefig("results/confusion_matrix.png", dpi=150)
plt.close()
print("Saved results/confusion_matrix.png")

# Sample predictions
test_indices = test_set.indices
test_images_np = images[test_indices]

correct_mask = all_preds == all_labels
wrong_mask = ~correct_mask

correct_idx = np.where(correct_mask)[0]
wrong_idx = np.where(wrong_mask)[0]

# Sort wrong predictions by confidence (most confident mistakes first)
wrong_conf = np.array([all_probs[i].max() for i in wrong_idx])
wrong_idx = wrong_idx[np.argsort(-wrong_conf)]

n_correct_show = 6
n_wrong_show = min(6, len(wrong_idx))
n_cols = max(n_correct_show, n_wrong_show)

fig, axes = plt.subplots(2, n_cols, figsize=(3 * n_cols, 7))

# Top row: correct predictions
axes[0, 0].set_ylabel("Correct", fontsize=14, fontweight="bold", color="green",
                       rotation=0, labelpad=60, va="center")
for i in range(n_cols):
    if i < n_correct_show:
        idx = correct_idx[i]
        axes[0, i].imshow(test_images_np[idx])
        pred_name = CLASS_NAMES[all_preds[idx]]
        true_name = CLASS_NAMES[all_labels[idx]]
        conf = all_probs[idx].max() * 100
        axes[0, i].set_title(f"{pred_name} ({conf:.0f}%)", fontsize=11, color="green", fontweight="bold")
    axes[0, i].set_xticks([])
    axes[0, i].set_yticks([])

# Bottom row: wrong predictions
axes[1, 0].set_ylabel("Wrong", fontsize=14, fontweight="bold", color="red",
                       rotation=0, labelpad=60, va="center")
for i in range(n_cols):
    if i < n_wrong_show:
        idx = wrong_idx[i]
        axes[1, i].imshow(test_images_np[idx])
        pred_name = CLASS_NAMES[all_preds[idx]]
        true_name = CLASS_NAMES[all_labels[idx]]
        conf = all_probs[idx].max() * 100
        axes[1, i].set_title(f"Pred: {pred_name} ({conf:.0f}%)\nTrue: {true_name}",
                              fontsize=10, color="red", fontweight="bold")
    else:
        axes[1, i].axis("off")
    axes[1, i].set_xticks([])
    axes[1, i].set_yticks([])

fig.suptitle("Galaxy Classification: Sample Predictions", fontsize=15, y=1.0)
plt.tight_layout()
plt.savefig("results/sample_predictions.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved results/sample_predictions.png")

accuracy = np.mean(all_preds == all_labels)
print(f"\nOverall test accuracy: {accuracy:.4f}")
print(f"Total test samples: {len(all_labels)}")
print(f"Correct: {np.sum(correct_mask)}, Wrong: {np.sum(wrong_mask)}")
