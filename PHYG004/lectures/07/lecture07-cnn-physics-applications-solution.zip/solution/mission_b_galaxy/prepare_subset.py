"""
Prepare Galaxy10 DECals binary subset for classroom use.

Downloads the Galaxy10 DECals dataset (HDF5) and extracts a binary subset:
  - Class 0: Disturbed → skip
  - Class 1: Merging → skip
  - Class 2: Round Smooth → "Elliptical" (label 0)
  - Class 3: In-between Round Smooth → skip
  - Class 4: Cigar Shaped Smooth → skip
  - Class 5: Barred Spiral → "Spiral" (label 1)
  - Class 6: Unbarred Tight Spiral → "Spiral" (label 1)
  - Class 7: Unbarred Loose Spiral → "Spiral" (label 1)
  - Class 8: Edge-on without Bulge → skip
  - Class 9: Edge-on with Bulge → skip

We combine spiral classes (5,6,7) vs round smooth (2) for a clean binary task.
Images are resized to 64x64 for fast training on laptops.

This script is meant for the instructor to prepare data for Google Drive upload.

Dataset source: https://astronn.readthedocs.io/en/latest/galaxy10.html
Direct download: https://zenodo.org/records/13865031/files/Galaxy10_DECals.h5
"""

import numpy as np
import h5py
import os
import matplotlib.pyplot as plt
from urllib.request import urlretrieve
from PIL import Image
from tqdm import tqdm

# Galaxy10 DECals download
DATA_URL = "https://zenodo.org/records/10845026/files/Galaxy10_DECals.h5"
DATA_FILE = "Galaxy10_DECals.h5"
OUTPUT_FILE = "galaxy_subset.npz"

N_PER_CLASS = 2500  # 2500 spiral + 2500 elliptical = 5000 total
TARGET_SIZE = 64

SPIRAL_CLASSES = [5, 6, 7]  # Barred spiral, unbarred tight, unbarred loose
ELLIPTICAL_CLASSES = [2]     # Round smooth


def download_galaxy10():
    """Download Galaxy10 DECals if not present."""
    if os.path.exists(DATA_FILE):
        print(f"{DATA_FILE} already exists, skipping download.")
        return

    print(f"Downloading Galaxy10 DECals (~1.8 GB)...")
    print(f"URL: {DATA_URL}")

    def progress(count, block_size, total_size):
        pct = count * block_size * 100 / total_size
        print(f"\r  {pct:.1f}%", end="", flush=True)

    urlretrieve(DATA_URL, DATA_FILE, reporthook=progress)
    print("\n  Download complete.")


def resize_images(images, target_size):
    """Resize a batch of images to target_size x target_size."""
    resized = np.zeros((len(images), target_size, target_size, 3), dtype=np.uint8)
    for i, img in enumerate(tqdm(images, desc="Resizing")):
        pil_img = Image.fromarray(img)
        pil_img = pil_img.resize((target_size, target_size), Image.LANCZOS)
        resized[i] = np.array(pil_img)
    return resized


def main():
    download_galaxy10()

    print(f"\nLoading {DATA_FILE}...")
    with h5py.File(DATA_FILE, "r") as f:
        images = f["images"][:]   # (N, 256, 256, 3) uint8
        labels = f["ans"][:]      # (N,) int

    print(f"  Total images: {len(images)}")
    print(f"  Image shape: {images.shape[1:]}")
    print(f"  Classes: {np.unique(labels)}")

    # Count per class
    for c in range(10):
        print(f"    Class {c}: {np.sum(labels == c)}")

    # Extract spiral and elliptical
    spiral_mask = np.isin(labels, SPIRAL_CLASSES)
    elliptical_mask = np.isin(labels, ELLIPTICAL_CLASSES)

    spiral_images = images[spiral_mask]
    elliptical_images = images[elliptical_mask]

    print(f"\nAvailable: {len(spiral_images)} spiral, {len(elliptical_images)} elliptical")

    # Random subsample
    rng = np.random.default_rng(42)
    spiral_idx = rng.choice(len(spiral_images), N_PER_CLASS, replace=False)
    elliptical_idx = rng.choice(len(elliptical_images), N_PER_CLASS, replace=False)

    spiral_subset = spiral_images[spiral_idx]
    elliptical_subset = elliptical_images[elliptical_idx]

    # Resize
    print(f"\nResizing to {TARGET_SIZE}x{TARGET_SIZE}...")
    spiral_resized = resize_images(spiral_subset, TARGET_SIZE)
    elliptical_resized = resize_images(elliptical_subset, TARGET_SIZE)

    # Combine
    all_images = np.concatenate([elliptical_resized, spiral_resized], axis=0)
    all_labels = np.concatenate([
        np.zeros(N_PER_CLASS, dtype=np.int64),   # 0 = elliptical
        np.ones(N_PER_CLASS, dtype=np.int64),     # 1 = spiral
    ])

    # Shuffle
    perm = rng.permutation(len(all_images))
    all_images = all_images[perm]
    all_labels = all_labels[perm]

    # Save
    np.savez_compressed(
        OUTPUT_FILE,
        images=all_images,
        labels=all_labels,
    )
    file_size = os.path.getsize(OUTPUT_FILE) / (1024 * 1024)
    print(f"\nSaved {OUTPUT_FILE}")
    print(f"  Images shape: {all_images.shape}")
    print(f"  Labels: {np.sum(all_labels == 0)} elliptical, {np.sum(all_labels == 1)} spiral")
    print(f"  File size: {file_size:.1f} MB")

    # Visualize samples
    fig, axes = plt.subplots(2, 8, figsize=(16, 4))
    fig.suptitle("Galaxy Subset Samples", fontsize=14)

    # Top row: elliptical
    ell_idx = np.where(all_labels == 0)[0][:8]
    for i, idx in enumerate(ell_idx):
        axes[0, i].imshow(all_images[idx])
        axes[0, i].set_title("Elliptical", fontsize=9)
        axes[0, i].axis("off")

    # Bottom row: spiral
    spi_idx = np.where(all_labels == 1)[0][:8]
    for i, idx in enumerate(spi_idx):
        axes[1, i].imshow(all_images[idx])
        axes[1, i].set_title("Spiral", fontsize=9)
        axes[1, i].axis("off")

    plt.tight_layout()
    plt.savefig("results/galaxy_samples.png", dpi=150)
    plt.close()
    print("Saved results/galaxy_samples.png")
    print(f"\nUpload {OUTPUT_FILE} to Google Drive for student access.")


if __name__ == "__main__":
    main()
