"""
Train a CNN to classify galaxy morphology (spiral vs elliptical).

Inspired by: Dieleman, Willett & Dambre, MNRAS 450, 1441 (2015)
Dataset: Galaxy10 DECals subset (5000 images, 64x64 RGB)

Key physics insight: Galaxies have rotational symmetry, so data
augmentation with random rotations is physically motivated.
"""

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset, random_split
import torchvision.transforms.v2 as T
import matplotlib.pyplot as plt

# Hyperparameters
BATCH_SIZE = 128
LEARNING_RATE = 3e-4
N_EPOCHS = 20
SEED = 42


class GalaxyCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.features = nn.Sequential(
            # (3, 64, 64) -> (32, 62, 62) -> (32, 31, 31)
            nn.Conv2d(3, 32, kernel_size=3),
            nn.ReLU(),
            nn.MaxPool2d(2),
            # (32, 31, 31) -> (64, 29, 29) -> (64, 14, 14)
            nn.Conv2d(32, 64, kernel_size=3),
            nn.ReLU(),
            nn.MaxPool2d(2),
            # (64, 14, 14) -> (128, 12, 12) -> (128, 6, 6)
            nn.Conv2d(64, 128, kernel_size=3),
            nn.ReLU(),
            nn.MaxPool2d(2),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(128 * 6 * 6, 128),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(128, 2),
        )

    def forward(self, x):
        x = self.features(x)
        x = self.classifier(x)
        return x


def main():
    torch.manual_seed(SEED)
    np.random.seed(SEED)
    device = torch.device("cpu")

    # Load data
    print("Loading galaxy data...")
    data = np.load("galaxy_subset.npz")
    images = data["images"]   # (5000, 64, 64, 3) uint8
    labels = data["labels"]   # (5000,)

    # Normalize to [0, 1] and convert to (N, C, H, W)
    X = torch.tensor(images, dtype=torch.float32).permute(0, 3, 1, 2) / 255.0
    y = torch.tensor(labels, dtype=torch.long)

    print(f"  Images: {X.shape}")
    print(f"  Elliptical: {(y == 0).sum().item()}, Spiral: {(y == 1).sum().item()}")

    # Split: 70% train, 15% val, 15% test
    n_total = len(X)
    n_train = int(0.7 * n_total)
    n_val = int(0.15 * n_total)
    n_test = n_total - n_train - n_val

    dataset = TensorDataset(X, y)
    train_set, val_set, test_set = random_split(
        dataset, [n_train, n_val, n_test],
        generator=torch.Generator().manual_seed(SEED)
    )

    train_loader = DataLoader(train_set, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_set, batch_size=BATCH_SIZE)
    test_loader = DataLoader(test_set, batch_size=BATCH_SIZE)

    print(f"  Train: {n_train}, Val: {n_val}, Test: {n_test}")

    # Data augmentation (applied during training)
    # Light augmentation — galaxies have rotational symmetry
    augment = T.RandomHorizontalFlip()

    model = GalaxyCNN().to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE, weight_decay=1e-4)

    print(f"\nModel: {sum(p.numel() for p in model.parameters()):,} parameters")
    print(f"Training for {N_EPOCHS} epochs...\n")

    # Training loop
    train_losses = []
    val_losses = []
    train_accs = []
    val_accs = []

    for epoch in range(N_EPOCHS):
        model.train()
        epoch_loss = 0.0
        correct = 0
        total = 0

        for X_batch, y_batch in train_loader:
            X_batch = augment(X_batch)
            X_batch, y_batch = X_batch.to(device), y_batch.to(device)

            optimizer.zero_grad()
            outputs = model(X_batch)
            loss = criterion(outputs, y_batch)
            loss.backward()
            optimizer.step()

            epoch_loss += loss.item() * X_batch.size(0)
            _, predicted = outputs.max(1)
            correct += predicted.eq(y_batch).sum().item()
            total += y_batch.size(0)

        train_loss = epoch_loss / total
        train_acc = correct / total
        train_losses.append(train_loss)
        train_accs.append(train_acc)

        # Validation
        model.eval()
        val_loss = 0.0
        correct = 0
        total = 0
        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch, y_batch = X_batch.to(device), y_batch.to(device)
                outputs = model(X_batch)
                loss = criterion(outputs, y_batch)
                val_loss += loss.item() * X_batch.size(0)
                _, predicted = outputs.max(1)
                correct += predicted.eq(y_batch).sum().item()
                total += y_batch.size(0)

        val_loss = val_loss / total
        val_acc = correct / total
        val_losses.append(val_loss)
        val_accs.append(val_acc)

        if (epoch + 1) % 5 == 0 or epoch == 0:
            print(f"Epoch {epoch+1:2d}/{N_EPOCHS}: train_loss={train_loss:.4f}, "
                  f"train_acc={train_acc:.3f}, val_acc={val_acc:.3f}")

    # Test evaluation
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for X_batch, y_batch in test_loader:
            X_batch, y_batch = X_batch.to(device), y_batch.to(device)
            outputs = model(X_batch)
            _, predicted = outputs.max(1)
            correct += predicted.eq(y_batch).sum().item()
            total += y_batch.size(0)

    test_acc = correct / total
    print(f"\nTest accuracy: {test_acc:.4f}")

    # Save model
    torch.save(model.state_dict(), "galaxy_cnn_model.pt")
    print("Saved galaxy_cnn_model.pt")

    # Plot training curves
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))

    ax1.plot(range(1, N_EPOCHS + 1), train_losses, "b-", label="Train")
    ax1.plot(range(1, N_EPOCHS + 1), val_losses, "r-", label="Validation")
    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("Loss")
    ax1.set_title("Galaxy CNN Training Loss")
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    ax2.plot(range(1, N_EPOCHS + 1), train_accs, "b-", label="Train")
    ax2.plot(range(1, N_EPOCHS + 1), val_accs, "r-", label="Validation")
    ax2.set_xlabel("Epoch")
    ax2.set_ylabel("Accuracy")
    ax2.set_title("Galaxy CNN Accuracy")
    ax2.legend()
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig("results/galaxy_training.png", dpi=150)
    plt.close()
    print("Saved results/galaxy_training.png")


if __name__ == "__main__":
    main()
