"""
Download the prepared Galaxy morphology subset from Google Drive.

This script downloads a pre-processed subset of the Galaxy10 DECals dataset:
  - 5000 images (2500 elliptical + 2500 spiral)
  - 64x64 RGB
  - Saved as galaxy_subset.npz

Students: Run this script first before training.
"""

import os
import numpy as np

# ============================================================
# TODO (Instructor): Replace with actual Google Drive file ID
# after uploading galaxy_subset.npz to Google Drive.
#
# To get the file ID:
# 1. Upload galaxy_subset.npz to Google Drive
# 2. Right-click → Share → Anyone with the link
# 3. Copy the link: https://drive.google.com/file/d/FILE_ID/view
# 4. Paste the FILE_ID below
# ============================================================
GDRIVE_FILE_ID = "1c_WZle0IJiGzojZXDFMWMA_ffsMP4OYS"
OUTPUT_FILE = "galaxy_subset.npz"


def download_from_gdrive(file_id, output_path):
    """Download a file from Google Drive using gdown."""
    import gdown
    url = f"https://drive.google.com/uc?id={file_id}"
    print(f"Downloading from Google Drive...")
    gdown.download(url, output_path, quiet=False)
    print(f"Saved to {output_path}")


def main():
    if os.path.exists(OUTPUT_FILE):
        print(f"{OUTPUT_FILE} already exists.")
    else:
        if GDRIVE_FILE_ID == "YOUR_FILE_ID_HERE":
            print("ERROR: Google Drive file ID not set!")
            print("Please update GDRIVE_FILE_ID in this script.")
            print("Or download galaxy_subset.npz manually and place it here.")
            return
        download_from_gdrive(GDRIVE_FILE_ID, OUTPUT_FILE)

    # Verify
    data = np.load(OUTPUT_FILE)
    images = data["images"]
    labels = data["labels"]

    print(f"\nDataset summary:")
    print(f"  Images shape: {images.shape}")
    print(f"  Labels shape: {labels.shape}")
    print(f"  Elliptical (0): {np.sum(labels == 0)}")
    print(f"  Spiral (1): {np.sum(labels == 1)}")
    print(f"  Image dtype: {images.dtype}")
    print(f"  Pixel range: [{images.min()}, {images.max()}]")


if __name__ == "__main__":
    main()
