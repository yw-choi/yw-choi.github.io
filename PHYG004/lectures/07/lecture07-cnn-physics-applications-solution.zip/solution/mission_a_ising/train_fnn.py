"""
Train a Fully Connected Neural Network (FNN) to classify 2D Ising model
configurations as ordered vs disordered phases.

Reference: Carrasquilla & Melko, Nature Physics 13, 431 (2017)

Input:  Flattened spin configuration (L*L = 1600 features)
Output: Binary classification (0=disordered, 1=ordered)
"""

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt

# Hyperparameters
BATCH_SIZE = 128
LEARNING_RATE = 3e-4
N_EPOCHS = 15
SEED = 42


class IsingFNN(nn.Module):
    def __init__(self, input_dim=1600):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 2),
        )

    def forward(self, x):
        return self.net(x)


def main():
    torch.manual_seed(SEED)
    np.random.seed(SEED)
    device = torch.device("cpu")

    # Load data
    print("Loading data...")
    data = np.load("ising_data.npz")
    configs = data["configs"].astype(np.float32)  # (N, 40, 40)
    labels = data["labels"]                        # (N,)

    N, L, _ = configs.shape
    X = configs.reshape(N, -1)  # Flatten to (N, 1600)
    y = labels

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=SEED, stratify=y
    )

    train_dataset = TensorDataset(torch.tensor(X_train), torch.tensor(y_train))
    test_dataset = TensorDataset(torch.tensor(X_test), torch.tensor(y_test))
    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE)

    print(f"Train: {len(X_train)}, Test: {len(X_test)}")

    model = IsingFNN().to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

    print(f"\nModel: {sum(p.numel() for p in model.parameters())} parameters")
    print(f"Training for {N_EPOCHS} epochs...\n")

    # Training loop
    train_losses = []
    train_accs = []
    test_accs = []

    for epoch in range(N_EPOCHS):
        model.train()
        epoch_loss = 0.0
        correct = 0
        total = 0

        for X_batch, y_batch in train_loader:
            X_batch, y_batch = X_batch.to(device), y_batch.to(device)

            optimizer.zero_grad()
            outputs = model(X_batch)
            loss = criterion(outputs, y_batch)
            loss.backward()
            optimizer.step()

            epoch_loss += loss.item() * X_batch.size(0)
            _, predicted = outputs.max(1)
            correct += predicted.eq(y_batch).sum().item()
            total += y_batch.size(0)

        train_loss = epoch_loss / total
        train_acc = correct / total
        train_losses.append(train_loss)
        train_accs.append(train_acc)

        # Evaluate on test set
        model.eval()
        correct = 0
        total = 0
        with torch.no_grad():
            for X_batch, y_batch in test_loader:
                X_batch, y_batch = X_batch.to(device), y_batch.to(device)
                outputs = model(X_batch)
                _, predicted = outputs.max(1)
                correct += predicted.eq(y_batch).sum().item()
                total += y_batch.size(0)

        test_acc = correct / total
        test_accs.append(test_acc)

        if (epoch + 1) % 5 == 0 or epoch == 0:
            print(f"Epoch {epoch+1:2d}/{N_EPOCHS}: loss={train_loss:.4f}, "
                  f"train_acc={train_acc:.3f}, test_acc={test_acc:.3f}")

    # Save model
    torch.save(model.state_dict(), "fnn_model.pt")
    print(f"\nFinal test accuracy: {test_accs[-1]:.4f}")
    print("Saved fnn_model.pt")

    # Plot training curves
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))

    ax1.plot(range(1, N_EPOCHS + 1), train_losses, "b-")
    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("Training Loss")
    ax1.set_title("FNN Training Loss")
    ax1.grid(True, alpha=0.3)

    ax2.plot(range(1, N_EPOCHS + 1), train_accs, "b-", label="Train")
    ax2.plot(range(1, N_EPOCHS + 1), test_accs, "r-", label="Test")
    ax2.set_xlabel("Epoch")
    ax2.set_ylabel("Accuracy")
    ax2.set_title("FNN Accuracy")
    ax2.legend()
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig("results/fnn_training.png", dpi=150)
    plt.close()
    print("Saved results/fnn_training.png")


if __name__ == "__main__":
    main()
