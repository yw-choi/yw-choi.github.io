"""
Analyze trained FNN and CNN models on the 2D Ising phase classification task.

Evaluates P(ordered) as a function of temperature and estimates the
critical temperature Tc from the neural network output.
Compares with exact Onsager result: Tc = 2/ln(1+sqrt(2)) ≈ 2.269.
"""

import numpy as np
import torch
import matplotlib.pyplot as plt
from train_fnn import IsingFNN
from train_cnn import IsingCNN

TC_EXACT = 2.0 / np.log(1 + np.sqrt(2))
device = torch.device("cpu")

# Load data
print("Loading data...")
data = np.load("ising_data.npz")
configs = data["configs"].astype(np.float32)
temperatures = data["temperatures"]
unique_temps = np.unique(temperatures)

# Plot sample configurations at representative temperatures
sample_temps = [1.0, 1.5, 2.0, 2.27, 2.5, 3.5]
fig, axes = plt.subplots(2, 3, figsize=(10, 7))
for ax, T_target in zip(axes.flat, sample_temps):
    idx = np.argmin(np.abs(unique_temps - T_target))
    T_actual = unique_temps[idx]
    mask = temperatures == T_actual
    cfg = configs[mask][0]  # First sample at this temperature
    ax.imshow(cfg, cmap="coolwarm", vmin=-1, vmax=1, interpolation="nearest")
    phase = "ordered" if T_actual < TC_EXACT else "disordered"
    ax.set_title(f"$T$ = {T_actual:.2f} ({phase})", fontsize=11)
    ax.set_xticks([])
    ax.set_yticks([])
fig.suptitle("Sample Ising Configurations at Different Temperatures", fontsize=14, y=0.98)
plt.tight_layout()
plt.savefig("results/sample_configs.png", dpi=150)
plt.close()
print("Saved results/sample_configs.png")

# Load models
fnn_model = IsingFNN()
fnn_model.load_state_dict(torch.load("fnn_model.pt", map_location=device, weights_only=True))
fnn_model.eval()

cnn_model = IsingCNN()
cnn_model.load_state_dict(torch.load("cnn_model.pt", map_location=device, weights_only=True))
cnn_model.eval()


def get_p_ordered(model, configs_at_T, use_cnn=False):
    """Compute average P(ordered) for configurations at a given temperature."""
    with torch.no_grad():
        if use_cnn:
            x = torch.tensor(configs_at_T[:, np.newaxis, :, :])
        else:
            N = configs_at_T.shape[0]
            x = torch.tensor(configs_at_T.reshape(N, -1))

        logits = model(x)
        probs = torch.softmax(logits, dim=1)
        # P(ordered) = probability of class 1
        p_ordered = probs[:, 1].mean().item()
    return p_ordered


# Evaluate at each temperature
fnn_p_ordered = []
cnn_p_ordered = []

print("Evaluating models at each temperature...")
for T in unique_temps:
    mask = temperatures == T
    cfgs = configs[mask]
    fnn_p_ordered.append(get_p_ordered(fnn_model, cfgs, use_cnn=False))
    cnn_p_ordered.append(get_p_ordered(cnn_model, cfgs, use_cnn=True))

fnn_p_ordered = np.array(fnn_p_ordered)
cnn_p_ordered = np.array(cnn_p_ordered)


def estimate_tc(temps, p_ordered):
    """Estimate Tc as the temperature where P(ordered) crosses 0.5."""
    for i in range(len(temps) - 1):
        if p_ordered[i] >= 0.5 and p_ordered[i + 1] < 0.5:
            # Linear interpolation
            t1, t2 = temps[i], temps[i + 1]
            p1, p2 = p_ordered[i], p_ordered[i + 1]
            tc = t1 + (0.5 - p1) * (t2 - t1) / (p2 - p1)
            return tc
    return np.nan


tc_fnn = estimate_tc(unique_temps, fnn_p_ordered)
tc_cnn = estimate_tc(unique_temps, cnn_p_ordered)

print(f"\nCritical Temperature Estimates:")
print(f"  Exact (Onsager):  Tc = {TC_EXACT:.4f}")
print(f"  FNN estimate:     Tc = {tc_fnn:.4f}  (error = {abs(tc_fnn - TC_EXACT):.4f})")
print(f"  CNN estimate:     Tc = {tc_cnn:.4f}  (error = {abs(tc_cnn - TC_EXACT):.4f})")

# Plot P(ordered) vs T for both models
fig, ax = plt.subplots(figsize=(8, 5))

# Shade training label regions
ax.axvspan(1.0, TC_EXACT, alpha=0.10, color="blue", label="Train label: ordered")
ax.axvspan(TC_EXACT, 3.5, alpha=0.10, color="red", label="Train label: disordered")

ax.plot(unique_temps, fnn_p_ordered, "bo-", markersize=4, label=f"FNN ($T_c$ = {tc_fnn:.3f})")
ax.plot(unique_temps, cnn_p_ordered, "rs-", markersize=4, label=f"CNN ($T_c$ = {tc_cnn:.3f})")
ax.axvline(TC_EXACT, color="k", linestyle="--", alpha=0.7, label=f"Exact $T_c$ = {TC_EXACT:.3f}")
ax.axhline(0.5, color="gray", linestyle=":", alpha=0.5)
ax.set_xlabel("Temperature $T$ ($J/k_B$)", fontsize=13)
ax.set_ylabel("$P(\\mathrm{ordered})$", fontsize=13)
ax.set_title("Neural Network Phase Classification: $P$(ordered) vs $T$", fontsize=14)
ax.legend(fontsize=10, loc="center right")
ax.grid(True, alpha=0.3)
ax.set_ylim(-0.05, 1.05)
ax.set_xlim(1.0, 3.5)
plt.tight_layout()
plt.savefig("results/p_ordered_vs_T.png", dpi=150)
plt.close()
print("\nSaved results/p_ordered_vs_T.png")

# Plot comparison bar chart
fig, ax = plt.subplots(figsize=(6, 4))
models = ["Exact\n(Onsager)", "FNN", "CNN"]
tc_values = [TC_EXACT, tc_fnn, tc_cnn]
colors = ["black", "steelblue", "indianred"]
bars = ax.bar(models, tc_values, color=colors, width=0.5)
ax.set_ylabel("$T_c$ estimate", fontsize=13)
ax.set_title("Critical Temperature Comparison", fontsize=14)
ax.set_ylim(2.0, 2.5)
for bar, val in zip(bars, tc_values):
    ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
            f"{val:.3f}", ha="center", fontsize=11)
ax.grid(True, alpha=0.3, axis="y")
plt.tight_layout()
plt.savefig("results/tc_comparison.png", dpi=150)
plt.close()
print("Saved results/tc_comparison.png")
