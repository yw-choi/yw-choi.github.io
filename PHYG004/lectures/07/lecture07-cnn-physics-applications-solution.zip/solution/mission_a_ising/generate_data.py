"""
Generate 2D Ising model training data for phase classification.

Produces spin configurations at various temperatures, labeled as:
  - ordered (label=1): T < Tc
  - disordered (label=0): T > Tc

where Tc = 2/ln(1+sqrt(2)) ≈ 2.269 (exact Onsager solution).

Output: ising_data.npz with keys 'configs', 'temperatures', 'labels'
"""

import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
from ising_mc import run_simulation

# Parameters
L = 40                          # Lattice size
TC = 2.0 / np.log(1 + np.sqrt(2))  # Exact critical temperature
N_TEMPS = 50                    # Number of temperature points
T_MIN, T_MAX = 1.0, 3.5        # Temperature range
N_SAMPLES_PER_T = 100           # Configurations per temperature
N_EQUILIB = 2000                # Equilibration sweeps
SAMPLE_INTERVAL = 10            # Sweeps between samples
SEED = 42

print(f"2D Ising Model Data Generation")
print(f"  Lattice size: {L}x{L}")
print(f"  Exact Tc = {TC:.4f}")
print(f"  Temperature range: [{T_MIN}, {T_MAX}], {N_TEMPS} points")
print(f"  Samples per temperature: {N_SAMPLES_PER_T}")
print()

temperatures_grid = np.linspace(T_MIN, T_MAX, N_TEMPS)

all_configs = []
all_temps = []
all_labels = []
all_magnetizations = []

for T in tqdm(temperatures_grid, desc="Generating data"):
    n_total_sweeps = N_EQUILIB + N_SAMPLES_PER_T * SAMPLE_INTERVAL
    result = run_simulation(
        L=L,
        T=T,
        n_sweeps=n_total_sweeps,
        n_equilib=N_EQUILIB,
        n_samples=N_SAMPLES_PER_T,
        sample_interval=SAMPLE_INTERVAL,
        seed=SEED + int(T * 1000),  # Different seed per temperature
    )

    configs = result["configs"]
    mags = result["magnetizations"]

    for cfg, mag in zip(configs, mags):
        all_configs.append(cfg)
        all_temps.append(T)
        all_labels.append(1 if T < TC else 0)  # 1=ordered, 0=disordered
        all_magnetizations.append(mag)

configs = np.array(all_configs, dtype=np.int8)
temperatures = np.array(all_temps, dtype=np.float32)
labels = np.array(all_labels, dtype=np.int64)
magnetizations = np.array(all_magnetizations, dtype=np.float32)

# Save data
np.savez(
    "ising_data.npz",
    configs=configs,
    temperatures=temperatures,
    labels=labels,
)
print(f"\nSaved ising_data.npz")
print(f"  configs shape: {configs.shape}")
print(f"  labels: {np.sum(labels == 1)} ordered, {np.sum(labels == 0)} disordered")

# Sanity check: magnetization vs temperature
mean_mag = []
unique_temps = np.unique(temperatures)
for T in unique_temps:
    mask = temperatures == T
    mean_mag.append(np.mean(magnetizations[mask]))
mean_mag = np.array(mean_mag)

plt.figure(figsize=(8, 5))
plt.plot(unique_temps, mean_mag, "bo-", markersize=4)
plt.axvline(TC, color="r", linestyle="--", label=f"$T_c$ = {TC:.3f} (exact)")
plt.xlabel("Temperature $T$ ($J/k_B$)", fontsize=13)
plt.ylabel("$\\langle |M| \\rangle$", fontsize=13)
plt.title("2D Ising Model: Magnetization vs Temperature", fontsize=14)
plt.legend(fontsize=12)
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig("results/magnetization_vs_T.png", dpi=150)
plt.close()
print("Saved results/magnetization_vs_T.png")

# Verify physics sanity
low_T_mag = np.mean(magnetizations[temperatures < 2.0])
high_T_mag = np.mean(magnetizations[temperatures > 2.5])
print(f"\nPhysics sanity check:")
print(f"  <|M|> for T < 2.0: {low_T_mag:.3f} (expect > 0.8)")
print(f"  <|M|> for T > 2.5: {high_T_mag:.3f} (expect < 0.2)")
