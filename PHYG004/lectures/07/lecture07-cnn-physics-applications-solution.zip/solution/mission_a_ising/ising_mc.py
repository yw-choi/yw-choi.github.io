"""
2D Ising Model Monte Carlo Simulation using Metropolis-Hastings Algorithm.

Reference: Carrasquilla & Melko, Nature Physics 13, 431 (2017)

The 2D Ising model Hamiltonian:
    H = -J * sum_{<i,j>} s_i * s_j
where s_i = +/- 1 and the sum is over nearest neighbors.
Critical temperature: Tc = 2 / ln(1 + sqrt(2)) ≈ 2.269 (Onsager, 1944)

Uses Numba JIT compilation for performance (~100x speedup over pure Python).
"""

import numpy as np
from numba import njit


@njit
def _metropolis_sweep(lattice, L, beta, rand_i, rand_j, rand_u):
    """JIT-compiled Metropolis sweep. L^2 single-spin flip attempts."""
    for k in range(L * L):
        i = rand_i[k]
        j = rand_j[k]
        s = lattice[i, j]

        # Nearest neighbors with periodic BC
        nn_sum = (
            lattice[(i + 1) % L, j]
            + lattice[(i - 1) % L, j]
            + lattice[i, (j + 1) % L]
            + lattice[i, (j - 1) % L]
        )

        dE = 2.0 * s * nn_sum

        if dE <= 0 or rand_u[k] < np.exp(-beta * dE):
            lattice[i, j] = -s


@njit
def _compute_energy(lattice, L):
    """JIT-compiled energy computation."""
    energy = 0.0
    for i in range(L):
        for j in range(L):
            s = lattice[i, j]
            energy -= s * (lattice[(i + 1) % L, j] + lattice[i, (j + 1) % L])
    return energy


def initialize_lattice(L: int, random: bool = True, rng: np.random.Generator = None) -> np.ndarray:
    """Initialize an L x L spin lattice.

    Args:
        L: Linear size of the lattice.
        random: If True, random +/-1 spins. If False, all spins +1 (ordered).
        rng: NumPy random generator.

    Returns:
        L x L array of +/-1 spins.
    """
    if rng is None:
        rng = np.random.default_rng()
    if random:
        return rng.choice(np.array([-1, 1]), size=(L, L)).astype(np.int64)
    else:
        return np.ones((L, L), dtype=np.int64)


def compute_magnetization(lattice: np.ndarray) -> float:
    """Compute magnetization per spin."""
    return np.abs(np.mean(lattice))


def metropolis_sweep(lattice: np.ndarray, T: float, rng: np.random.Generator) -> np.ndarray:
    """Perform one full Metropolis sweep (L^2 single-spin flip attempts).

    Args:
        lattice: Current spin configuration.
        T: Temperature (in units of J/k_B).
        rng: NumPy random generator.

    Returns:
        Updated lattice (modified in-place and returned).
    """
    L = lattice.shape[0]
    beta = 1.0 / T
    n = L * L
    rand_i = rng.integers(0, L, size=n)
    rand_j = rng.integers(0, L, size=n)
    rand_u = rng.random(size=n)
    _metropolis_sweep(lattice, L, beta, rand_i, rand_j, rand_u)
    return lattice


def run_simulation(
    L: int,
    T: float,
    n_sweeps: int = 1000,
    n_equilib: int = 500,
    n_samples: int = 1,
    sample_interval: int = 10,
    seed: int = None,
) -> dict:
    """Run a full Ising MC simulation at temperature T.

    Args:
        L: Lattice size.
        T: Temperature.
        n_sweeps: Total number of MC sweeps (equilibration + measurement).
        n_equilib: Number of equilibration sweeps.
        n_samples: Number of configurations to collect.
        sample_interval: Sweeps between samples (decorrelation).
        seed: Random seed.

    Returns:
        Dictionary with keys:
            'configs': list of spin configurations
            'magnetizations': list of |M| values
            'energies': list of energy values
    """
    rng = np.random.default_rng(seed)

    # Start from ordered state at low T, random at high T
    ordered_start = T < 2.269
    lattice = initialize_lattice(L, random=not ordered_start, rng=rng)

    # Equilibration
    for _ in range(n_equilib):
        metropolis_sweep(lattice, T, rng)

    # Measurement
    configs = []
    magnetizations = []
    energies = []

    for sweep in range(n_sweeps - n_equilib):
        metropolis_sweep(lattice, T, rng)
        if sweep % sample_interval == 0 and len(configs) < n_samples:
            configs.append(lattice.copy())
            magnetizations.append(compute_magnetization(lattice))
            energies.append(_compute_energy(lattice, L) / (L * L))

    return {
        "configs": configs,
        "magnetizations": magnetizations,
        "energies": energies,
    }


if __name__ == "__main__":
    # Quick test (first call triggers JIT compilation)
    L = 16
    print("Compiling JIT functions...")
    for T in [1.5, 2.269, 3.5]:
        result = run_simulation(L, T, n_sweeps=2000, n_equilib=1000, n_samples=1, seed=42)
        print(f"T={T:.3f}: |M|={result['magnetizations'][0]:.3f}, E/N={result['energies'][0]:.3f}")
    print("Done.")
