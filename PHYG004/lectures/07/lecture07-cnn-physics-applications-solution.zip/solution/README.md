# Lecture 07: CNN/FNN Applications in Physics — Solution

Complete working solutions for the hands-on session.

## Mission A: Ising Phase Classification

Reproduces: Carrasquilla & Melko, *Nature Physics* **13**, 431 (2017)

### Execution Order

```bash
cd mission_a_ising
python generate_data.py    # ~10s with Numba, generates ising_data.npz
python train_fnn.py        # ~30s, test accuracy ~97%
python train_cnn.py        # ~60s, test accuracy ~99%
python analyze.py          # ~5s, estimates Tc ≈ 2.27
```

### Expected Results

| Model | Test Accuracy | Tc Estimate | |Tc - Tc_exact| |
|-------|--------------|-------------|-----------------|
| FNN   | ~97%         | ~2.257      | ~0.012          |
| CNN   | ~99%         | ~2.274      | ~0.005          |

Exact: Tc = 2.269 (Onsager 1944)

## Mission B: Galaxy Morphology Classification

Inspired by: Dieleman, Willett & Dambre, *MNRAS* **450**, 1441 (2015)
Dataset: Galaxy10 DECals (subset)

### Data Preparation (Instructor Only)

```bash
cd mission_b_galaxy
python prepare_subset.py   # Downloads Galaxy10 (~2.5GB), extracts 5k subset
# Then upload galaxy_subset.npz to Google Drive
```

### Execution Order (Students)

```bash
cd mission_b_galaxy
python download_data.py    # Downloads subset from Google Drive
python train_cnn.py        # ~3min CPU, test accuracy ~92%
python evaluate.py         # Confusion matrix + sample predictions
```

### Expected Results

| Metric | Value |
|--------|-------|
| Test Accuracy | ~92% |
| Elliptical Precision | ~86% |
| Spiral Precision | ~98% |

## Dependencies

```bash
pip install -r requirements.txt
```
