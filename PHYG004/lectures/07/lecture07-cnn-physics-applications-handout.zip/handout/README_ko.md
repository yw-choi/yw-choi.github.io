# Lecture 07: AI Agent와 함께하는 물리 논문 재현

## Overview

이번 세션에서는 **VS Code Copilot Chat Agent**와 대화하면서 물리 연구 논문의 결과를 재현합니다.
직접 코드를 처음부터 짜는 것이 아니라, AI agent에게 물리적 맥락을 설명하고 코드를 생성하게 한 뒤,
**물리적 직관으로 결과를 검증**하는 과정을 경험합니다.

## Setup

### 1. Git Repository 생성

Copilot Chat을 열고 Agent mode (Ctrl+I)에서 다음과 같이 요청하세요:

> "sogang-physics org에 2026-ml-{내이름} 이라는 private repo를 gh CLI로 만들고 clone해줘.
> 그리고 Python 가상환경을 만들고 PyTorch, torchvision, NumPy, matplotlib, scikit-learn, tqdm, numba를 설치해줘.
> requirements.txt도 만들어줘."

### 2. VS Code Copilot 사용법

- **Ctrl+L**: Copilot Chat 열기
- **@workspace**: 현재 프로젝트 컨텍스트 포함
- **Agent mode** (Ctrl+I): 파일 생성/수정을 agent가 직접 수행
- 중요: Agent mode에서 작업하면 파일을 직접 만들어줍니다

### 3. 팁: Agent에게 좋은 프롬프트 주기

| Bad | Good |
|-----|------|
| "ML 코드 짜줘" | "2D Ising model의 Metropolis MC simulation을 구현해줘. L×L 격자, periodic BC, temperature T를 인자로 받아서 평형 후 spin configuration을 반환" |
| "CNN 만들어줘" | "40×40 spin configuration 이미지를 ordered/disordered로 분류하는 CNN을 PyTorch로 만들어줘. Conv2d 2개, MaxPool, FC layer 구조로" |

**물리적 맥락을 많이 줄수록** agent가 더 좋은 코드를 생성합니다.

---

## Mission A: Ising Phase Classification (Main)

**논문**: Carrasquilla & Melko, *Nature Physics* **13**, 431 (2017)
— "Machine learning phases of matter"

**목표**: Neural network으로 2D Ising model의 상전이를 감지하고, 임계온도 Tc를 추정

자세한 내용: [mission_a_ising/README_ko.md](mission_a_ising/README_ko.md)

**예상 소요 시간**: 40-50분

---

## Mission B: Galaxy Morphology Classification (시간 되면)

**논문**: Dieleman, Willett & Dambre, *MNRAS* **450**, 1441 (2015)
— "Rotation-invariant convolutional neural networks for galaxy morphology prediction"

**목표**: CNN으로 은하 이미지를 spiral/elliptical로 분류

자세한 내용: [mission_b_galaxy/README_ko.md](mission_b_galaxy/README_ko.md)

**예상 소요 시간**: 20-30분

---

## 제출

작업이 끝나면 agent에게 요청하세요:

> "지금까지 작업한 모든 코드와 결과물을 git에 commit하고 push해줘.
> 커밋 메시지는 'Lecture 07 hands-on: Ising classification and galaxy morphology'로."

## 평가 기준

- 코드의 정확성보다는 **agent와의 작업 과정**을 중시합니다
- Git history에 작업 과정이 남아있으면 좋습니다 (중간중간 commit)
- 최종 결과물:
  - Ising: P(ordered) vs T 플롯 + Tc 추정값
  - Galaxy (optional): Confusion matrix + sample predictions
