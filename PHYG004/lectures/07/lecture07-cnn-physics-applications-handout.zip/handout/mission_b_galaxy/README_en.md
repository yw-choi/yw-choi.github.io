# Mission B: Galaxy Morphology Classification

## Background

Galaxies are broadly classified by morphology into **elliptical** and **spiral** types.
Traditionally classified by eye (the Galaxy Zoo project),
CNNs can automate this task.

**Key physics**: Galaxies have rotational symmetry — the orientation of a galaxy
is irrelevant to its morphological classification. This makes **flip/rotation augmentation**
a physically motivated data augmentation strategy.

**Paper**: Dieleman, Willett & Dambre, *MNRAS* **450**, 1441 (2015)

---

## Step 1: Data Download & Exploration

**Goal**: Download the galaxy dataset and visualize it

Ask Copilot:

> "Run download_data.py to download the galaxy data.
> Then load galaxy_subset.npz and explore the data.
> Print the image shape and label distribution.
> Visualize 8 elliptical and 8 spiral galaxies side by side."

**Checkpoint**:
- [ ] `galaxy_subset.npz` downloaded
- [ ] Images shape: (5000, 64, 64, 3)
- [ ] 2500 elliptical + 2500 spiral
- [ ] Visual check: can you tell the two types apart by eye?

---

## Step 2: CNN Model & Training

**Ask Copilot**:

> "Build a PyTorch CNN to classify 64×64 RGB galaxy images as spiral vs elliptical.
> Use 3 Conv2d layers + ReLU + MaxPool + FC layer with Dropout.
> 70/15/15 train/val/test split.
> Apply RandomHorizontalFlip for data augmentation — galaxies have mirror symmetry.
> 20 epochs, Adam optimizer with lr=3e-4. Plot train/val loss and accuracy curves."

**Checkpoint**:
- [ ] `train_cnn.py` runs successfully
- [ ] Test accuracy ≥ 85%
- [ ] Training time: under 5 minutes on CPU
- [ ] Overfitting check: train_acc - val_acc < 15%

**Physics interpretation**: Why is horizontal flip effective?
→ A galaxy's physical properties don't depend on the observation orientation.

---

## Step 3: Evaluation & Interpretation

**Ask Copilot**:

> "Evaluate the trained galaxy CNN model.
> Plot a confusion matrix for the test set.
> Visualize correctly classified and misclassified examples with their images.
> Print a classification report."

**Checkpoint**:
- [ ] Confusion matrix: diagonal-dominant
- [ ] Sample predictions visualization
- [ ] Examine misclassified images: can you explain why the model got them wrong?

**Think about it**: What kinds of galaxies does the model get wrong?
(edge-on spirals? blurry images? ambiguous morphology?)

---

## Completion Criteria

1. **Data visualization**: elliptical vs spiral sample images
2. **CNN**: test accuracy ≥ 85%
3. **Evaluation**: confusion matrix + sample predictions + interpretation

Ask the agent to commit & push!
