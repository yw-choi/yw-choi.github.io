"""
Train a CNN to classify galaxy morphology (spiral vs elliptical).

Inspired by: Dieleman, Willett & Dambre, MNRAS 450, 1441 (2015)
Dataset: Galaxy10 DECals subset (5000 images, 64x64 RGB)

Key physics insight: Galaxies have rotational symmetry, so data
augmentation with random rotations is physically motivated.
"""

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset, random_split
import matplotlib.pyplot as plt

BATCH_SIZE = 64
LEARNING_RATE = 1e-3
N_EPOCHS = 20
SEED = 42


class GalaxyCNN(nn.Module):
    """CNN for galaxy morphology classification.

    Architecture:
        Conv2d(3, 32, 3) -> ReLU -> MaxPool
        Conv2d(32, 64, 3) -> ReLU -> MaxPool
        Conv2d(64, 128, 3) -> ReLU -> MaxPool
        Flatten -> Linear(128*6*6, 128) -> ReLU -> Dropout -> Linear(128, 2)
    """
    def __init__(self):
        super().__init__()
        # TODO: Define the convolutional feature extractor
        # Hint: Use Conv2d, BatchNorm2d, ReLU, MaxPool2d
        self.features = nn.Sequential(
            # FIXME: Add conv layers
            nn.Identity(),  # placeholder
        )
        # TODO: Define the classifier head
        self.classifier = nn.Sequential(
            nn.Flatten(),
            # FIXME: Add FC layers
            nn.Identity(),  # placeholder
        )

    def forward(self, x):
        x = self.features(x)
        x = self.classifier(x)
        return x


def main():
    torch.manual_seed(SEED)
    np.random.seed(SEED)
    device = torch.device("cpu")

    # Load data
    print("Loading galaxy data...")
    data = np.load("galaxy_subset.npz")
    images = data["images"]   # (5000, 64, 64, 3) uint8
    labels = data["labels"]   # (5000,)

    # TODO: Normalize to [0, 1] and convert to (N, C, H, W) format
    # Hint: torch.tensor(...).permute(0, 3, 1, 2) / 255.0

    # TODO: Split into train/val/test (70/15/15)

    # TODO: Create DataLoaders

    # TODO: Define data augmentation
    # Hint: RandomRotation(180) is physically motivated!

    model = GalaxyCNN().to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

    print(f"Model: {sum(p.numel() for p in model.parameters()):,} parameters")

    # TODO: Training loop with augmentation
    # Apply augmentation to training batches only

    # TODO: Test evaluation

    # TODO: Save model

    # TODO: Plot training curves (train/val loss and accuracy)


if __name__ == "__main__":
    main()
