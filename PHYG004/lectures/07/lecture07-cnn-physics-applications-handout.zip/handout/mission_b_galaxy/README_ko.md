# Mission B: Galaxy Morphology Classification

## Background

은하는 형태에 따라 크게 **elliptical** (타원 은하)과 **spiral** (나선 은하)로 분류됩니다.
전통적으로 천문학자들이 육안으로 분류했지만 (Galaxy Zoo 프로젝트),
CNN을 사용하면 자동으로 분류할 수 있습니다.

**핵심 물리**: 은하는 회전 대칭을 가집니다 — 은하의 방향(orientation)은
형태 분류와 무관합니다. 따라서 **rotation augmentation**이 물리적으로 자연스러운
data augmentation 전략입니다.

**논문**: Dieleman, Willett & Dambre, *MNRAS* **450**, 1441 (2015)

---

## Step 1: Data Download & Exploration

**Goal**: Galaxy 데이터셋 다운로드 및 시각화

Copilot에게 요청하세요:

> "download_data.py를 실행해서 galaxy 데이터를 다운로드해줘.
> 그리고 galaxy_subset.npz를 로드해서 데이터를 탐색해줘.
> 이미지 shape, label 분포를 확인하고,
> elliptical과 spiral 각각 8개씩 시각화해줘."

**Checkpoint**:
- [ ] `galaxy_subset.npz` 다운로드 완료
- [ ] Images shape: (5000, 64, 64, 3)
- [ ] 2500 elliptical + 2500 spiral
- [ ] 시각화: 사람 눈으로 봐도 두 종류가 다르게 보이는가?

---

## Step 2: CNN 모델 구현 & 학습

**Copilot에게 요청해보세요**:

> "galaxy_subset.npz의 64×64 RGB 은하 이미지를 spiral vs elliptical로 분류하는 CNN을 만들어줘.
> PyTorch로 구현하고, Conv2d 3개 + ReLU + MaxPool + FC layer with Dropout.
> 70/15/15 train/val/test split.
> Data augmentation으로 RandomHorizontalFlip을 적용해줘 — 은하는 좌우 대칭이니까.
> 20 epochs, Adam optimizer with lr=3e-4, train/val loss curve와 accuracy curve를 플롯해줘."

**Checkpoint**:
- [ ] `train_cnn.py` 실행 완료
- [ ] Test accuracy ≥ 85%
- [ ] Training time: CPU에서 5분 이내
- [ ] Overfitting 확인: train_acc - val_acc < 15%

**물리적 해석**: RandomRotation(180)이 효과적인 이유는?
→ 은하의 물리적 성질은 관측 방향에 의존하지 않음.

---

## Step 3: Evaluation & Interpretation

**Copilot에게 요청해보세요**:

> "학습된 galaxy CNN 모델을 평가해줘.
> Test set에 대한 confusion matrix를 그리고,
> 맞힌 예시와 틀린 예시를 각각 이미지로 시각화해줘.
> Classification report도 출력해줘."

**Checkpoint**:
- [ ] Confusion matrix: 대각선이 우세
- [ ] Sample predictions 시각화
- [ ] 틀린 이미지 관찰: 왜 틀렸는지 물리적으로 해석해보기

**생각해볼 것**: 모델이 틀리는 은하는 어떤 특징이 있나요?
(edge-on spiral? 흐릿한 이미지? 애매한 형태?)

---

## 완료 기준

1. **데이터 시각화**: elliptical vs spiral 샘플 이미지
2. **CNN**: test accuracy ≥ 85%
3. **평가**: confusion matrix + sample predictions + 해석

Agent에게 commit & push를 요청하세요!
