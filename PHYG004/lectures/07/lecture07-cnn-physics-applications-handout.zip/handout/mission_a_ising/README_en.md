# Mission A: 2D Ising Model Phase Classification

## Background

The 2D Ising model is a canonical model in statistical mechanics with an exact analytical solution (Onsager, 1944).

**Hamiltonian**: $H = -J \sum_{\langle i,j \rangle} s_i s_j$, where $s_i = \pm 1$

**Critical temperature**: $T_c = \frac{2}{\ln(1+\sqrt{2})} \approx 2.269 \, J/k_B$

- $T < T_c$: **ordered phase** (ferromagnetic — most spins aligned)
- $T > T_c$: **disordered phase** (paramagnetic — spins are random)

**Key idea**: Show spin configurations to a neural network and train it to classify
ordered vs disordered. The network's output changes sharply near $T_c$,
effectively detecting the phase transition.

---

## Step 1: Monte Carlo Simulation

**Goal**: Implement a Metropolis-Hastings MC simulation for the 2D Ising model

**Ask Copilot**:

> "Implement a Metropolis-Hastings Monte Carlo simulation for the 2D Ising model in Python.
> Use an L×L square lattice with periodic boundary conditions.
> Take temperature T as an argument. One sweep = L^2 single-spin flip attempts.
> Optimize with Numba @njit. Return the equilibrium spin configuration as a +/-1 array."

**Checkpoint**:
- [ ] `ising_mc.py` created
- [ ] Running at L=16, T=1.5 gives |M| > 0.8 (ordered)
- [ ] Running at L=16, T=3.5 gives |M| < 0.2 (disordered)
- [ ] Runs in ~1 second per temperature (after Numba compilation)

**Hint**: The Metropolis criterion: always accept if $\Delta E \leq 0$,
otherwise accept with probability $\exp(-\beta \Delta E)$. Energy change: $\Delta E = 2 s_i \sum_{nn} s_j$

---

## Step 2: Training Data Generation

**Goal**: Generate spin configurations at multiple temperatures and create a labeled dataset

**Ask Copilot**:

> "Using ising_mc.py, create a script to generate training data.
> L=40 lattice, 50 temperatures from T=1.0 to T=3.5, 100 configurations per temperature.
> Label T < Tc = 2.269 as ordered (label 1), T > Tc as disordered (label 0).
> Save results to ising_data.npz and plot magnetization vs T."

**Checkpoint**:
- [ ] `ising_data.npz` created (configs, temperatures, labels)
- [ ] configs.shape = (5000, 40, 40)
- [ ] Magnetization vs T plot shows transition near T ≈ 2.27
- [ ] T < 2.0: |M| > 0.8, T > 2.5: |M| < 0.2

---

## Step 3: FNN Classifier

**Goal**: Classify phases using a Fully Connected Neural Network

**Ask Copilot**:

> "Load ising_data.npz and build a PyTorch FNN to classify ordered/disordered.
> Flatten the 40×40 spin configuration to a 1600-dimensional input.
> Hidden layers: 128 → 64 → 2 (with ReLU).
> 80/20 train/test split, Adam optimizer with lr=3e-4, 15 epochs.
> Plot the training curve and print the final test accuracy."

**Checkpoint**:
- [ ] `train_fnn.py` runs successfully
- [ ] Test accuracy ≥ 90%
- [ ] Training loss decreases smoothly

**Physics interpretation**: Regions far from Tc (T ≪ Tc and T ≫ Tc) are easy to classify.
The challenging samples are configurations near T ≈ Tc.

---

## Step 4: CNN Classifier

**Goal**: Solve the same problem with a CNN (exploiting 2D structure)

**Ask Copilot**:

> "Use the same Ising data but in (1, 40, 40) image format and classify with a CNN.
> Conv2d(1→16, 3) → ReLU → MaxPool → Conv2d(16→32, 3) → ReLU → MaxPool → FC → 2.
> Same train/test split and hyperparameters as the FNN."

**Checkpoint**:
- [ ] `train_cnn.py` runs successfully
- [ ] Test accuracy ≥ 92% (should match or exceed the FNN)
- [ ] Training time: under 2 minutes on CPU

**Physics interpretation**: Why does the CNN outperform the FNN?
→ Spin-spin correlations have spatial structure, and convolutional filters capture these patterns more efficiently.

---

## Step 5: Critical Temperature Estimation

**Goal**: Estimate Tc from the trained models

**Ask Copilot**:

> "Load the trained FNN and CNN models, and compute P(ordered) at each temperature.
> Plot P(ordered) vs T — it should show a sigmoid-like curve.
> Find the temperature where P = 0.5 using linear interpolation to estimate Tc.
> Compare with the exact value Tc = 2.269."

**Checkpoint**:
- [ ] P(ordered) vs T plot: monotonically decreasing sigmoid-like curve
- [ ] FNN Tc estimate: 2.0 < Tc < 2.5
- [ ] |Tc_estimated - 2.269| < 0.15
- [ ] FNN vs CNN comparison plot

---

## Completion Criteria

When Mission A is complete, verify:

1. **Data**: `ising_data.npz` + magnetization plot
2. **FNN**: model file + training curve + test accuracy ≥ 90%
3. **CNN**: model file + training curve + test accuracy ≥ 92%
4. **Analysis**: P(ordered) vs T plot + Tc estimate

Once confirmed, ask the agent to commit, then move on to Mission B!
