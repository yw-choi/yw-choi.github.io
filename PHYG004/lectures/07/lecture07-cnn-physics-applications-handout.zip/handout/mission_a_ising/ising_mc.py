"""
2D Ising Model Monte Carlo Simulation using Metropolis-Hastings Algorithm.

Reference: Carrasquilla & Melko, Nature Physics 13, 431 (2017)

The 2D Ising model Hamiltonian:
    H = -J * sum_{<i,j>} s_i * s_j
where s_i = +/- 1 and the sum is over nearest neighbors.
Critical temperature: Tc = 2 / ln(1 + sqrt(2)) ≈ 2.269 (Onsager, 1944)
"""

import numpy as np
from numba import njit


@njit
def _metropolis_sweep(lattice, L, beta, rand_i, rand_j, rand_u):
    """JIT-compiled Metropolis sweep. L^2 single-spin flip attempts.

    For each attempt:
    1. Pick a random site (i, j)
    2. Compute energy change dE = 2 * s_i * (sum of nearest neighbors)
    3. Accept flip if dE <= 0, or with probability exp(-beta * dE)
    """
    for k in range(L * L):
        i = rand_i[k]
        j = rand_j[k]
        s = lattice[i, j]

        # TODO: Compute sum of nearest neighbors with periodic boundary conditions
        # Hint: neighbors are at (i+1)%L, (i-1)%L, (j+1)%L, (j-1)%L
        nn_sum = 0  # FIXME: replace with actual neighbor sum

        # TODO: Compute energy change for flipping spin at (i, j)
        dE = 0.0  # FIXME: dE = 2 * s * nn_sum

        # TODO: Apply Metropolis acceptance criterion
        # If dE <= 0: always accept (flip the spin)
        # Else: accept with probability exp(-beta * dE)
        pass  # FIXME: implement acceptance and spin flip


def initialize_lattice(L, random=True, rng=None):
    """Initialize an L x L spin lattice with +/-1 values."""
    if rng is None:
        rng = np.random.default_rng()
    if random:
        return rng.choice(np.array([-1, 1]), size=(L, L)).astype(np.int64)
    else:
        return np.ones((L, L), dtype=np.int64)


def compute_magnetization(lattice):
    """Compute magnetization per spin: |<s>|"""
    return np.abs(np.mean(lattice))


def metropolis_sweep(lattice, T, rng):
    """Perform one full Metropolis sweep (L^2 single-spin flip attempts)."""
    L = lattice.shape[0]
    beta = 1.0 / T
    n = L * L
    rand_i = rng.integers(0, L, size=n)
    rand_j = rng.integers(0, L, size=n)
    rand_u = rng.random(size=n)
    _metropolis_sweep(lattice, L, beta, rand_i, rand_j, rand_u)
    return lattice


def run_simulation(L, T, n_sweeps=1000, n_equilib=500, n_samples=1,
                   sample_interval=10, seed=None):
    """Run a full Ising MC simulation at temperature T.

    Returns dict with 'configs', 'magnetizations', 'energies'.
    """
    rng = np.random.default_rng(seed)
    ordered_start = T < 2.269
    lattice = initialize_lattice(L, random=not ordered_start, rng=rng)

    # Equilibration
    for _ in range(n_equilib):
        metropolis_sweep(lattice, T, rng)

    # Measurement
    configs = []
    magnetizations = []

    for sweep in range(n_sweeps - n_equilib):
        metropolis_sweep(lattice, T, rng)
        if sweep % sample_interval == 0 and len(configs) < n_samples:
            configs.append(lattice.copy())
            magnetizations.append(compute_magnetization(lattice))

    return {"configs": configs, "magnetizations": magnetizations}


if __name__ == "__main__":
    L = 16
    print("Testing Ising MC...")
    for T in [1.5, 2.269, 3.5]:
        result = run_simulation(L, T, n_sweeps=2000, n_equilib=1000, n_samples=1, seed=42)
        print(f"T={T:.3f}: |M|={result['magnetizations'][0]:.3f}")
