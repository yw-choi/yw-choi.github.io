"""
Train a Fully Connected Neural Network (FNN) to classify 2D Ising model
configurations as ordered vs disordered phases.

Reference: Carrasquilla & Melko, Nature Physics 13, 431 (2017)

Input:  Flattened spin configuration (L*L = 1600 features)
Output: Binary classification (0=disordered, 1=ordered)
"""

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt

BATCH_SIZE = 128
LEARNING_RATE = 1e-3
N_EPOCHS = 20
SEED = 42


class IsingFNN(nn.Module):
    """Simple FNN for Ising phase classification.

    Architecture: 1600 -> 128 -> 64 -> 2
    """
    def __init__(self, input_dim=1600):
        super().__init__()
        # TODO: Define the network layers
        # Hint: Use nn.Sequential with nn.Linear, nn.ReLU, nn.Dropout
        # Input: 1600 (flattened 40x40 lattice)
        # Hidden: 128 -> 64
        # Output: 2 classes (ordered, disordered)
        self.net = nn.Sequential(
            # FIXME: Add layers here
            nn.Identity(),  # placeholder
        )

    def forward(self, x):
        return self.net(x)


def main():
    torch.manual_seed(SEED)
    np.random.seed(SEED)
    device = torch.device("cpu")

    # Load data
    print("Loading data...")
    data = np.load("ising_data.npz")
    configs = data["configs"].astype(np.float32)
    labels = data["labels"]

    N, L, _ = configs.shape
    X = configs.reshape(N, -1)  # Flatten to (N, 1600)
    y = labels

    # TODO: Train/test split (80/20)
    # Hint: use train_test_split from sklearn

    # TODO: Create DataLoaders

    model = IsingFNN().to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

    print(f"Model: {sum(p.numel() for p in model.parameters())} parameters")

    # TODO: Training loop
    # For each epoch:
    #   1. Set model to train mode
    #   2. Loop over batches, compute loss, backprop, update
    #   3. Evaluate on test set
    #   4. Print progress every 5 epochs

    # TODO: Save model with torch.save(model.state_dict(), "fnn_model.pt")

    # TODO: Plot training curves (loss and accuracy vs epoch)


if __name__ == "__main__":
    main()
