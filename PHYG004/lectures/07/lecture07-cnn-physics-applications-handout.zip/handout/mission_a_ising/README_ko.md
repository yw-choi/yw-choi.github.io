# Mission A: 2D Ising Model Phase Classification

## Background

2D Ising model은 통계역학의 대표적인 모델로, 정확한 해석해가 존재합니다 (Onsager, 1944).

**Hamiltonian**: $H = -J \sum_{\langle i,j \rangle} s_i s_j$, where $s_i = \pm 1$

**Critical temperature**: $T_c = \frac{2}{\ln(1+\sqrt{2})} \approx 2.269 \, J/k_B$

- $T < T_c$: **ordered phase** (ferromagnetic, 대부분의 스핀이 같은 방향)
- $T > T_c$: **disordered phase** (paramagnetic, 스핀이 무작위)

**핵심 아이디어**: Neural network에게 spin configuration을 보여주고
ordered인지 disordered인지 분류하게 하면, network의 output이
$T_c$ 근처에서 급격히 변하면서 상전이를 감지할 수 있다.

---

## Step 1: Monte Carlo Simulation

**Goal**: 2D Ising model의 Metropolis-Hastings MC simulation 구현

**Copilot에게 요청해보세요**:

> "2D Ising model의 Metropolis-Hastings Monte Carlo simulation을 Python으로 구현해줘.
> L×L 정사각 격자에서 periodic boundary condition을 사용하고,
> temperature T를 인자로 받아. 한 sweep은 L^2번의 single-spin flip 시도야.
> Numba @njit으로 최적화해줘. 결과로 equilibrium spin configuration (+/-1 array)을 반환해."

**Checkpoint**:
- [ ] `ising_mc.py` 파일 생성됨
- [ ] L=16, T=1.5에서 실행 → |M| > 0.8 (ordered)
- [ ] L=16, T=3.5에서 실행 → |M| < 0.2 (disordered)
- [ ] 한 temperature에서 ~1초 내 실행 (Numba 컴파일 후)

**힌트**: Metropolis criterion은 $\Delta E \leq 0$이면 항상 accept,
아니면 $\exp(-\beta \Delta E)$ 확률로 accept. $\Delta E = 2 s_i \sum_{nn} s_j$

---

## Step 2: Training Data Generation

**Goal**: 여러 온도에서 spin configuration을 생성하고 labeled dataset 만들기

**Copilot에게 요청해보세요**:

> "ising_mc.py를 사용해서 training data를 생성하는 스크립트를 만들어줘.
> L=40 격자, T=1.0부터 3.5까지 50개 온도에서 각 100개 configuration을 생성해.
> T < Tc = 2.269는 ordered (label 1), T > Tc는 disordered (label 0)으로 labeling.
> 결과를 ising_data.npz로 저장하고, magnetization vs T 플롯도 그려줘."

**Checkpoint**:
- [ ] `ising_data.npz` 생성 (configs, temperatures, labels)
- [ ] configs.shape = (5000, 40, 40)
- [ ] Magnetization vs T 플롯에서 T ≈ 2.27 근처 전이 확인
- [ ] T < 2.0: |M| > 0.8, T > 2.5: |M| < 0.2

---

## Step 3: FNN Classifier

**Goal**: Fully Connected Neural Network으로 phase 분류

**Copilot에게 요청해보세요**:

> "ising_data.npz를 로드해서 FNN으로 ordered/disordered를 분류하는 PyTorch 모델을 만들어줘.
> 40×40 spin configuration을 flatten해서 1600차원 입력으로 사용.
> Hidden layers: 128 → 64 → 2 (with ReLU, Dropout).
> 80/20 train/test split, Adam optimizer, 20 epochs.
> Training curve 플롯과 최종 test accuracy를 출력해줘."

**Checkpoint**:
- [ ] `train_fnn.py` 실행 완료
- [ ] Test accuracy ≥ 90%
- [ ] Training loss가 감소하는 플롯

**물리적 해석**: T ≪ Tc와 T ≫ Tc 영역은 구분이 쉽기 때문에 높은 정확도.
어려운 부분은 T ≈ Tc 근처의 configurations.

---

## Step 4: CNN Classifier

**Goal**: CNN으로 같은 문제 풀기 (2D 구조 활용)

**Copilot에게 요청해보세요**:

> "같은 Ising 데이터를 (1, 40, 40) 형태로 2D 이미지처럼 CNN에 넣어서 분류해줘.
> Conv2d(1→16, 3) → ReLU → MaxPool → Conv2d(16→32, 3) → ReLU → MaxPool → FC → 2.
> FNN과 같은 train/test split, 같은 hyperparameters 사용."

**Checkpoint**:
- [ ] `train_cnn.py` 실행 완료
- [ ] Test accuracy ≥ 92% (FNN보다 같거나 높아야)
- [ ] Training time: CPU에서 2분 이내

**물리적 해석**: CNN이 FNN보다 좋은 이유는? → Spin-spin correlation은 공간적 구조이므로
convolutional filter가 이 패턴을 더 효율적으로 캡처.

---

## Step 5: Critical Temperature Estimation

**Goal**: 학습된 모델로 Tc 추정

**Copilot에게 요청해보세요**:

> "학습된 FNN과 CNN 모델을 로드해서, 각 온도별로 P(ordered)를 계산해줘.
> P(ordered) vs T를 플롯하면 sigmoid-like curve가 나올 거야.
> P = 0.5가 되는 온도를 linear interpolation으로 찾아서 Tc를 추정하고,
> exact value Tc = 2.269와 비교해줘."

**Checkpoint**:
- [ ] P(ordered) vs T 플롯: 단조감소하는 sigmoid-like curve
- [ ] FNN Tc 추정값: 2.0 < Tc < 2.5
- [ ] |Tc_estimated - 2.269| < 0.15
- [ ] FNN vs CNN 비교 플롯

---

## 완료 기준

Mission A가 완료되면 다음을 확인하세요:

1. **데이터**: `ising_data.npz` + magnetization 플롯
2. **FNN**: 모델 파일 + training curve + test accuracy ≥ 90%
3. **CNN**: 모델 파일 + training curve + test accuracy ≥ 92%
4. **분석**: P(ordered) vs T 플롯 + Tc 추정값

모두 확인되면 agent에게 commit을 요청하고 Mission B로 넘어가세요!
