# Lecture 07: Reproducing Physics Papers with an AI Agent

## Overview

In this session, you will reproduce results from physics research papers by **conversing with VS Code Copilot Chat Agent**.
Rather than writing code from scratch, you will explain the physical context to an AI agent, have it generate code,
and then **verify the results using your physics intuition**.

## Setup

### 1. Create a Git Repository

Open Copilot Chat in Agent mode (Ctrl+I) and ask:

> "Create a private repo called 2026-ml-{my-name} under the sogang-physics org using the gh CLI, and clone it.
> Then set up a Python virtual environment and install PyTorch, torchvision, NumPy, matplotlib, scikit-learn, tqdm, and numba.
> Also create a requirements.txt file."

### 2. Using VS Code Copilot

- **Ctrl+L**: Open Copilot Chat
- **@workspace**: Include current project context
- **Agent mode** (Ctrl+I): Agent directly creates/edits files
- Important: In Agent mode, the agent creates files for you

### 3. Tips: Writing Good Prompts for the Agent

| Bad | Good |
|-----|------|
| "Write ML code" | "Implement a Metropolis MC simulation for the 2D Ising model. Take an L×L lattice with periodic BC and temperature T as arguments. Return the equilibrated spin configuration." |
| "Make a CNN" | "Build a PyTorch CNN that classifies 40×40 spin configuration images as ordered/disordered. Use 2 Conv2d layers, MaxPool, and FC layers." |

**The more physical context you provide**, the better code the agent generates.

---

## Mission A: Ising Phase Classification (Main)

**Paper**: Carrasquilla & Melko, *Nature Physics* **13**, 431 (2017)
— "Machine learning phases of matter"

**Goal**: Detect the 2D Ising model phase transition using a neural network and estimate the critical temperature Tc

Details: [mission_a_ising/README_en.md](mission_a_ising/README_en.md)

**Estimated time**: 40-50 min

---

## Mission B: Galaxy Morphology Classification (if time permits)

**Paper**: Dieleman, Willett & Dambre, *MNRAS* **450**, 1441 (2015)
— "Rotation-invariant convolutional neural networks for galaxy morphology prediction"

**Goal**: Classify galaxy images as spiral or elliptical using a CNN

Details: [mission_b_galaxy/README_en.md](mission_b_galaxy/README_en.md)

**Estimated time**: 20-30 min

---

## Submission

When you're done, ask the agent:

> "Commit all my code and results to git and push.
> Use the commit message 'Lecture 07 hands-on: Ising classification and galaxy morphology'."

## Grading Criteria

- We value the **process of working with the agent** over code correctness
- It's great if your git history shows the work process (commit often)
- Final deliverables:
  - Ising: P(ordered) vs T plot + Tc estimate
  - Galaxy (optional): Confusion matrix + sample predictions
