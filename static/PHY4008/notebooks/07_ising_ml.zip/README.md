# Machine learning phases of matter: Ising model

`07_ising_ml.ipynb` reproduces the Ising-model results of J. Carrasquilla and
R. G. Melko, *Machine learning phases of matter*, arXiv:1605.01735
(Nature Physics 13, 431 (2017)).

| File | Content |
| --- | --- |
| 07_ising_ml.ipynb | Student-facing notebook (English), saved with outputs |
| 07_ising_ml.html | Offline preview of the executed notebook |
| ising_ml_data.npz | Saved Monte Carlo configurations (regenerated when missing) |

## Structure

1. Metropolis sampling of the square lattice (Numba), configuration gallery, magnetization.
2. Data set: flattened configurations, labels from T < Tc or T > Tc.
3. Training in pictures: prediction/label/update loop, cross-entropy curve,
   gradient-descent step, and measured changes after ten updates.
4. Batch/epoch and data-split diagrams; full training and validation curves,
   then output and accuracy versus temperature (paper Fig. 1B, 1C).
5. Hidden-layer analysis: weights on the lattice, site-averaged weights, input versus magnetization.
6. Three-neuron toy model with the threshold parameter epsilon (paper Fig. 1D-F).
7. Finite-size scaling collapse for L = 10, 20, 30, 40, 60 (Nature Physics Fig. 1a, 1b).
8. Square-lattice networks applied to the triangular lattice (paper Fig. 2).

## Run

Python 3.12 with NumPy, Matplotlib, Numba and Jupyter. Select
**Restart Kernel → Run All**. No deep-learning library is needed.

Without `ising_ml_data.npz` the notebook generates the configurations:
5 sizes, 40 temperatures, 250 training/validation, 250 test and 250 triangular-lattice
configurations per temperature. This took 70 s on a 14-core Apple M4 Pro.
With the saved data the notebook runs in well under a minute.
Set `recompute = True` after changing sizes, temperatures or sampling parameters.

## Training walkthrough

Sections 3–4 combine six explanatory figures, essential equations, and short
executable examples. Compact symbol tables define notation on first use. Figures show:

1. A real spin picture, predicted probabilities, correct label, loss, and the update loop.
2. Cross-entropy as a function of probability assigned to the correct class.
3. One score update on its loss curve, including the slope and before/after probabilities.
4. Loss and predictions before/after ten updates on eight real configurations.
5. A 12-picture illustration of batches and epochs, distinguished from the full run.
6. The roles of training, validation, and test data.

The full NumPy implementation and drawing functions remain inside the notebook's
setup cell. Its source is collapsed in the HTML and marked as hidden in Jupyter
metadata (some viewers may still show it). Forward pass, cross-entropy, gradient descent, backpropagation, and L2
regularization equations are in the main lesson, with symbols defined beside them.
Further derivations and Adam details are in a collapsible optional appendix. Run every code cell, including setup, in order. No external
Python helper files are required.

For each size, 8,000 examples are used for training and 2,000 for validation, with
whole Monte Carlo chains kept in one split. A separate 10,000-example test set is
evaluated after training. Use validation results to choose settings. Learning curves
compare training/validation loss and accuracy from epoch 0.

## Notes

- Temperature grids: 40 points in [1.0, 3.5] (square) and [2.5, 5.0] (triangular).
  The crossing temperatures are resolved to about one grid spacing (0.064).
- Near Tc, successive Metropolis samples of the larger lattices are correlated.
  Each temperature uses 10 independent chains to limit the effect.
- The paper does not state its temperature window or sample counts; these are
  choices of this notebook, so accuracies differ slightly from the quoted
  94% (L = 10) and 99% (L = 40).

Authoring script: `scripts/ising_ml/build_nb.py`. Saved outputs were produced
with NumPy 2.5.4, Numba 0.68.1 and Matplotlib 3.11.2 on 2026-11-17.
All 21 code cells (17 saved figures) ran in a fresh Python 3.12.12 kernel using the saved data
(about 20 s on the preparation machine). The analytic gradients were checked
against central finite differences. The HTML includes its math-rendering assets.
