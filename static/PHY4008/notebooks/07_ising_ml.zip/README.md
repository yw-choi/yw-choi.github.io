# Machine learning phases of matter: Ising model

Install numpy, matplotlib, and numba, then open 07_ising_ml.ipynb.
Keep ising_ml_data.npz in the notebook working directory and run all cells in order.
The saved configurations avoid repeating the Monte Carlo sampling, which takes
one to a few minutes. Set recompute = True to regenerate them.

Preview:
https://yw-choi.github.io/PHY4008/notebooks/07_ising_ml.html

Course:
https://yw-choi.github.io/PHY4008/
