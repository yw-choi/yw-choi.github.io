# Ising model II

Install numpy, matplotlib, and numba, then open 03_ising_model_2.ipynb.
Keep the .npz file in the notebook working directory and run all cells in order.
The saved scan avoids repeating the several-minute calculation.
Set recompute_scan = True to regenerate it.

Previous lesson:
https://yw-choi.github.io/PHY4008/notebooks/02_ising_model_1.html

Course:
https://yw-choi.github.io/PHY4008/
