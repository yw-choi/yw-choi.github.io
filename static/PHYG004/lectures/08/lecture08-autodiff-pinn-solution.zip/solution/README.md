# Lecture 08 — Solution

## Automatic Differentiation & Physics-Informed Neural Networks

### Setup

```bash
pip install -r requirements.txt
```

### Execution Order

```bash
# Mission A: Autodiff for Physics
cd mission_a_autodiff
python autodiff_physics.py

# Mission B: PINN for Quantum Harmonic Oscillator
cd ../mission_b_pinn_qho
python pinn_schrodinger.py
```

### Expected Results

#### Mission A: Autodiff

| Output | Expected Value |
|--------|---------------|
| Equilibrium distance $r_{\text{eq}}$ | $\approx 1.1225$ ($= 2^{1/6}\sigma$) |
| Hessian eigenvalues (2D potential) | $[1.5, \; 2.5]$ |
| Normal mode frequencies | $[1.225, \; 1.581]$ |

Plots saved to `mission_a_autodiff/results/`.

#### Mission B: PINN

| Output | Expected Value |
|--------|---------------|
| Ground state energy $E_0$ | $\approx 0.500$ (exact: $0.5$) |
| $\psi(x)$ shape | Gaussian, matching $\pi^{-1/4} e^{-x^2/2}$ |

Training: ~8000 steps, ~1-2 min on CPU.
Plots saved to `mission_b_pinn_qho/results/`.
