"""
Automatic Differentiation for Physics with JAX

Demonstrates jax.grad, jax.hessian, and jax.vmap on physics potentials:
  1. Lennard-Jones potential → force, equilibrium distance
  2. 2D potential energy surface → gradient, Hessian, normal modes
  3. Batch computation with vmap
"""

import jax
import jax.numpy as jnp
import matplotlib.pyplot as plt
import os

# ── Step 1: Lennard-Jones potential ──────────────────────────────────────────


def lj_potential(r: float, epsilon: float = 1.0, sigma: float = 1.0) -> float:
    """Lennard-Jones pair potential V(r)."""
    return 4.0 * epsilon * ((sigma / r) ** 12 - (sigma / r) ** 6)


# Force: F(r) = -dV/dr
lj_force = jax.grad(lj_potential)  # returns dV/dr
force_fn = lambda r: -lj_force(r)  # negate for force


def find_equilibrium(r_init: float = 1.5, lr: float = 0.001, n_steps: int = 500) -> float:
    """Find equilibrium distance by minimizing V(r) via gradient descent."""
    r = r_init
    for _ in range(n_steps):
        grad_v = jax.grad(lj_potential)(r)
        r = r - lr * grad_v
    return r


# ── Step 2: 2D potential energy surface ──────────────────────────────────────


def potential_2d(xy: jnp.ndarray) -> float:
    """2D potential: V(x,y) = x² + y² + 0.5xy."""
    x, y = xy
    return x**2 + y**2 + 0.5 * x * y


# Gradient and Hessian
grad_2d = jax.grad(potential_2d)
hessian_2d = jax.hessian(potential_2d)


# ── Step 3: Batch computation with vmap ──────────────────────────────────────

# Vectorize force computation over an array of distances
batch_force = jax.vmap(lambda r: -jax.grad(lj_potential)(r))


# ── Main ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    os.makedirs("results", exist_ok=True)

    # --- Step 1: LJ potential and force ---
    print("=" * 60)
    print("Step 1: Lennard-Jones Potential")
    print("=" * 60)

    r_arr = jnp.linspace(0.9, 3.0, 200)
    v_arr = jax.vmap(lj_potential)(r_arr)
    f_arr = jax.vmap(force_fn)(r_arr)

    r_eq = find_equilibrium()
    r_exact = 2.0 ** (1.0 / 6.0)  # sigma = 1
    print(f"  Equilibrium distance (gradient descent): r_eq = {r_eq:.6f}")
    print(f"  Exact value (2^(1/6)):                   r_eq = {r_exact:.6f}")
    print(f"  Error: {abs(r_eq - r_exact):.2e}")

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))

    ax1.plot(r_arr, v_arr, "b-", linewidth=2)
    ax1.axhline(0, color="gray", linestyle="--", alpha=0.5)
    ax1.axvline(r_eq, color="r", linestyle="--", alpha=0.7, label=f"$r_{{eq}}={r_eq:.3f}$")
    ax1.set_xlabel("$r$")
    ax1.set_ylabel("$V(r)$")
    ax1.set_title("Lennard-Jones Potential")
    ax1.set_ylim(-1.5, 3)
    ax1.legend()

    ax2.plot(r_arr, f_arr, "r-", linewidth=2)
    ax2.axhline(0, color="gray", linestyle="--", alpha=0.5)
    ax2.axvline(r_eq, color="b", linestyle="--", alpha=0.7, label=f"$r_{{eq}}={r_eq:.3f}$")
    ax2.set_xlabel("$r$")
    ax2.set_ylabel("$F(r) = -dV/dr$")
    ax2.set_title("Force from Autodiff")
    ax2.legend()

    plt.tight_layout()
    plt.savefig("results/step1_lj.png", dpi=150)
    plt.close()
    print("  Saved: results/step1_lj.png")

    # --- Step 2: 2D potential, gradient, Hessian ---
    print()
    print("=" * 60)
    print("Step 2: 2D Potential Energy Surface")
    print("=" * 60)

    xy0 = jnp.array([1.0, -0.5])
    grad_val = grad_2d(xy0)
    hess_val = hessian_2d(xy0)
    eigenvalues = jnp.linalg.eigvalsh(hess_val)

    print(f"  Point: {xy0}")
    print(f"  Gradient:  {grad_val}")
    print(f"  Hessian:\n    {hess_val[0]}\n    {hess_val[1]}")
    print(f"  Eigenvalues (normal mode freq²): {eigenvalues}")
    print(f"  Normal mode frequencies: {jnp.sqrt(eigenvalues)}")

    # Contour plot
    x_grid = jnp.linspace(-2, 2, 100)
    y_grid = jnp.linspace(-2, 2, 100)
    X, Y = jnp.meshgrid(x_grid, y_grid)
    Z = jax.vmap(jax.vmap(lambda x, y: potential_2d(jnp.array([x, y])), in_axes=(None, 0)), in_axes=(0, None))(x_grid, y_grid).T

    fig, ax = plt.subplots(figsize=(6, 5))
    cs = ax.contourf(X, Y, Z, levels=30, cmap="viridis")
    plt.colorbar(cs, ax=ax, label="$V(x,y)$")
    ax.plot(*xy0, "ro", markersize=8)
    ax.quiver(*xy0, *(-grad_val * 0.3), color="red", scale=1, scale_units="xy", angles="xy", width=0.01)
    ax.set_xlabel("$x$")
    ax.set_ylabel("$y$")
    ax.set_title("2D Potential + Force Vector")
    plt.tight_layout()
    plt.savefig("results/step2_2d_potential.png", dpi=150)
    plt.close()
    print("  Saved: results/step2_2d_potential.png")

    # --- Step 3: Batch force with vmap ---
    print()
    print("=" * 60)
    print("Step 3: Batch Force Computation with vmap")
    print("=" * 60)

    r_batch = jnp.linspace(1.0, 3.0, 10)
    forces = batch_force(r_batch)

    print(f"  {'r':>8s}  {'F(r)':>10s}")
    print(f"  {'-'*8}  {'-'*10}")
    for r_val, f_val in zip(r_batch, forces):
        print(f"  {r_val:8.4f}  {f_val:10.6f}")

    print()
    print("Done!")
