# Lecture 08: Automatic Differentiation & Physics-Informed Neural Networks

## Overview

In this hands-on session, you'll use **JAX's automatic differentiation** to compute exact derivatives of physics functions, then apply it to build a **Physics-Informed Neural Network** (PINN) that solves the quantum harmonic oscillator.

| Mission | Topic | Time | Difficulty |
|---------|-------|------|------------|
| A | JAX autodiff: `grad`, `hessian`, `vmap` | 20 min | Easy |
| B | PINN for the Schrödinger equation | 30 min | Medium |

## Setup

### 1. Create a virtual environment and install dependencies

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 2. Open in VS Code with Copilot

```bash
code .
```

Make sure **GitHub Copilot Chat** is enabled. Use **Agent mode** (Ctrl+L → select "Agent") for best results.

## How to Work with Copilot Agent

1. **Open the mission README** (e.g., `mission_a_autodiff/README_en.md`)
2. **Read the step description** and the "Ask Copilot" prompt
3. **Copy the prompt** into Copilot Chat (or write your own)
4. **Review** what Copilot generates — don't accept blindly
5. **Run the script** to verify: `python autodiff_physics.py`
6. **Check the checkpoint** criteria
7. **Commit** after each step: `git add -A && git commit -m "Step N done"`

### Tips for Good Prompts

- **Include physics context**: "The force is $F = -dV/dr$" is better than "compute the derivative"
- **Mention the specific JAX function**: "Use `jax.grad` with `argnums=1`"
- **Reference existing code**: "The function `lj_potential` is already defined above"

## Missions

### Mission A: Autodiff for Physics (20 min)

Directory: `mission_a_autodiff/`

Implement 3 TODOs in `autodiff_physics.py`:
1. Force from LJ potential via `jax.grad`
2. Gradient + Hessian of a 2D potential
3. Batch force computation with `jax.vmap`

See `mission_a_autodiff/README_en.md` for step-by-step guide.

### Mission B: PINN for Quantum Harmonic Oscillator (30 min)

Directory: `mission_b_pinn_qho/`

Implement 3 TODOs in `pinn_schrodinger.py`:
1. Second derivative $\psi''(x)$ via autodiff
2. PINN loss function (PDE residual + normalization + boundary)
3. Training step with gradient updates

See `mission_b_pinn_qho/README_en.md` for step-by-step guide.

## Submission & Grading

- Push your completed code to your repo in `sogang-physics/2026-ml-{name}`
- Grading values **process** (git history, incremental commits) over just the final result
- Include the output plots in `results/` directories
