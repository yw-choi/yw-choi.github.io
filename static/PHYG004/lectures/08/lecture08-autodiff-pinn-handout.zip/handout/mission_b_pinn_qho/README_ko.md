# Mission B: PINN으로 양자 조화 진동자 풀기 (30분)

## 배경

**물리 정보 기반 신경망** (PINN)은 신경망을 미분방정식의 시행 해(trial solution)로 사용합니다. 데이터로 학습하는 대신, 방정식 자체를 만족하도록 학습시킵니다 — 손실 함수가 PDE 잔차(residual)가 얼마나 0에 가까운지를 측정합니다.

이 미션에서는 양자 조화 진동자의 1D 슈뢰딩거 방정식을 풉니다:

$$-\frac{1}{2}\psi''(x) + \frac{1}{2}x^2\psi(x) = E\,\psi(x)$$

네트워크가 $\psi(x)$를 출력하고, autodiff가 $\psi''(x)$를 계산합니다. 에너지 $E$는 네트워크 가중치와 함께 학습되는 매개변수입니다.

**정확한 바닥상태**: $E_0 = 0.5$, $\psi_0(x) = \pi^{-1/4}\exp(-x^2/2)$

## 이미 제공된 것

스캐폴드(`pinn_schrodinger.py`)에 포함:
- MLP 정의 (`init_mlp`, `mlp_forward`) — hidden layer 3개, 64 유닛, tanh
- `psi_fn(params, x)` — 네트워크 순전파
- Adam optimizer 학습 루프
- 정확한 해와 비교하는 시각화 코드
- 정확한 해 `psi_exact(x)`

**구현할 함수 3개** (TODO 1–3).

## Step 1: Autodiff로 이계도함수 계산

**목표**: `jax.grad`를 사용해 $\psi''(x)$를 계산하는 `psi_xx_fn(params, x)` 구현

**Copilot에게 요청**:

> "`pinn_schrodinger.py`에서 TODO 1을 구현해줘: `psi_xx_fn(params, x)`를 정의해서 이계도함수 $\psi''(x)$를 계산해. `psi_fn`에 `jax.grad`를 `argnums=1`로 두 번 적용해서 $x$에 대해 미분해 (네트워크 파라미터가 아니라)."

**체크포인트**:
- [ ] `psi_xx_fn(params, 0.0)`이 유한한 숫자 반환 (0.0이 아님)
- [ ] 미분이 네트워크 파라미터가 아닌 $x$에 대한 것

**물리적 해석**: 이것이 PINN의 핵심 통찰입니다 — autodiff가 네트워크 출력을 *입력* $x$에 대해 미분하여 PDE에 나타나는 도함수를 제공합니다. 유한 차분이 필요 없습니다.

## Step 2: PINN 손실 함수

**목표**: 세 가지 성분으로 구성된 `pinn_loss(params, E, x_grid)` 구현

손실 함수의 세 부분:

$$\mathcal{L}_{\text{pde}} = \frac{1}{N}\sum_i \left| -\frac{1}{2}\psi''(x_i) + \frac{1}{2}x_i^2\psi(x_i) - E\,\psi(x_i) \right|^2$$

$$\mathcal{L}_{\text{norm}} = \left(\int\psi(x)^2\,dx - 1\right)^2$$

$$\mathcal{L}_{\text{bc}} = \psi(x_{\min})^2 + \psi(x_{\max})^2$$

$$\mathcal{L} = \mathcal{L}_{\text{pde}} + 10\,\mathcal{L}_{\text{norm}} + 5\,\mathcal{L}_{\text{bc}}$$

**Copilot에게 요청**:

> "`pinn_schrodinger.py`에서 TODO 2를 구현해줘: `pinn_loss` 함수. 다음을 해야 해:
> 1. `jax.vmap`으로 모든 격자점에서 ψ와 ψ'' 계산
> 2. PDE 잔차 계산: $-\psi''/2 + x^2\psi/2 - E\psi$
> 3. `L_pde` = 잔차의 평균 제곱
> 4. `L_norm` = (`jnp.trapezoid`로 ψ²의 사다리꼴 적분 - 1)²
> 5. `L_bc` = ψ(x_min)² + ψ(x_max)²
> 6. `L_pde + 10*L_norm + 5*L_bc` 반환"

**체크포인트**:
- [ ] `pinn_loss(params, 0.3, x_grid)`가 유한한 양수 반환
- [ ] 학습 중 손실이 감소

**물리적 해석**:
- $\mathcal{L}_{\text{pde}}$: 샘플 점에서 슈뢰딩거 방정식 강제
- $\mathcal{L}_{\text{norm}}$: $\langle\psi|\psi\rangle = 1$ 강제
- $\mathcal{L}_{\text{bc}}$: 경계에서 $\psi \to 0$ 강제 (속박 상태 조건)
- 가중치 (10, 5)는 이 목적들의 균형을 맞춤 — 없으면 최적화기가 규격화를 $\psi = 0$으로 자명하게 만족시킬 수 있음

## Step 3: 학습 단계

**목표**: `params`와 `E` 모두의 기울기를 계산하고 업데이트하는 `train_step` 구현

**Copilot에게 요청**:

> "`pinn_schrodinger.py`에서 TODO 3을 구현해줘: `train_step` 함수. `jax.value_and_grad(pinn_loss, argnums=(0, 1))`을 사용해서 `params`(네트워크 가중치)와 `E`(에너지) 모두에 대한 손실과 기울기를 계산해. 그다음 두 가지 모두에 optimizer 업데이트를 적용해."

**체크포인트**:
- [ ] 학습이 오류 없이 실행
- [ ] 8000 스텝 동안 손실이 ~4000에서 < 0.01로 감소
- [ ] $E$가 $\approx 0.500$으로 수렴 (정확값: $0.5$)
- [ ] $\psi(x)$가 정확한 해의 가우시안 형태와 일치

## 완료 기준

- [ ] 세 개의 TODO 모두 구현
- [ ] `python pinn_schrodinger.py`가 ~1–2분 내 완료
- [ ] 최종 $E$가 0.5의 0.01 이내
- [ ] `results/pinn_qho.png`에 저장된 그래프가 좋은 일치 보임
- [ ] 변경 사항 커밋

## 확장 (시간이 남으면)

- 무한 사각 우물로 퍼텐셜 변경: $|x| < L/2$에서 $V(x) = 0$, 그 외 $\infty$. (힌트: 우물 밖에서 매우 큰 $V$ 사용)
- 이중 우물 퍼텐셜 시도: $V(x) = (x^2 - 1)^2$. 어떤 바닥상태 에너지가 나오는가?
