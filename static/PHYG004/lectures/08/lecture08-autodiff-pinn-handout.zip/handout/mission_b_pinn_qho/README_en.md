# Mission B: PINN for the Quantum Harmonic Oscillator (30 min)

## Background

A **Physics-Informed Neural Network** (PINN) uses a neural network as a trial solution to a differential equation. Instead of training on data, you train the network to satisfy the equation itself — the loss function measures how well the PDE residual vanishes.

In this mission, you'll solve the 1D Schrödinger equation for the quantum harmonic oscillator:

$$-\frac{1}{2}\psi''(x) + \frac{1}{2}x^2\psi(x) = E\,\psi(x)$$

The network outputs $\psi(x)$, and autodiff computes $\psi''(x)$. The energy $E$ is a trainable parameter that the optimizer discovers alongside the network weights.

**Exact ground state**: $E_0 = 0.5$, $\psi_0(x) = \pi^{-1/4}\exp(-x^2/2)$

## What's Already Provided

The scaffold (`pinn_schrodinger.py`) gives you:
- MLP definition (`init_mlp`, `mlp_forward`) — 3 hidden layers, 64 units, tanh
- `psi_fn(params, x)` — network forward pass
- Training loop with Adam optimizer
- Plotting code comparing your result to the exact solution
- Exact solution `psi_exact(x)`

**You implement 3 functions** (TODOs 1–3).

## Step 1: Second Derivative via Autodiff

**Goal**: Implement `psi_xx_fn(params, x)` that computes $\psi''(x)$ using `jax.grad`.

**Ask Copilot**:

> "Implement TODO 1 in `pinn_schrodinger.py`: define `psi_xx_fn(params, x)` that computes the second derivative $\psi''(x)$. Apply `jax.grad` twice to `psi_fn` with `argnums=1` to differentiate with respect to $x$ (not the network params)."

**Checkpoint**:
- [ ] `psi_xx_fn(params, 0.0)` returns a finite number (not 0.0)
- [ ] The derivative is with respect to $x$, not the network parameters

**Physics interpretation**: This is the key insight of PINNs — autodiff differentiates the network output with respect to its *input* $x$, giving you the derivatives that appear in the PDE. No finite differences needed.

## Step 2: PINN Loss Function

**Goal**: Implement `pinn_loss(params, E, x_grid)` with three components.

The loss has three parts:

$$\mathcal{L}_{\text{pde}} = \frac{1}{N}\sum_i \left| -\frac{1}{2}\psi''(x_i) + \frac{1}{2}x_i^2\psi(x_i) - E\,\psi(x_i) \right|^2$$

$$\mathcal{L}_{\text{norm}} = \left(\int\psi(x)^2\,dx - 1\right)^2$$

$$\mathcal{L}_{\text{bc}} = \psi(x_{\min})^2 + \psi(x_{\max})^2$$

$$\mathcal{L} = \mathcal{L}_{\text{pde}} + 10\,\mathcal{L}_{\text{norm}} + 5\,\mathcal{L}_{\text{bc}}$$

**Ask Copilot**:

> "Implement TODO 2 in `pinn_schrodinger.py`: the `pinn_loss` function. It should:
> 1. Compute ψ and ψ'' at all grid points using `jax.vmap`
> 2. Compute the PDE residual: $-\psi''/2 + x^2\psi/2 - E\psi$
> 3. `L_pde` = mean squared residual
> 4. `L_norm` = (trapezoidal integral of ψ² - 1)² using `jnp.trapezoid`
> 5. `L_bc` = ψ(x_min)² + ψ(x_max)²
> 6. Return `L_pde + 10*L_norm + 5*L_bc`"

**Checkpoint**:
- [ ] `pinn_loss(params, 0.3, x_grid)` returns a finite positive number
- [ ] The loss decreases during training

**Physics interpretation**:
- $\mathcal{L}_{\text{pde}}$ enforces the Schrödinger equation at sample points
- $\mathcal{L}_{\text{norm}}$ enforces $\langle\psi|\psi\rangle = 1$
- $\mathcal{L}_{\text{bc}}$ enforces $\psi \to 0$ at the boundaries (bound state condition)
- The weights (10, 5) balance these objectives — without them, the optimizer may satisfy normalization trivially ($\psi = 0$ everywhere)

## Step 3: Training Step

**Goal**: Implement `train_step` that computes gradients and updates both `params` and `E`.

**Ask Copilot**:

> "Implement TODO 3 in `pinn_schrodinger.py`: the `train_step` function. Use `jax.value_and_grad(pinn_loss, argnums=(0, 1))` to compute the loss and gradients with respect to both `params` (network weights) and `E` (energy). Then apply the optimizer updates to both."

**Checkpoint**:
- [ ] Training runs without errors
- [ ] Loss decreases from ~4000 to < 0.01 over 8000 steps
- [ ] $E$ converges to $\approx 0.500$ (exact: $0.5$)
- [ ] $\psi(x)$ matches the Gaussian shape of the exact solution

## Completion Criteria

- [ ] All three TODOs implemented
- [ ] `python pinn_schrodinger.py` completes in ~1–2 min
- [ ] Final $E$ within 0.01 of 0.5
- [ ] Plot saved to `results/pinn_qho.png` shows good agreement
- [ ] Commit your changes

## Extension (if time permits)

- Change the potential to an infinite square well: $V(x) = 0$ for $|x| < L/2$, $\infty$ otherwise. (Hint: use a very large $V$ outside the well.)
- Try a double-well potential: $V(x) = (x^2 - 1)^2$. What ground state energy do you get?
