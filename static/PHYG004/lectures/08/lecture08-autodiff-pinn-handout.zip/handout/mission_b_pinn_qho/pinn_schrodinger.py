"""
Physics-Informed Neural Network for the 1D Quantum Harmonic Oscillator

Solves the time-independent Schrödinger equation (atomic units):
    -1/2 ψ''(x) + 1/2 x² ψ(x) = E ψ(x)

Exact ground state: E₀ = 0.5, ψ₀(x) = π^(-1/4) exp(-x²/2)

Reference: Jin et al., "PINNs for Quantum Eigenvalue Problems" (2022)
           arXiv:2203.00451
"""

import jax
import jax.numpy as jnp
import optax
import matplotlib.pyplot as plt
import os

# ── Hyperparameters ──────────────────────────────────────────────────────────

SEED = 42
HIDDEN_DIM = 64
N_LAYERS = 3
N_COLLOC = 300          # fixed grid points
X_MIN, X_MAX = -5.0, 5.0
LEARNING_RATE = 1e-3
N_STEPS = 8000
PRINT_EVERY = 1000

# ── MLP Definition (pure JAX) ───────────────────────────────────────────────


def init_mlp(key, layer_sizes):
    """Initialize MLP parameters: list of (W, b) tuples."""
    params = []
    for in_dim, out_dim in zip(layer_sizes[:-1], layer_sizes[1:]):
        key, subkey = jax.random.split(key)
        scale = jnp.sqrt(2.0 / in_dim)
        W = scale * jax.random.normal(subkey, (in_dim, out_dim))
        b = jnp.zeros(out_dim)
        params.append((W, b))
    return params


def mlp_forward(params, x_scalar):
    """Forward pass: scalar x → scalar output."""
    h = jnp.array([x_scalar])  # shape (1,)
    for W, b in params[:-1]:
        h = jnp.tanh(h @ W + b)
    W_last, b_last = params[-1]
    return jnp.squeeze(h @ W_last + b_last)


# ── Core PINN Functions ─────────────────────────────────────────────────────


def psi_fn(params, x):
    """ψ(x): neural network output."""
    return mlp_forward(params, x)


# TODO 1: Implement psi_xx_fn — the second derivative ψ''(x) via autodiff
# Hint: apply jax.grad twice with argnums=1 (differentiate w.r.t. x, not params)
#   dpsi_dx = jax.grad(psi_fn, argnums=1)
#   d2psi_dx2 = jax.grad(dpsi_dx, argnums=1)
def psi_xx_fn(params, x):
    """ψ''(x): second derivative via autodiff."""
    raise NotImplementedError("TODO 1: apply jax.grad twice with argnums=1")


# TODO 2: Implement the PINN loss function
# The loss has three parts:
#   L_pde  = mean(|-ψ''/2 + x²ψ/2 - Eψ|²)   (PDE residual at collocation points)
#   L_norm = (∫ψ² dx - 1)²                     (normalization constraint)
#   L_bc   = ψ(x_min)² + ψ(x_max)²            (boundary decay)
#   Total: L = L_pde + 10 * L_norm + 5 * L_bc
#
# Hint: use jax.vmap(psi_fn, in_axes=(None, 0)) to vectorize over x_grid
#       use jnp.trapezoid(psi_vals**2, x_grid) for the normalization integral
def pinn_loss(params, E, x_grid):
    """Total PINN loss for the Schrödinger equation."""
    raise NotImplementedError("TODO 2: implement L_pde + 10*L_norm + 5*L_bc")


# TODO 3: Implement the training step
# Hint: use jax.value_and_grad(pinn_loss, argnums=(0, 1)) to get gradients
#       w.r.t. both params and E simultaneously.
#       Then apply optimizer updates to both.
def train_step(params, E, opt_state_params, opt_state_E, x_grid,
               optimizer_params, optimizer_E):
    """Single training step: compute gradients and update params + E."""
    raise NotImplementedError("TODO 3: use jax.value_and_grad with argnums=(0, 1)")


# ── Exact Solution ───────────────────────────────────────────────────────────


def psi_exact(x):
    """Exact ground state: ψ₀(x) = π^(-1/4) exp(-x²/2)."""
    return jnp.pi ** (-0.25) * jnp.exp(-0.5 * x**2)


# ── Main ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    os.makedirs("results", exist_ok=True)

    key = jax.random.PRNGKey(SEED)

    # Initialize network
    layer_sizes = [1] + [HIDDEN_DIM] * N_LAYERS + [1]
    key, subkey = jax.random.split(key)
    params = init_mlp(subkey, layer_sizes)

    # Initialize energy (start with a guess below ground state)
    E = 0.3

    # Fixed collocation grid (stable for integration)
    x_grid = jnp.linspace(X_MIN, X_MAX, N_COLLOC)

    # Optimizers
    optimizer_params = optax.adam(LEARNING_RATE)
    optimizer_E = optax.adam(LEARNING_RATE)
    opt_state_params = optimizer_params.init(params)
    opt_state_E = optimizer_E.init(E)

    # JIT compile the training step
    train_step_jit = jax.jit(train_step, static_argnums=(5, 6))

    # Training
    print("=" * 60)
    print("Training PINN for Quantum Harmonic Oscillator")
    print("=" * 60)

    loss_history = []
    E_history = []

    for step in range(N_STEPS):
        params, E, opt_state_params, opt_state_E, loss = train_step_jit(
            params, E, opt_state_params, opt_state_E, x_grid,
            optimizer_params, optimizer_E,
        )

        loss_history.append(float(loss))
        E_history.append(float(E))

        if step % PRINT_EVERY == 0 or step == N_STEPS - 1:
            print(f"  Step {step:5d} | Loss = {loss:.6f} | E = {float(E):.6f}")

    print(f"\n  Final E = {float(E):.6f}  (exact: 0.5)")
    print(f"  Error: |E - 0.5| = {abs(float(E) - 0.5):.6f}")

    # ── Plotting ─────────────────────────────────────────────────────────────

    x_plot = jnp.linspace(X_MIN, X_MAX, 500)
    psi_nn = jax.vmap(psi_fn, in_axes=(None, 0))(params, x_plot)
    psi_ex = psi_exact(x_plot)

    # Fix sign ambiguity: align sign with exact solution
    if jnp.sum(psi_nn * psi_ex) < 0:
        psi_nn = -psi_nn

    fig, axes = plt.subplots(1, 3, figsize=(14, 4))

    # (a) Wavefunction comparison
    axes[0].plot(x_plot, psi_ex, "b-", linewidth=2, label="Exact $\\psi_0(x)$")
    axes[0].plot(x_plot, psi_nn, "r--", linewidth=2, label="PINN $\\psi_\\theta(x)$")
    axes[0].set_xlabel("$x$")
    axes[0].set_ylabel("$\\psi(x)$")
    axes[0].set_title("Wavefunction")
    axes[0].legend()

    # (b) Energy convergence
    axes[1].plot(E_history, "g-", linewidth=1)
    axes[1].axhline(0.5, color="k", linestyle="--", alpha=0.7, label="$E_0 = 0.5$")
    axes[1].set_xlabel("Step")
    axes[1].set_ylabel("$E$")
    axes[1].set_title("Energy Convergence")
    axes[1].legend()

    # (c) Loss curve
    axes[2].semilogy(loss_history, "m-", linewidth=1)
    axes[2].set_xlabel("Step")
    axes[2].set_ylabel("Loss")
    axes[2].set_title("Training Loss")

    plt.tight_layout()
    plt.savefig("results/pinn_qho.png", dpi=150)
    plt.close()
    print("  Saved: results/pinn_qho.png")
    print("\nDone!")
