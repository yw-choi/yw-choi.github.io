# Mission A: 물리학을 위한 자동 미분 (20분)

## 배경

물리학에서 미분은 일상입니다: 퍼텐셜에서 힘, 라그랑지안에서 운동방정식, 자유에너지에서 응답함수. **자동 미분** (autodiff)을 사용하면 어떤 Python 함수든 정확한 미분값을 계산할 수 있습니다 — 유한 차분도, 기호 미분도 필요 없습니다.

JAX의 `jax.grad`는 함수를 첫 번째 인자에 대해 미분합니다. 합성도 가능합니다: `grad(grad(f))`는 이계도함수, `jax.hessian`은 전체 Hessian 행렬, `jax.vmap`은 배치 벡터화를 제공합니다.

이 미션에서는 두 가지 물리 퍼텐셜에 이 도구들을 사용합니다.

## Step 1: Lennard-Jones 퍼텐셜로부터 힘 계산

**목표**: `jax.grad`를 사용해 $F(r) = -\frac{dV}{dr}$ 계산

Lennard-Jones 퍼텐셜:

$$V(r) = 4\varepsilon \left[ \left(\frac{\sigma}{r}\right)^{12} - \left(\frac{\sigma}{r}\right)^{6} \right]$$

**Copilot에게 요청**:

> "`autodiff_physics.py`에서 TODO 1을 구현해줘: `jax.grad`를 사용해서 Lennard-Jones 퍼텐셜의 힘 $F(r) = -dV/dr$을 계산하는 `force_fn`을 정의해. `lj_potential(r)` 함수는 이미 정의되어 있어."

**체크포인트**:
- [ ] `force_fn(1.0)`이 0이 아닌 값 반환 ($\approx +24.0$, 반발력)
- [ ] `force_fn(2.0)`이 작은 음수 반환 (인력)
- [ ] 힘 그래프에서 $r \approx 1.12$에서 $F = 0$

**물리적 해석**: 힘이 0인 평형 거리는 $r_{\text{eq}} = 2^{1/6}\sigma \approx 1.122$입니다. `find_equilibrium` 함수는 $V(r)$에 대한 경사 하강법으로 이를 찾습니다 — `jax.grad(V)`가 정확한 기울기를 주기 때문에 가능합니다.

## Step 2: Hessian과 고유진동 모드

**목표**: 2D 퍼텐셜의 기울기 벡터와 Hessian 행렬 계산, 고유진동수 추출

2D 퍼텐셜:

$$V(x, y) = x^2 + y^2 + \tfrac{1}{2}xy$$

**Copilot에게 요청**:

> "TODO 2를 구현해줘: `jax.grad(potential_2d)`로 `grad_2d`를, `jax.hessian(potential_2d)`로 `hessian_2d`를 정의해. 각각 퍼텐셜의 기울기 벡터와 $2 \times 2$ Hessian 행렬을 계산하는 함수야."

**체크포인트**:
- [ ] `grad_2d(jnp.array([1.0, -0.5]))`가 `[1.75, -0.5]` 반환
- [ ] Hessian 행렬이 `[[2.0, 0.5], [0.5, 2.0]]` (이차 퍼텐셜이므로 상수)
- [ ] 고유값이 `[1.5, 2.5]`
- [ ] 등고선 그래프에서 기울기 벡터가 아래쪽을 가리킴

**물리적 해석**: Hessian의 고유값은 고유진동 모드의 주파수 제곱 $\omega_i^2$입니다. 결정 격자에서는 이것이 역학 행렬(dynamical matrix)로 일반화됩니다 — autodiff를 사용하면 아무리 복잡한 퍼텐셜이라도 이를 계산할 수 있습니다.

## Step 3: vmap으로 배치 계산

**목표**: `jax.vmap`으로 여러 거리에서 힘을 동시에 계산

**Copilot에게 요청**:

> "TODO 3을 구현해줘: `jax.vmap`을 사용해서 단일 점 힘 계산을 거리 배열 전체로 벡터화하는 `batch_force`를 정의해. $r$ 값 배열을 받아서 힘 배열을 반환해야 해."

**체크포인트**:
- [ ] `batch_force(jnp.linspace(1.0, 3.0, 10))`이 10개의 힘 값 배열 반환
- [ ] $r = 1.0$ 근처에서 큰 양수 (반발력), $r = 3.0$ 근처에서 작은 음수 (인력)

**물리적 해석**: `jax.vmap`은 수동 for문을 없앱니다. `jax.grad`와 결합하면 분자동역학 궤적 전체에 대한 힘을 한 번의 벡터화된 호출로 계산할 수 있습니다. 이것이 바로 JAX MD (Schoenholz & Cubuk, 2020)의 작동 방식입니다.

## 완료 기준

- [ ] 세 개의 TODO 모두 구현
- [ ] `python autodiff_physics.py` 오류 없이 실행
- [ ] `results/`에 두 개의 그래프 저장
- [ ] 평형 거리가 $2^{1/6} \approx 1.1225$와 일치
- [ ] 변경 사항 커밋
