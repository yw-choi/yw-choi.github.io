# Mission A: Automatic Differentiation for Physics (20 min)

## Background

In physics, we constantly compute derivatives: forces from potentials, equations of motion from Lagrangians, response functions from free energies. **Automatic differentiation** (autodiff) lets us compute exact derivatives of any Python function — no finite differences, no symbolic math.

JAX provides `jax.grad` which differentiates a function with respect to its first argument. You can compose it: `grad(grad(f))` gives the second derivative. `jax.hessian` gives the full Hessian matrix. `jax.vmap` vectorizes any function over a batch of inputs.

In this mission, you'll use these tools on two physics potentials.

## Step 1: Force from the Lennard-Jones Potential

**Goal**: Compute $F(r) = -\frac{dV}{dr}$ using `jax.grad`.

The Lennard-Jones potential is:

$$V(r) = 4\varepsilon \left[ \left(\frac{\sigma}{r}\right)^{12} - \left(\frac{\sigma}{r}\right)^{6} \right]$$

**Ask Copilot**:

> "In `autodiff_physics.py`, implement TODO 1: define `force_fn` that computes the force $F(r) = -dV/dr$ from the Lennard-Jones potential using `jax.grad`. The function `lj_potential(r)` is already defined."

**Checkpoint**:
- [ ] `force_fn(1.0)` returns a nonzero value (should be $\approx +24.0$, repulsive)
- [ ] `force_fn(2.0)` returns a small negative value (attractive)
- [ ] The force plot shows $F = 0$ at $r \approx 1.12$

**Physics interpretation**: The equilibrium distance where $F = 0$ is $r_{\text{eq}} = 2^{1/6}\sigma \approx 1.122$. The `find_equilibrium` function uses gradient descent on $V(r)$ to find this — it works because `jax.grad(V)` gives the exact gradient.

## Step 2: Hessian and Normal Modes

**Goal**: Compute the gradient and Hessian of a 2D potential, extract normal mode frequencies.

The 2D potential is:

$$V(x, y) = x^2 + y^2 + \tfrac{1}{2}xy$$

**Ask Copilot**:

> "Implement TODO 2: define `grad_2d` using `jax.grad(potential_2d)` and `hessian_2d` using `jax.hessian(potential_2d)`. These compute the gradient vector and the $2 \times 2$ Hessian matrix of the potential."

**Checkpoint**:
- [ ] `grad_2d(jnp.array([1.0, -0.5]))` returns `[1.75, -0.5]`
- [ ] Hessian matrix is `[[2.0, 0.5], [0.5, 2.0]]` (constant — it's a quadratic potential)
- [ ] Eigenvalues are `[1.5, 2.5]`
- [ ] The contour plot shows the gradient vector pointing downhill

**Physics interpretation**: The Hessian eigenvalues are the squared normal mode frequencies $\omega_i^2$. In a harmonic crystal, this generalizes to the dynamical matrix — autodiff can compute it for any potential, no matter how complex.

## Step 3: Batch Computation with vmap

**Goal**: Compute forces at many distances simultaneously using `jax.vmap`.

**Ask Copilot**:

> "Implement TODO 3: define `batch_force` using `jax.vmap` to vectorize the single-point force computation over an array of distances. The function should take an array of $r$ values and return an array of forces."

**Checkpoint**:
- [ ] `batch_force(jnp.linspace(1.0, 3.0, 10))` returns an array of 10 force values
- [ ] Forces are large positive (repulsive) near $r = 1.0$ and small negative (attractive) near $r = 3.0$

**Physics interpretation**: `jax.vmap` eliminates the need for manual for-loops. Combined with `jax.grad`, you can compute forces for an entire molecular dynamics trajectory in one vectorized call. This is exactly how JAX MD (Schoenholz & Cubuk, 2020) works.

## Completion Criteria

- [ ] All three TODOs implemented
- [ ] `python autodiff_physics.py` runs without errors
- [ ] Two plots saved in `results/`
- [ ] Equilibrium distance matches $2^{1/6} \approx 1.1225$
- [ ] Commit your changes
