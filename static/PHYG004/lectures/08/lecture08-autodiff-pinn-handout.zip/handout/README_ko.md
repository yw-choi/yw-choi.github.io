# Lecture 08: 자동 미분 & 물리 정보 기반 신경망

## 개요

이번 실습에서는 **JAX의 자동 미분**으로 물리 함수의 정확한 도함수를 계산하고, 이를 활용해 양자 조화 진동자를 푸는 **물리 정보 기반 신경망** (PINN)을 구현합니다.

| 미션 | 주제 | 시간 | 난이도 |
|------|------|------|--------|
| A | JAX autodiff: `grad`, `hessian`, `vmap` | 20분 | 쉬움 |
| B | 슈뢰딩거 방정식을 위한 PINN | 30분 | 보통 |

## 준비

### 1. 가상 환경 생성 및 의존성 설치

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 2. VS Code에서 열기 (Copilot 사용)

```bash
code .
```

**GitHub Copilot Chat**이 활성화되어 있는지 확인하세요. 최적의 결과를 위해 **Agent 모드** (Ctrl+L → "Agent" 선택)를 사용하세요.

## Copilot Agent 사용법

1. **미션 README 열기** (예: `mission_a_autodiff/README_ko.md`)
2. **단계 설명**과 "Copilot에게 요청" 프롬프트 읽기
3. Copilot Chat에 **프롬프트 복사** (또는 직접 작성)
4. Copilot이 생성한 코드 **검토** — 무조건 수락하지 않기
5. 스크립트 **실행**으로 확인: `python autodiff_physics.py`
6. **체크포인트** 기준 확인
7. 각 단계 후 **커밋**: `git add -A && git commit -m "Step N done"`

### 좋은 프롬프트 작성 팁

- **물리적 맥락 포함**: "힘은 $F = -dV/dr$" 이 "도함수를 계산해"보다 좋음
- **JAX 함수 명시**: "`argnums=1`로 `jax.grad` 사용"
- **기존 코드 참조**: "위에 정의된 `lj_potential` 함수 사용"

## 미션

### Mission A: 물리를 위한 Autodiff (20분)

디렉토리: `mission_a_autodiff/`

`autodiff_physics.py`에서 TODO 3개 구현:
1. `jax.grad`로 LJ 퍼텐셜에서 힘 계산
2. 2D 퍼텐셜의 기울기 + Hessian
3. `jax.vmap`으로 배치 힘 계산

단계별 가이드: `mission_a_autodiff/README_ko.md`

### Mission B: 양자 조화 진동자를 위한 PINN (30분)

디렉토리: `mission_b_pinn_qho/`

`pinn_schrodinger.py`에서 TODO 3개 구현:
1. Autodiff로 이계도함수 $\psi''(x)$ 계산
2. PINN 손실 함수 (PDE 잔차 + 규격화 + 경계 조건)
3. 기울기 업데이트로 학습 단계 구현

단계별 가이드: `mission_b_pinn_qho/README_ko.md`

## 제출 및 평가

- 완성된 코드를 `sogang-physics/2026-ml-{name}` 레포에 push
- **과정** (git 히스토리, 점진적 커밋)이 최종 결과만큼 중요
- `results/` 디렉토리의 출력 그래프 포함
