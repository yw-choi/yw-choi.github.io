# Step 0 — Bigram Language Model by Counting

> "Counting is the closed-form solution for a model that has no
> attention, no MLP, and an 'embedding' that is just a row in a lookup
> table." — Karpathy

## Background

Before any neural network, the simplest possible language model is a
**bigram count table**: `state_dict[i][j]` is the number of times token
`j` followed token `i` in the training data. To predict what comes next
after token `i`, you look up row `i` and normalize.

The remarkable thing is that this trivial model already shares the same
**outer skeleton** as a GPT — you tokenize, you do a "forward pass" that
returns a distribution, you update parameters per document, and you
sample autoregressively at inference time. From Step 1 onwards we keep
the skeleton and only change *what's inside the model box*.

### The math

For a sequence of tokens $t_0, t_1, \ldots, t_n$ the model assigns

$$p(t_{k+1} \mid t_k) = \frac{c_{t_k, t_{k+1}} + 1}{\sum_j c_{t_k, j} + V}$$

where $c_{ij}$ is the count and $V$ is the vocab size. The "+1" in the
numerator and "+V" in the denominator are **Laplace smoothing** — they
keep the log-probability finite for tokens that were never seen
following $t_k$.

The training loss is the average cross-entropy:

$$\mathcal{L} = -\frac{1}{n} \sum_{k=0}^{n-1} \log p(t_{k+1} \mid t_k)$$

For this model, the closed-form minimizer of $\mathcal{L}$ over the
training set is **counting** — no gradient descent needed. (Try to
prove this in 5 lines!)

## What you fill in

Open `scaffold.py` and complete four TODOs:

| # | What | Hint |
|---|------|------|
| 1 | `bigram(token_id)` — Laplace-smoothed row lookup | one list comprehension |
| 2 | Forward pass — average cross-entropy of a document | `-math.log(probs[target_id])` |
| 3 | Update — bump the count `state_dict[token_id][target_id] += 1` | one line |
| 4 | Inference — sample autoregressively from BOS | `random.choices(range(vocab_size), weights=bigram(token_id))[0]` |

## Ask Copilot

> "In `scaffold.py`, fill in TODO 1: implement `bigram(token_id)` that
> returns a length-`vocab_size` probability distribution over the next
> token using add-one Laplace smoothing on `state_dict[token_id]`."

> "Now fill in TODO 2 and TODO 3: in the training loop, compute the
> average cross-entropy loss for the document by calling `bigram` at
> each position, and then update `state_dict` by incrementing the
> bigram counts."

> "Finally fill in TODO 4: sample 20 names from the trained bigram
> model. Start at BOS, sample the next token using
> `random.choices(range(vocab_size), weights=bigram(token_id))[0]`,
> stop when BOS is emitted or after 16 characters."

## Run

```bash
python scaffold.py
```

## Checkpoint

- [ ] First step prints `loss` around **3.30** (close to $\log V$ — random)
- [ ] Last step prints `loss` around **2.40**
- [ ] The 20 sampled names look like *plausible* names — short, mostly
      consonant–vowel alternation, no impossible tri-grams like `xxq`
- [ ] You did not import `numpy`, `torch`, or any third-party library
- [ ] Commit: `git add -A && git commit -m "Step 0 done"`

## Why bother with such a trivial model?

Because the loss it achieves (~2.4) is the **floor we have to beat**
with a real neural net. Any neural language model that does worse than
this is buggy. And philosophically, every step from here just replaces
"counting" with a differentiable approximation that *generalizes* —
generalization is the whole point of moving away from counts.

→ Next: **Step 1**, where we replace the count table with an MLP and
discover backpropagation by hand.
