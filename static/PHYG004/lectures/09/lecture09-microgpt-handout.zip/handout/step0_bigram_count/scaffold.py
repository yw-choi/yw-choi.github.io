"""
Step 0 — Bigram language model trained by counting.

GOAL: build a "model" that has no neural net at all. The model is just a
count table state_dict[i][j] = how many times token j follows token i.
Training is literally counting; inference samples from the row.

This is a special case of a GPT where there is no attention (each token
only sees itself), no MLP, and the "embedding" is just a lookup row.
Counting is the closed-form solution. From Step 1 onwards we replace the
counts with a differentiable parameterization and gradient descent.

Fill in the four TODO blocks below, then run:
    python scaffold.py

You should see the loss go down from ~3.3 to ~2.4 over 1000 steps, and
20 hallucinated names at the end.
"""

import os       # os.path.exists
import math     # math.log
import random   # random.seed, random.choices, random.shuffle
random.seed(42)

# -----------------------------------------------------------------------------
# Dataset: load and tokenize a list of names (provided)
# -----------------------------------------------------------------------------
if not os.path.exists('input.txt'):
    import urllib.request
    names_url = 'https://raw.githubusercontent.com/karpathy/makemore/refs/heads/master/names.txt'
    urllib.request.urlretrieve(names_url, 'input.txt')
docs = [l.strip() for l in open('input.txt').read().strip().split('\n') if l.strip()]
random.shuffle(docs)
print(f"num docs: {len(docs)}")

# -----------------------------------------------------------------------------
# Tokenizer: character-level, with a special BOS token (provided)
# -----------------------------------------------------------------------------
uchars = sorted(set(''.join(docs)))   # unique characters → token ids 0..n-1
BOS = len(uchars)                     # special Beginning-of-Sequence token id
vocab_size = len(uchars) + 1
print(f"vocab size: {vocab_size}")

# -----------------------------------------------------------------------------
# Parameters: a vocab_size × vocab_size count table (provided, all zeros)
# -----------------------------------------------------------------------------
state_dict = [[0] * vocab_size for _ in range(vocab_size)]

# -----------------------------------------------------------------------------
# TODO 1 — the "model"
# -----------------------------------------------------------------------------
# Implement bigram(token_id) that returns the probability distribution over
# the NEXT token, given the current token_id.
#
# Use add-one (Laplace) smoothing so that unseen bigrams still get nonzero
# probability:
#
#     p(j | i) = (count[i][j] + 1) / (sum_j count[i][j] + vocab_size)
#
# Returns a list of length vocab_size that sums to 1.
def bigram(token_id):
    # TODO: replace this with the formula above
    raise NotImplementedError("TODO 1: implement Laplace-smoothed bigram(token_id)")

# -----------------------------------------------------------------------------
# Train the model
# -----------------------------------------------------------------------------
num_steps = 1000
for step in range(num_steps):

    # Take a single document, tokenize it, surround it with BOS on both sides
    doc = docs[step % len(docs)]
    tokens = [BOS] + [uchars.index(ch) for ch in doc] + [BOS]
    n = len(tokens) - 1

    # -------------------------------------------------------------------------
    # TODO 2 — forward pass
    # -------------------------------------------------------------------------
    # Compute the average cross-entropy loss for this document:
    #     loss = -(1/n) * sum_{t=0..n-1} log p(target_t | token_t)
    # where p(...) comes from bigram(token_t) and target_t = tokens[t+1].
    losses = []
    for pos_id in range(n):
        token_id, target_id = tokens[pos_id], tokens[pos_id + 1]
        # TODO: append the per-position cross-entropy loss to `losses`
        pass
    loss = (1 / n) * sum(losses) if losses else float('nan')

    # -------------------------------------------------------------------------
    # TODO 3 — update the model
    # -------------------------------------------------------------------------
    # Increment state_dict[token_id][target_id] for every (token, target)
    # pair in this document. That's it — no gradients, no learning rate.
    for pos_id in range(n):
        token_id, target_id = tokens[pos_id], tokens[pos_id + 1]
        # TODO: bump the count
        pass

    print(f"step {step+1:4d} / {num_steps:4d} | loss {loss:.4f}")

# -----------------------------------------------------------------------------
# TODO 4 — inference
# -----------------------------------------------------------------------------
# Sample 20 names from the model. Start each sample at BOS, then repeatedly
# sample the next token from bigram(current_token), stopping when BOS is
# emitted or after 16 characters.
#
# Hint: random.choices(range(vocab_size), weights=...) is your friend.
print("\n--- inference (new, hallucinated names) ---")
for sample_idx in range(20):
    token_id = BOS
    sample = []
    for _ in range(16):
        # TODO: sample next token, break on BOS, otherwise append uchars[token_id]
        break
    print(f"sample {sample_idx+1:2d}: {''.join(sample)}")
