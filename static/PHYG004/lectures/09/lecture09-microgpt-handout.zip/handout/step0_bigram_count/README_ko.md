# Step 0 — 카운팅으로 만드는 Bigram Language Model

> "어텐션도 없고, MLP도 없고, '임베딩'이 단순한 lookup table 한 줄인
> 모델에 대해서는, 카운팅이 closed-form 해다." — Karpathy

## 배경

Neural network 이전, 가장 단순한 language model은 **bigram count table**
이다. `state_dict[i][j]` = 학습 데이터에서 토큰 `i` 다음에 토큰 `j`가
등장한 횟수. 토큰 `i` 다음에 무엇이 올지 예측하려면 `i`번째 행을 꺼내서
정규화하면 끝.

놀라운 점은 이 사소한 모델이 이미 GPT와 **같은 바깥쪽 골격**을 공유한다는
것이다 — 토크나이즈하고, "forward pass"가 분포를 반환하고, 문서마다
파라미터를 업데이트하고, 추론 시에는 autoregressive하게 샘플링한다.
Step 1부터는 이 골격을 그대로 유지한 채 *모델 박스 안*만 바꿔 나간다.

### 수식

토큰 시퀀스 $t_0, t_1, \ldots, t_n$ 에 대해 모델이 부여하는 확률은

$$p(t_{k+1} \mid t_k) = \frac{c_{t_k, t_{k+1}} + 1}{\sum_j c_{t_k, j} + V}$$

여기서 $c_{ij}$ 는 카운트, $V$ 는 vocab size이다. 분자의 "+1"과
분모의 "+V"는 **Laplace smoothing** — 학습 중에 한 번도 못 본 bigram에
대해서도 log-probability가 발산하지 않도록 해주는 장치다.

학습 손실은 평균 cross-entropy:

$$\mathcal{L} = -\frac{1}{n} \sum_{k=0}^{n-1} \log p(t_{k+1} \mid t_k)$$

이 모델에서는 학습 데이터에 대한 $\mathcal{L}$의 최소값을 **카운팅**
한 번으로 얻을 수 있다 — gradient descent가 필요 없다. (5줄로 증명해
보라!)

## 채워야 할 부분

`scaffold.py`를 열고 네 개의 TODO를 완성한다.

| # | 무엇을 | 힌트 |
|---|------|------|
| 1 | `bigram(token_id)` — Laplace smoothing이 적용된 행 lookup | list comprehension 한 줄 |
| 2 | Forward pass — 문서의 평균 cross-entropy | `-math.log(probs[target_id])` |
| 3 | Update — `state_dict[token_id][target_id] += 1` | 한 줄 |
| 4 | Inference — BOS에서 시작해 autoregressive 샘플링 | `random.choices(range(vocab_size), weights=bigram(token_id))[0]` |

## Copilot에게 시킬 프롬프트

> "`scaffold.py`에서 TODO 1을 채워줘: `state_dict[token_id]`에
> add-one (Laplace) smoothing을 적용해서, 다음 토큰에 대한 길이
> `vocab_size` 확률 분포를 반환하는 `bigram(token_id)`를 구현해."

> "TODO 2와 TODO 3을 채워줘: training loop에서 각 위치마다 `bigram`을
> 호출해서 문서의 평균 cross-entropy 손실을 구하고, 그 다음
> `state_dict`의 bigram 카운트를 증가시켜줘."

> "마지막으로 TODO 4: 학습된 모델에서 20개의 이름을 샘플링해.
> BOS에서 시작해서, `random.choices(range(vocab_size), weights=bigram(token_id))[0]`
> 으로 다음 토큰을 뽑고, BOS가 나오거나 16글자가 되면 멈춰."

## 실행

```bash
python scaffold.py
```

## 체크포인트

- [ ] 첫 step의 `loss`가 **3.30 부근** (= $\log V$, 즉 랜덤 수준)
- [ ] 마지막 step의 `loss`가 **2.40 부근**
- [ ] 샘플링된 20개 이름이 *그럴듯한* 이름처럼 보임 — 짧고, 대체로
      자음–모음이 번갈아 나오고, `xxq` 같은 이상한 trigram이 없음
- [ ] `numpy`, `torch`를 비롯한 외부 라이브러리를 import하지 않음
- [ ] 커밋: `git add -A && git commit -m "Step 0 done"`

## 이런 사소한 모델을 굳이 왜?

이 모델이 달성하는 손실 (~2.4)이 진짜 neural language model이
**반드시 깨야 하는 바닥**이기 때문이다. 이것보다 더 나쁜 결과를 내는
모델은 어디선가 버그가 난 것이다. 그리고 철학적으로, 앞으로의 모든
step은 결국 "카운팅"을 *일반화 가능한* 미분 가능한 근사로 바꿔 나가는
과정이다 — 일반화야말로 카운트에서 벗어나는 진짜 이유다.

→ 다음: **Step 1**. 카운트 테이블을 MLP로 대체하고, 손으로
backpropagation을 직접 유도해 본다.
