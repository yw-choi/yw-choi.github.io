"""
Step 4 — Multi-head attention and configurable layer count.

What changed from Step 3:
  - n_head = 4: split q, k, v into 4 sub-vectors of length head_dim and
    do attention independently in each, then concatenate.
  - n_layer is now configurable, with layer-prefixed state_dict keys
    'layer0.attn_wq', 'layer0.mlp_fc1', etc. The forward pass loops
    over layers.
  - keys/values are now per-layer lists.

After this step the model architecture is identical to GPT-2 / train.py.
The only remaining difference is the optimizer (still SGD here, Adam
in Step 5).

Fill in the TODOs and run:
    python scaffold.py
"""

import os
import math
import random
random.seed(42)

# -----------------------------------------------------------------------------
# Dataset + Tokenizer (provided)
# -----------------------------------------------------------------------------
if not os.path.exists('input.txt'):
    import urllib.request
    names_url = 'https://raw.githubusercontent.com/karpathy/makemore/refs/heads/master/names.txt'
    urllib.request.urlretrieve(names_url, 'input.txt')
docs = [l.strip() for l in open('input.txt').read().strip().split('\n') if l.strip()]
random.shuffle(docs)
print(f"num docs: {len(docs)}")

uchars = sorted(set(''.join(docs)))
BOS = len(uchars)
vocab_size = len(uchars) + 1
print(f"vocab size: {vocab_size}")

# -----------------------------------------------------------------------------
# Autograd (provided)
# -----------------------------------------------------------------------------
class Value:
    __slots__ = ('data', 'grad', '_children', '_local_grads')
    def __init__(self, data, children=(), local_grads=()):
        self.data, self.grad = data, 0
        self._children, self._local_grads = children, local_grads
    def __add__(self, other):
        other = other if isinstance(other, Value) else Value(other)
        return Value(self.data + other.data, (self, other), (1, 1))
    def __mul__(self, other):
        other = other if isinstance(other, Value) else Value(other)
        return Value(self.data * other.data, (self, other), (other.data, self.data))
    def __pow__(self, other): return Value(self.data**other, (self,), (other * self.data**(other-1),))
    def log(self): return Value(math.log(self.data), (self,), (1/self.data,))
    def exp(self): return Value(math.exp(self.data), (self,), (math.exp(self.data),))
    def relu(self): return Value(max(0, self.data), (self,), (float(self.data > 0),))
    def __neg__(self): return self * -1
    def __radd__(self, o): return self + o
    def __sub__(self, o): return self + (-o)
    def __rsub__(self, o): return o + (-self)
    def __rmul__(self, o): return self * o
    def __truediv__(self, o): return self * o**-1
    def __rtruediv__(self, o): return o * self**-1
    def backward(self):
        topo, visited = [], set()
        def build(v):
            if v not in visited:
                visited.add(v)
                for c in v._children: build(c)
                topo.append(v)
        build(self)
        self.grad = 1
        for v in reversed(topo):
            for child, lg in zip(v._children, v._local_grads):
                child.grad += lg * v.grad

# -----------------------------------------------------------------------------
# Hyperparameters (provided — read these carefully!)
# -----------------------------------------------------------------------------
n_embd = 16        # embedding dimension (must be divisible by n_head)
n_head = 4         # number of attention heads
n_layer = 1        # number of transformer blocks (try 2 once it works!)
block_size = 16    # maximum sequence length
head_dim = n_embd // n_head

# -----------------------------------------------------------------------------
# TODO 1 — parameters with layer-prefixed keys
# -----------------------------------------------------------------------------
# Build a state_dict that contains:
#   - 'wte', 'wpe', 'lm_head'  (shared across all layers)
#   - For each i in range(n_layer):
#         f'layer{i}.attn_wq'   shape (n_embd, n_embd)
#         f'layer{i}.attn_wk'   shape (n_embd, n_embd)
#         f'layer{i}.attn_wv'   shape (n_embd, n_embd)
#         f'layer{i}.attn_wo'   shape (n_embd, n_embd)
#         f'layer{i}.mlp_fc1'   shape (4*n_embd, n_embd)
#         f'layer{i}.mlp_fc2'   shape (n_embd, 4*n_embd)
#
# This naming convention is exactly how PyTorch state_dicts work for
# stacked layers — flat dict, dot-separated names.
matrix = lambda nout, nin, std=0.08: [[Value(random.gauss(0, std)) for _ in range(nin)] for _ in range(nout)]
state_dict = {
    'wte':     matrix(vocab_size, n_embd),
    'wpe':     matrix(block_size, n_embd),
    'lm_head': matrix(vocab_size, n_embd),
}
# TODO 1: populate per-layer keys
raise NotImplementedError("TODO 1: add per-layer 'layer{i}.*' entries to state_dict")

params = [p for mat in state_dict.values() for row in mat for p in row]
print(f"num params: {len(params)}")

# -----------------------------------------------------------------------------
# Building blocks (provided)
# -----------------------------------------------------------------------------
def linear(x, w):
    return [sum(wi * xi for wi, xi in zip(wo, x)) for wo in w]

def softmax(logits):
    max_val = max(val.data for val in logits)
    exps = [(val - max_val).exp() for val in logits]
    total = sum(exps)
    return [e / total for e in exps]

def rmsnorm(x):
    ms = sum(xi * xi for xi in x) / len(x)
    scale = (ms + 1e-5) ** -0.5
    return [xi * scale for xi in x]

# -----------------------------------------------------------------------------
# TODO 2 — multi-head attention inside the layer loop
# -----------------------------------------------------------------------------
# `keys` and `values` are now LISTS of LISTS:
#     keys[li]   = list of past key vectors for layer li
#     values[li] = list of past value vectors for layer li
#
# The block becomes a `for li in range(n_layer):` loop. Inside each layer:
#
#   1) Pre-norm and project to (q, k, v) using the layer's weights:
#         q = linear(x, state_dict[f'layer{li}.attn_wq'])
#         (similarly k, v)
#      Append k to keys[li] and v to values[li].
#
#   2) MULTI-HEAD: for h in range(n_head):
#         hs = h * head_dim
#         q_h = q[hs:hs+head_dim]                    # this head's query
#         k_h = [ki[hs:hs+head_dim] for ki in keys[li]]    # past keys for this head
#         v_h = [vi[hs:hs+head_dim] for vi in values[li]]
#         attn_logits[t] = (q_h . k_h[t]) / sqrt(head_dim)
#         attn_weights = softmax(attn_logits)
#         head_out[j]  = sum_t attn_weights[t] * v_h[t][j]   for j = 0..head_dim-1
#         x_attn.extend(head_out)
#      After the loop x_attn is a length-n_embd list (concatenation of heads).
#
#   3) Output projection + residual:
#         x = linear(x_attn, state_dict[f'layer{li}.attn_wo'])
#         x = x + residual
#
#   4) MLP block exactly as in Step 3 but with 'layer{li}.mlp_*' keys.
#
# Note that scores are now divided by sqrt(HEAD_DIM), not sqrt(n_embd).
def gpt(token_id, pos_id, keys, values):
    tok_emb = state_dict['wte'][token_id]
    pos_emb = state_dict['wpe'][pos_id]
    x = [t + p for t, p in zip(tok_emb, pos_emb)]
    x = rmsnorm(x)

    # TODO 2: multi-head attention inside a per-layer loop
    raise NotImplementedError("TODO 2: implement the multi-head, multi-layer transformer body")

    logits = linear(x, state_dict['lm_head'])
    return logits

# -----------------------------------------------------------------------------
# Training loop (provided)
# -----------------------------------------------------------------------------
num_steps = 1000
learning_rate = 0.1
for step in range(num_steps):
    doc = docs[step % len(docs)]
    tokens = [BOS] + [uchars.index(ch) for ch in doc] + [BOS]
    n = min(block_size, len(tokens) - 1)

    keys = [[] for _ in range(n_layer)]
    values = [[] for _ in range(n_layer)]
    losses = []
    for pos_id in range(n):
        token_id, target_id = tokens[pos_id], tokens[pos_id + 1]
        logits = gpt(token_id, pos_id, keys, values)
        probs = softmax(logits)
        losses.append(-probs[target_id].log())
    loss = (1 / n) * sum(losses)

    loss.backward()

    lr_t = learning_rate * (1 - step / num_steps)
    for p in params:
        p.data -= lr_t * p.grad
        p.grad = 0

    if step < 5 or step % 200 == 0:
        print(f"step {step+1:4d} / {num_steps:4d} | loss {loss.data:.4f}")

# -----------------------------------------------------------------------------
# Inference (provided)
# -----------------------------------------------------------------------------
temperature = 0.5
print("\n--- inference (new, hallucinated names) ---")
for sample_idx in range(20):
    keys = [[] for _ in range(n_layer)]
    values = [[] for _ in range(n_layer)]
    token_id = BOS
    sample = []
    for pos_id in range(block_size):
        logits = gpt(token_id, pos_id, keys, values)
        probs = softmax([l / temperature for l in logits])
        token_id = random.choices(range(vocab_size), weights=[p.data for p in probs])[0]
        if token_id == BOS:
            break
        sample.append(uchars[token_id])
    print(f"sample {sample_idx+1:2d}: {''.join(sample)}")
