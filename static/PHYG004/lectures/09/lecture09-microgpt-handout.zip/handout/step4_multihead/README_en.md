# Step 4 — Multi-Head Attention and Layer Stacking

> "After this step the model architecture is identical to GPT-2."

## What changes from Step 3

| Step 3 | Step 4 |
|--------|--------|
| Single attention head | **`n_head` parallel heads** that look at different sub-spaces |
| Single transformer block | A `for li in range(n_layer):` loop |
| Flat parameter names | **`layer{i}.attn_wq`** etc. (PyTorch convention) |
| `keys = []`, `values = []` | `keys[li] = [...]`, one per layer |

The architecture is now structurally identical to GPT-2 / `train.py`.
The only remaining difference is the optimizer.

## Why multi-head?

Each head sees a different `head_dim`-dimensional subspace of the
n_embd-dimensional hidden state. Heads can specialize: in the original
*Attention Is All You Need* paper, some heads attend to syntactic
relationships, others to semantic ones, others purely to position.
With one giant head you can in principle learn all of this, but with
multiple narrow heads the optimization is empirically much easier.

The math is just slicing:

$$q = W_q x \in \mathbb{R}^{n_\text{embd}}, \quad q^{(h)} = q_{\,h\cdot d : (h+1)\cdot d}$$

where $d = n_\text{embd} / n_\text{head}$ is the per-head dimension.
Each head independently does scaled dot-product attention with its own
$q^{(h)}, k^{(h)}, v^{(h)}$, and we divide scores by $\sqrt{d}$ — note
the head dimension, not the full embedding dimension! Concatenating
the per-head outputs gives a length-`n_embd` vector that we then pass
through `attn_wo`.

## Why layer prefixes?

When you stack `n_layer` transformer blocks, you need a way to name
the parameters of layer 0 vs layer 1. The PyTorch convention is
**dot-separated keys** in a flat dict:

```
state_dict = {
    'wte': ...,
    'wpe': ...,
    'layer0.attn_wq': ...,
    'layer0.mlp_fc1': ...,
    'layer1.attn_wq': ...,
    'layer1.mlp_fc1': ...,
    ...
    'lm_head': ...,
}
```

This is exactly how PyTorch's `nn.Module.state_dict()` flattens nested
modules. Once you understand this naming you understand how to load and
save real LLMs.

## What you fill in

| # | What |
|---|------|
| 1 | Populate `state_dict` with `layer{i}.*` entries inside a `for i in range(n_layer):` loop |
| 2 | Inside `gpt`, the per-layer loop with multi-head attention and the MLP block |

The hyperparameters, the dataset, the tokenizer, the autograd engine,
the building blocks (`linear`, `softmax`, `rmsnorm`), the training
loop, and the inference loop are all **provided**.

## Ask Copilot

> "In `scaffold.py`, fill in TODO 1: add per-layer entries to
> `state_dict`. For each `i in range(n_layer)`, add the six keys
> `layer{i}.attn_wq`, `layer{i}.attn_wk`, `layer{i}.attn_wv`,
> `layer{i}.attn_wo` of shape `(n_embd, n_embd)`, plus
> `layer{i}.mlp_fc1` of shape `(4*n_embd, n_embd)` and
> `layer{i}.mlp_fc2` of shape `(n_embd, 4*n_embd)`. Use the `matrix`
> helper. Then remove the `raise NotImplementedError` line."

> "Now fill in TODO 2: convert the single transformer block from
> Step 3 into a `for li in range(n_layer):` loop. Inside the loop,
> read keys/values as `keys[li]` and `values[li]` and look up
> per-layer weights as `state_dict[f'layer{li}.attn_wq']` etc. Split
> the attention into `n_head` heads of size `head_dim = n_embd //
> n_head`, do scaled-dot-product attention with `sqrt(head_dim)`
> normalization for each head, concatenate the per-head outputs into a
> length-`n_embd` `x_attn`, project with `attn_wo`, add the residual,
> then do the MLP block exactly as in Step 3."

## Run

```bash
python scaffold.py
```

This is the **slowest** step yet. Each forward pass now allocates a
graph proportional to `n_layer * sequence_length^2 * n_head`. On a
laptop expect ~3–5 minutes for 1000 steps with `n_layer=1`. **Try
`n_layer=2` once it works** — it should give a slightly lower loss.

## Checkpoint

- [ ] First step prints `loss` around **3.6**
- [ ] Final step prints `loss` around **2.3** (similar to Step 3 with
      single head — multi-head doesn't help much at this size, but the
      machinery is in place)
- [ ] Sampled names look name-like
- [ ] Try setting `n_layer = 2` at the top and re-running. The loss
      should drop to **~2.1–2.2**. (It will be twice as slow.)
- [ ] Commit: `git add -A && git commit -m "Step 4 done"`

## Reflection

You now have the **exact** GPT-2 architecture. Token embed + position
embed + N × (pre-norm + multi-head causal attention + residual +
pre-norm + MLP + residual) + lm_head. The only thing standing between
you and `train.py` is the optimizer. That is the very last step.

→ Next: **Step 5**, where SGD becomes Adam.
