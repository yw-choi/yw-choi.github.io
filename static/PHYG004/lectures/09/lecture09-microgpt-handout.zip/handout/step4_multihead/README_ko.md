# Step 4 — Multi-Head Attention과 Layer Stacking

> "이 step이 끝나면 모델 architecture는 GPT-2와 동일하다."

## Step 3 → Step 4 변화

| Step 3 | Step 4 |
|--------|--------|
| 단일 attention head | 서로 다른 부분공간을 보는 **`n_head`개의 병렬 head** |
| 단일 transformer block | `for li in range(n_layer):` 루프 |
| 평탄한 파라미터 이름 | **`layer{i}.attn_wq`** 등 (PyTorch 컨벤션) |
| `keys = []`, `values = []` | `keys[li] = [...]`, layer 당 하나 |

architecture가 구조적으로 GPT-2 / `train.py`와 동일해진다. 남은 차이는
optimizer뿐.

## Multi-head를 왜?

각 head는 n_embd 차원 hidden state의 서로 다른 `head_dim` 차원
부분공간을 본다. Head들이 분업할 수 있다 — *Attention Is All You Need*
원논문에서 어떤 head는 통사 관계를, 어떤 head는 의미 관계를, 어떤
head는 순수하게 위치만 본다. 거대한 단일 head로도 원리적으로 다 배울
수 있지만, 여러 개의 좁은 head로 나누면 경험적으로 최적화가 훨씬 쉽다.

수식은 그냥 slicing이다:

$$q = W_q x \in \mathbb{R}^{n_\text{embd}}, \quad q^{(h)} = q_{\,h\cdot d : (h+1)\cdot d}$$

여기서 $d = n_\text{embd} / n_\text{head}$ 는 per-head 차원. 각 head가
독립적으로 자기 $q^{(h)}, k^{(h)}, v^{(h)}$로 scaled dot-product
attention을 하고, score는 $\sqrt{d}$ — 즉 head 차원으로 — 나눈다 (전체
embedding 차원 아님!). per-head 출력을 concat하면 길이 `n_embd` 벡터가
되고, 이걸 `attn_wo`에 통과시킨다.

## Layer prefix는 왜?

`n_layer`개의 transformer block을 쌓으면, layer 0과 layer 1의 파라미터를
이름으로 구별해야 한다. PyTorch 컨벤션은 평탄한 dict 안의 **dot-separated
key**:

```
state_dict = {
    'wte': ...,
    'wpe': ...,
    'layer0.attn_wq': ...,
    'layer0.mlp_fc1': ...,
    'layer1.attn_wq': ...,
    'layer1.mlp_fc1': ...,
    ...
    'lm_head': ...,
}
```

PyTorch의 `nn.Module.state_dict()`가 nested module을 평탄화하는 방식과
정확히 같다. 이 naming을 이해하면 진짜 LLM checkpoint를 load/save하는
방법을 이해한 것이다.

## 채워야 할 부분

| # | 무엇을 |
|---|------|
| 1 | `for i in range(n_layer):` 안에서 `state_dict`에 `layer{i}.*` 항목 채우기 |
| 2 | `gpt` 안에서 multi-head attention + MLP block을 per-layer 루프로 |

하이퍼파라미터, dataset, tokenizer, autograd engine, building blocks
(`linear`, `softmax`, `rmsnorm`), training loop, inference loop는 모두
**제공**되어 있다.

## Copilot 프롬프트

> "`scaffold.py`에서 TODO 1을 채워줘: `state_dict`에 layer 별 항목을
> 추가해. 각 `i in range(n_layer)`에 대해 여섯 개의 키
> `layer{i}.attn_wq`, `layer{i}.attn_wk`, `layer{i}.attn_wv`,
> `layer{i}.attn_wo` (모두 `(n_embd, n_embd)`),
> `layer{i}.mlp_fc1` (`(4*n_embd, n_embd)`),
> `layer{i}.mlp_fc2` (`(n_embd, 4*n_embd)`)를 추가해. `matrix` 헬퍼를
> 써. 그 후 `raise NotImplementedError` 줄을 지워."

> "이제 TODO 2를 채워줘: Step 3의 단일 transformer block을
> `for li in range(n_layer):` 루프로 바꿔. 루프 안에서 keys/values는
> `keys[li]`, `values[li]`로 읽고, layer 별 weight는
> `state_dict[f'layer{li}.attn_wq']` 식으로 lookup. attention은
> `head_dim = n_embd // n_head` 크기의 `n_head`개의 head로 쪼개고, 각
> head에서 `sqrt(head_dim)`으로 normalize한 scaled-dot-product
> attention을 하고, head 출력들을 concat해서 길이 `n_embd`의
> `x_attn`을 만들고, `attn_wo`로 사영, residual 더하기, 그다음 MLP
> block은 Step 3과 동일하게."

## 실행

```bash
python scaffold.py
```

이 step은 지금까지 중 **가장 느리다**. forward 한 번이
`n_layer * sequence_length^2 * n_head`에 비례하는 graph를 만들기 때문.
노트북에서 `n_layer=1`로 1000 step에 3–5분 예상. **잘 돌면 `n_layer=2`도
시도해 보라** — 손실이 약간 더 내려간다.

## 체크포인트

- [ ] 첫 step의 `loss`가 **3.6** 부근
- [ ] 마지막 step의 `loss`가 **2.3** 부근 (Step 3와 비슷 — 이 크기에서는
      multi-head가 큰 도움은 안 되지만, 기계장치는 마련됨)
- [ ] 샘플링된 이름이 이름답게 보임
- [ ] 위쪽 `n_layer = 2`로 바꿔서 다시 실행. 손실이 **~2.1–2.2**로
      내려가야 함. (속도는 두 배 느려짐.)
- [ ] 커밋: `git add -A && git commit -m "Step 4 done"`

## 회고

이제 **정확히** GPT-2 architecture다. 토큰 embed + 위치 embed +
N × (pre-norm + multi-head causal attention + residual + pre-norm + MLP
+ residual) + lm_head. `train.py`까지 남은 건 optimizer 하나뿐.
그게 마지막 step.

→ 다음: **Step 5**. SGD를 Adam으로.
