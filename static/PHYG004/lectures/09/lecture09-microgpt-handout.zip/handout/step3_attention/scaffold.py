"""
Step 3 — From bigram MLP to a real transformer block.

What changed from Step 2:
  - The model now sees the WHOLE PREFIX of the sequence, not just the
    current token. This is what attention buys us.
  - We add: position embeddings (`wpe`), single-head causal attention
    (q, k, v, attn_wo), RMSNorm, residual connections, and a separate
    language-modeling head (`lm_head`).
  - The model API changes from `mlp(token_id)` to
    `gpt(token_id, pos_id, keys, values)`. The caller threads `keys`
    and `values` lists across positions — that is the KV cache.

After this step the model is structurally a GPT. The only remaining
differences from train.py are: single head (vs multi-head), single
layer (vs configurable n_layer), and SGD (vs Adam).

Fill in the TODOs and run:
    python scaffold.py
"""

import os
import math
import random
random.seed(42)

# -----------------------------------------------------------------------------
# Dataset + Tokenizer (provided)
# -----------------------------------------------------------------------------
if not os.path.exists('input.txt'):
    import urllib.request
    names_url = 'https://raw.githubusercontent.com/karpathy/makemore/refs/heads/master/names.txt'
    urllib.request.urlretrieve(names_url, 'input.txt')
docs = [l.strip() for l in open('input.txt').read().strip().split('\n') if l.strip()]
random.shuffle(docs)
print(f"num docs: {len(docs)}")

uchars = sorted(set(''.join(docs)))
BOS = len(uchars)
vocab_size = len(uchars) + 1
print(f"vocab size: {vocab_size}")

# -----------------------------------------------------------------------------
# Autograd (provided — same Value class as Step 2)
# -----------------------------------------------------------------------------
class Value:
    __slots__ = ('data', 'grad', '_children', '_local_grads')
    def __init__(self, data, children=(), local_grads=()):
        self.data, self.grad = data, 0
        self._children, self._local_grads = children, local_grads
    def __add__(self, other):
        other = other if isinstance(other, Value) else Value(other)
        return Value(self.data + other.data, (self, other), (1, 1))
    def __mul__(self, other):
        other = other if isinstance(other, Value) else Value(other)
        return Value(self.data * other.data, (self, other), (other.data, self.data))
    def __pow__(self, other): return Value(self.data**other, (self,), (other * self.data**(other-1),))
    def log(self): return Value(math.log(self.data), (self,), (1/self.data,))
    def exp(self): return Value(math.exp(self.data), (self,), (math.exp(self.data),))
    def relu(self): return Value(max(0, self.data), (self,), (float(self.data > 0),))
    def __neg__(self): return self * -1
    def __radd__(self, o): return self + o
    def __sub__(self, o): return self + (-o)
    def __rsub__(self, o): return o + (-self)
    def __rmul__(self, o): return self * o
    def __truediv__(self, o): return self * o**-1
    def __rtruediv__(self, o): return o * self**-1
    def backward(self):
        topo, visited = [], set()
        def build(v):
            if v not in visited:
                visited.add(v)
                for c in v._children: build(c)
                topo.append(v)
        build(self)
        self.grad = 1
        for v in reversed(topo):
            for child, lg in zip(v._children, v._local_grads):
                child.grad += lg * v.grad

# -----------------------------------------------------------------------------
# Parameters: now there are NINE matrices, not three
# -----------------------------------------------------------------------------
n_embd = 16
block_size = 16    # maximum sequence length
matrix = lambda nout, nin: [[Value(random.gauss(0, 0.08)) for _ in range(nin)] for _ in range(nout)]
state_dict = {
    'wte':     matrix(vocab_size, n_embd),  # token embedding
    'wpe':     matrix(block_size, n_embd),  # position embedding   <-- new
    'attn_wq': matrix(n_embd, n_embd),      # query                <-- new
    'attn_wk': matrix(n_embd, n_embd),      # key                  <-- new
    'attn_wv': matrix(n_embd, n_embd),      # value                <-- new
    'attn_wo': matrix(n_embd, n_embd),      # output projection    <-- new
    'mlp_fc1': matrix(4 * n_embd, n_embd),
    'mlp_fc2': matrix(n_embd, 4 * n_embd),  # NB: now back to n_embd, not vocab!
    'lm_head': matrix(vocab_size, n_embd),  # final projection     <-- new
}
params = [p for mat in state_dict.values() for row in mat for p in row]
print(f"num params: {len(params)}")

# -----------------------------------------------------------------------------
# Building blocks (provided)
# -----------------------------------------------------------------------------
def linear(x, w):
    return [sum(wi * xi for wi, xi in zip(wo, x)) for wo in w]

def softmax(logits):
    max_val = max(val.data for val in logits)
    exps = [(val - max_val).exp() for val in logits]
    total = sum(exps)
    return [e / total for e in exps]

# -----------------------------------------------------------------------------
# TODO 1 — RMSNorm
# -----------------------------------------------------------------------------
# RMSNorm normalizes a vector by its root-mean-square magnitude:
#
#       y = x / sqrt(mean(x^2) + eps)
#
# Use eps = 1e-5. No learnable scale (we omit it for simplicity — you'll
# rediscover that LayerNorm/RMSNorm with learnable scale is the LLaMA choice).
#
# Hint: `(value ** -0.5)` gives 1/sqrt; multiply each entry of x by it.
def rmsnorm(x):
    raise NotImplementedError("TODO 1: rmsnorm")

# -----------------------------------------------------------------------------
# TODO 2 — the GPT forward pass for one position
# -----------------------------------------------------------------------------
# This is the heart of the lecture. Read carefully.
#
# Inputs:
#   token_id: int, the current token at this position
#   pos_id:   int, the position index 0..block_size-1
#   keys:     list of past key vectors (each of length n_embd). MUTABLE —
#             you must APPEND this position's key to it.
#   values:   list of past value vectors. APPEND v.
#
# Outputs:
#   logits:   list of length vocab_size, the next-token scores
#
# Layout, layer by layer:
#
#   1) Embed:        x = wte[token_id] + wpe[pos_id]
#                    x = rmsnorm(x)               # pre-norm at the very entry
#
#   2) Attention block:
#      x_residual = x
#      x = rmsnorm(x)                                 # pre-norm
#      q = linear(x, attn_wq)                         # length n_embd
#      k = linear(x, attn_wk)
#      v = linear(x, attn_wv)
#      keys.append(k); values.append(v)               # KV cache
#      attn_logits[t] = (q . keys[t]) / sqrt(n_embd)  for t = 0..len(keys)-1
#      attn_weights = softmax(attn_logits)
#      x_attn[j]    = sum_t attn_weights[t] * values[t][j]   for j = 0..n_embd-1
#      x = linear(x_attn, attn_wo)
#      x = x + x_residual                             # residual
#
#   3) MLP block:
#      x_residual = x
#      x = rmsnorm(x)
#      x = linear(x, mlp_fc1)
#      x = [xi.relu() for xi in x]
#      x = linear(x, mlp_fc2)
#      x = x + x_residual                             # residual
#
#   4) Project to vocabulary:
#      logits = linear(x, lm_head)
#      return logits
#
# Notice the CAUSAL structure is automatic: we only iterate over keys/values
# we have already appended (= positions ≤ pos_id), so future tokens cannot
# leak into the present. No mask needed.
def gpt(token_id, pos_id, keys, values):
    raise NotImplementedError("TODO 2: implement the single-layer GPT forward pass")

# -----------------------------------------------------------------------------
# Training loop (provided)
# -----------------------------------------------------------------------------
num_steps = 1000
learning_rate = 0.1
for step in range(num_steps):
    doc = docs[step % len(docs)]
    tokens = [BOS] + [uchars.index(ch) for ch in doc] + [BOS]
    n = min(block_size, len(tokens) - 1)

    keys, values = [], []
    losses = []
    for pos_id in range(n):
        token_id, target_id = tokens[pos_id], tokens[pos_id + 1]
        logits = gpt(token_id, pos_id, keys, values)
        probs = softmax(logits)
        losses.append(-probs[target_id].log())
    loss = (1 / n) * sum(losses)

    loss.backward()

    lr_t = learning_rate * (1 - step / num_steps)
    for p in params:
        p.data -= lr_t * p.grad
        p.grad = 0

    if step < 5 or step % 200 == 0:
        print(f"step {step+1:4d} / {num_steps:4d} | loss {loss.data:.4f}")

# -----------------------------------------------------------------------------
# Inference (provided) — note the per-sample fresh keys/values
# -----------------------------------------------------------------------------
temperature = 0.5
print("\n--- inference (new, hallucinated names) ---")
for sample_idx in range(20):
    keys, values = [], []
    token_id = BOS
    sample = []
    for pos_id in range(block_size):
        logits = gpt(token_id, pos_id, keys, values)
        probs = softmax([l / temperature for l in logits])
        token_id = random.choices(range(vocab_size), weights=[p.data for p in probs])[0]
        if token_id == BOS:
            break
        sample.append(uchars[token_id])
    print(f"sample {sample_idx+1:2d}: {''.join(sample)}")
