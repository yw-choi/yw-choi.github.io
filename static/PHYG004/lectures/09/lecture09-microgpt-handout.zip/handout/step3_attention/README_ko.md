# Step 3 — Attention, RMSNorm, Residual: 진짜 Transformer

> "이 step이 끝나면 모델은 구조적으로 GPT다. `train.py`와 남은 차이는
> 단일 head, 단일 layer, SGD뿐이다."

## Step 2 → Step 3 변화

전체 progression에서 **개념적으로 가장 큰 도약**이다.

| Step 2 | Step 3 |
|--------|--------|
| 현재 토큰만 보는 모델 | attention으로 **전체 prefix**를 보는 모델 |
| weight matrix 3개 | **9개** |
| `mlp(token_id) → logits` | `gpt(token_id, pos_id, keys, values) → logits` |
| 위치 개념 없음 | 토큰 임베딩에 `wpe[pos_id]`를 더함 |
| 정규화 없음 | RMSNorm 세 군데 (입력, attn 앞, mlp 앞) |
| Residual 없음 | attention과 MLP 블록 모두에 residual |

새로 추가되는 모든 조각이 *Attention Is All You Need*와 GPT-2 논문에서
읽었던 바로 그것들이다.

## 새 building blocks

### Position embedding

각 위치 $0 \le t < \text{block\_size}$ 마다 학습 가능한 벡터
$\text{wpe}_t$가 있고, 토큰 embedding에 더한다:

$$x = \text{wte}_{\text{token}} + \text{wpe}_t$$

토큰 embedding 자체는 "내가 이 이름의 세 번째 문자다"를 모르기 때문에,
이걸 알려주는 게 wpe다.

### RMSNorm

벡터 $x \in \mathbb{R}^d$ 에 대해

$$\mathrm{RMSNorm}(x) = \frac{x}{\sqrt{\frac{1}{d}\sum_i x_i^2 + \varepsilon}}$$

(LLaMA에서 쓰는 표준 RMSNorm은 학습 가능한 scale도 있는데, 명료함을
위해 여기서는 생략한다.) 역할은 layer를 지나면서 activation이 발산하거나
사라지는 것을 막아주는 것이다.

### Causal self-attention (single head)

위치 $t$에서, 누적된 과거 key $k_0, \ldots, k_t$와 value
$v_0, \ldots, v_t$가 있다고 하자:

1. 현재 정규화된 hidden state로부터 q, k, v를 만든다:
   $q = W_q x$, $k = W_k x$, $v = W_v x$. 새 $k$, $v$를 누적 리스트에
   `append`한다.
2. Score: $a_s = \frac{q \cdot k_s}{\sqrt{d}}$, $s = 0, \ldots, t$.
3. $s$에 대해 softmax: $\alpha = \mathrm{softmax}(a)$.
4. value의 weighted sum: $\text{attn} = \sum_{s=0}^{t} \alpha_s v_s$.
5. Output projection: $W_o \cdot \text{attn}$.

**Causality는 자동으로** 만족된다. 우리가 이미 append한 위치 ($\le t$)
에 대해서만 더하기 때문이다. 삼각 mask가 없는 이유는 history 자체가
미래를 안 가지고 있기 때문.

### Residual connections

attention 블록과 MLP 블록 끝에서 입력을 더한다:

$$x \leftarrow x + \text{attn\_block}(x), \qquad x \leftarrow x + \text{mlp\_block}(x).$$

깊은 stack을 학습할 수 있게 해 주는 gradient highway다.

### `lm_head`

MLP 블록은 이제 `n_embd` 차원에 머문다. 별도의 `lm_head` 행렬이 마지막
hidden state를 `vocab_size`로 사영해서 cross-entropy 계산에 쓴다.

## 채워야 할 부분

| # | 함수 | 무엇을 |
|---|----|------|
| 1 | `rmsnorm(x)` | RMS로 나누기, $\varepsilon = 10^{-5}$ |
| 2 | `gpt(token_id, pos_id, keys, values)` | embed → attn block → mlp block → lm_head |

`Value`, dataset, tokenizer, training loop, inference loop는 모두
**제공**되어 있다.

## Copilot 프롬프트

> "`scaffold.py`에서 TODO 1 `rmsnorm(x)`을 채워줘: `x`의
> root-mean-square를 계산한 후, 각 entry를 `sqrt(ms + 1e-5)`로 나눠.
> `x`가 `Value` 리스트이고 autograd engine이 `__pow__`를 알기 때문에
> 역제곱근은 `**-0.5`로 표현하면 돼."

> "이제 TODO 2 `gpt(token_id, pos_id, keys, values)`를 주석에 적힌
> 레시피대로 구현해줘:
> 1. Embed: `x = wte[token_id] + wpe[pos_id]`, 그다음 `rmsnorm(x)`.
> 2. Attention block: residual 저장, `rmsnorm(x)`, q/k/v 사영,
>    `keys.append(k); values.append(v)`, 누적 리스트 위에서
>    scaled-dot-product attention 계산, `attn_wo`로 사영, residual 더하기.
> 3. MLP block: residual 저장, `rmsnorm(x)`, fc1 → ReLU → fc2,
>    residual 더하기.
> 4. `lm_head`로 `vocab_size`에 사영해서 반환."

Copilot이 작성한 후에는 **attention loop를 천천히 읽고** 다음을
확인하라:
- score가 $\sqrt{n_\text{embd}}$로 나뉘어 있는지
- 과거 (현재 포함)에 대해서만 합이 잡히는지
- residual이 output projection *뒤*에 더해지는지 (앞에 더하지 않도록)

## 실행

```bash
python scaffold.py
```

이 step은 Step 2보다 **눈에 띄게 느리다** — 각 forward에서 sequence
길이의 제곱에 비례하는 graph가 만들어지기 때문 (attention score가
모든 과거 위치에 의존). 노트북에서 1000 step에 1–3분 정도 예상.

## 체크포인트

- [ ] 첫 training step의 `loss`가 **3.6** 부근
- [ ] 마지막 step의 `loss`가 **2.3** 부근 (Step 2보다 낮음 — attention이
      실제로 도움이 됨!)
- [ ] 샘플링된 이름이 Step 2보다 눈에 띄게 더 이름답고 길고 다양함
- [ ] 외부 라이브러리 import 없음
- [ ] 커밋: `git add -A && git commit -m "Step 3 done"`

## 회고

토큰 embedding + 위치 embedding + pre-norm + self-attention + residual
+ pre-norm + MLP + residual + lm_head — 완전한 causal Transformer 블록을
순수 Python으로 작성했다. 이건 *정확히* GPT-2와 같은 architecture다.
GPT-2와의 차이는 head 수, layer 수, optimizer뿐이고, 다음 두 step에서
모두 메운다.

→ 다음: **Step 4**. 단일 attention head를 multiple head로 쪼개고,
블록을 `n_layer`만큼의 `for` 루프로 감싼다.
