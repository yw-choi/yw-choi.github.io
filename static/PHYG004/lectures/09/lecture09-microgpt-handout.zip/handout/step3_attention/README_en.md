# Step 3 — Attention, RMSNorm, Residual: a Real Transformer

> "After this step the model is structurally a GPT. The only remaining
> differences from `train.py` are: single head, single layer, and SGD."

## What changes from Step 2

This is the **biggest conceptual jump** in the whole progression.

| Step 2 | Step 3 |
|--------|--------|
| Model only sees the current token | Model sees the **whole prefix** via attention |
| 3 weight matrices | **9** weight matrices |
| `mlp(token_id) → logits` | `gpt(token_id, pos_id, keys, values) → logits` |
| No notion of position | `wpe[pos_id]` added to the token embedding |
| No normalization | RMSNorm at three places (entry, pre-attn, pre-mlp) |
| No residuals | Residual connections around attention and MLP |

The new pieces are exactly the things you read about in *Attention Is
All You Need* and the GPT-2 paper.

## The new building blocks

### Position embedding

Each position $0 \le t < \text{block\_size}$ has its own learned vector
$\text{wpe}_t$. We add it to the token embedding:

$$x = \text{wte}_{\text{token}} + \text{wpe}_t$$

This is what tells the model "I am the third character of the name",
because the underlying token embedding doesn't know.

### RMSNorm

For a vector $x \in \mathbb{R}^d$,

$$\mathrm{RMSNorm}(x) = \frac{x}{\sqrt{\frac{1}{d}\sum_i x_i^2 + \varepsilon}}$$

(The standard LLaMA RMSNorm also has a learnable scale, which we omit
for clarity.) The role is to keep activations from blowing up or
vanishing across layers.

### Causal self-attention (single head)

For a single position $t$, given the running history of past keys
$k_0, \ldots, k_t$ and values $v_0, \ldots, v_t$:

1. Compute query, key, value from the current normalized hidden state:
   $q = W_q x$, $k = W_k x$, $v = W_v x$. Append the new $k$ and $v$
   to the running lists.
2. Score: $a_s = \frac{q \cdot k_s}{\sqrt{d}}$ for $s = 0, \ldots, t$.
3. Softmax over $s$: $\alpha = \mathrm{softmax}(a)$.
4. Weighted sum of values: $\text{attn} = \sum_{s=0}^{t} \alpha_s v_s$.
5. Output projection: $W_o \cdot \text{attn}$.

**Causality is automatic**: we only sum over keys/values we have
already appended, i.e. positions $\le t$. There is no triangular mask
because the history simply doesn't contain the future.

### Residual connections

After both the attention block and the MLP block, we add the input
back:

$$x \leftarrow x + \text{attn\_block}(x), \qquad x \leftarrow x + \text{mlp\_block}(x).$$

This is the gradient highway that lets us train deep stacks.

### `lm_head`

The MLP block now stays in `n_embd` dimensions. A separate `lm_head`
matrix projects the final hidden state to `vocab_size` for cross-entropy.

## What you fill in

| # | Function | What |
|---|----------|------|
| 1 | `rmsnorm(x)` | divide by the RMS, $\varepsilon = 10^{-5}$ |
| 2 | `gpt(token_id, pos_id, keys, values)` | embed → attn block → mlp block → lm_head |

The `Value` class, the dataset, the tokenizer, the training loop and
the inference loop are all **provided**.

## Ask Copilot

> "In `scaffold.py`, fill in TODO 1 `rmsnorm(x)`: compute the
> root-mean-square of `x`, then return each entry divided by
> `sqrt(ms + 1e-5)`. Use `**-0.5` for the inverse square root since
> `x` is a list of `Value`s and the autograd engine knows `__pow__`."

> "Now fill in TODO 2 `gpt(token_id, pos_id, keys, values)` exactly as
> the recipe in the comment block:
> 1. Embed: `x = wte[token_id] + wpe[pos_id]`, then `rmsnorm(x)`.
> 2. Attention block: save residual, `rmsnorm(x)`, project to q/k/v,
>    `keys.append(k); values.append(v)`, compute scaled-dot-product
>    attention over the running lists, project with `attn_wo`, add the
>    residual.
> 3. MLP block: save residual, `rmsnorm(x)`, fc1 → ReLU → fc2, add the
>    residual.
> 4. Project to `vocab_size` with `lm_head` and return."

After Copilot writes it, **read the attention loop carefully** and
convince yourself that:
- the scores are normalized by $\sqrt{n_\text{embd}}$
- only the past (including the present) is summed over
- the residual is added *after* the output projection, not before

## Run

```bash
python scaffold.py
```

This step is **noticeably slower** than Step 2 — each forward pass
allocates a graph proportional to the sequence length squared (because
attention scores depend on all past positions). On a laptop expect
~1–3 minutes for 1000 steps.

## Checkpoint

- [ ] First training step prints `loss` around **3.6**
- [ ] Final training step prints `loss` around **2.3** (lower than
      Step 2 — attention actually helps!)
- [ ] Sampled names look noticeably more name-like than Step 2 (longer,
      more structure, more variety)
- [ ] You did not import any third-party library
- [ ] Commit: `git add -A && git commit -m "Step 3 done"`

## Reflection

You just built a complete causal Transformer block — token embed +
position embed + pre-norm + self-attention + residual + pre-norm + MLP
+ residual + lm_head — in pure Python without any libraries. This is
*exactly* the same architecture as GPT-2. The only differences from
GPT-2 are the head count, the layer count, and the optimizer, all of
which we fix in the next two steps.

→ Next: **Step 4**, where we split the single attention head into
multiple heads and wrap the block in a `for` loop over `n_layer`.
