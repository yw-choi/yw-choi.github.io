# Lecture 09 — microGPT, built from scratch in 6 steps

> "Counting → MLP → autograd → attention → multi-head → Adam.
> Six revisions, six commits, one transformer."

In this hands-on you will build a **complete GPT-2-style transformer
language model** in pure Python — no NumPy, no PyTorch, no JAX. The
six steps mirror the six revisions of Karpathy's
[`build_microgpt.py`](https://gist.github.com/karpathy/561ac2de12a47cc06a23691e1be9543a)
gist. At each step the **outer skeleton stays the same** (dataset →
tokenizer → forward → backward → update → sample); only what's inside
the "model" box changes.

## The 6 steps

| Step | Adds | Difficulty | Approx. lines |
|------|------|:----------:|--------------:|
| [0 — Bigram counting](step0_bigram_count/README_en.md) | A count table, no NN | Trivial | 80 |
| [1 — MLP, manual gradients](step1_mlp_manual/README_en.md) | MLP, hand-derived backprop, gradient check | Medium | 180 |
| [2 — Autograd Value class](step2_autograd/README_en.md) | A 50-line autograd engine | Medium | 160 |
| [3 — Attention + RMSNorm + residuals](step3_attention/README_en.md) | First real transformer block | Hard | 190 |
| [4 — Multi-head + layer loop](step4_multihead/README_en.md) | GPT-2-identical architecture | Medium | 200 |
| [5 — Adam optimizer](step5_adam/README_en.md) | The final piece — this IS train.py | Easy | 200 |

Each step has its own subdirectory with `README_en.md` (English),
`README_ko.md` (Korean), and `scaffold.py` (the file you fill in).
After each step, run the script and check the loss — there are
explicit checkpoints in every README.

## Pedagogical narrative

**The whole point of the progression is that the only thing that
changes between a bigram count table and a real GPT is the model
class.** Dataset, tokenizer, training loop, inference loop — all
identical from Step 0. This collapses the seemingly enormous gap
between "I understand bigrams" and "I understand transformers" into
five concrete, reviewable changes.

The progression also doubles as a **practical autodiff lecture**: you
hand-derive backprop in Step 1, automate it in Step 2, then watch the
same machinery silently handle attention, RMSNorm, and a stack of
transformer blocks in Steps 3–5 without any extra code on your part.
This is the deepest reason autograd matters.

## Setup

No installation needed. The scripts are pure Python (3.8+) and
download the training data (`names.txt`, ~228 KB) on first run.

```bash
cd handout/step0_bigram_count
python scaffold.py    # downloads input.txt, runs the bigram model
```

Each step takes a few minutes to run on a laptop. Steps 3–5 are the
slowest because they build a Value computation graph for every
position of every sequence in pure Python.

## How to work with Copilot

This hands-on is designed for **VS Code + GitHub Copilot Agent mode**.
The workflow per step is:

1. **Open the step's `README_*.md`** alongside `scaffold.py` in VS Code.
2. **Read the "What changes" and the math** — don't skip; the prose is
   the lecture.
3. **Open Copilot Chat in Agent mode** and paste the prompts from the
   "Ask Copilot" section. Send them one TODO at a time.
4. **Read everything Copilot writes**, line by line, and convince
   yourself it matches the recipe in the comment block. Reject and
   re-prompt if it cuts corners or uses NumPy.
5. **Run the script** (`python scaffold.py`).
6. **Check the checkpoint** in the README.
7. **Commit** with a short message: `git commit -am "Step N done"`.

### Tips for good prompts

- **Be explicit about the constraint**: "no NumPy, pure Python lists,
  use the existing `Value` class".
- **Reference the file structure**: "in `scaffold.py`, fill in TODO 2
  inside `analytic_gradient`".
- **Quote the recipe**: paste a few lines of the comment block you
  want it to follow.
- **If Copilot is wrong, say WHY**: "this divides by `n_embd` but
  should divide by `head_dim`, fix it".

## Submission & grading

- Push your completed code to your repo in `sogang-physics/2026-ml-{name}`.
- Grading values **process** (incremental commits, one per step) over
  just the final result.
- A working Step 5 with all checkpoints passed = full credit.
- Bonus credit for going off-script: a 2-layer model, a different
  dataset (Shakespeare, your favorite physics paper), or a comparison
  plot of loss vs. step across all six steps.

## Reference

If you get truly stuck on a step, the complete working code is in
`../solution/step{0..5}_*.py`. **Don't peek until you have spent at
least 15 minutes trying yourself** — the lecture is the struggle.
