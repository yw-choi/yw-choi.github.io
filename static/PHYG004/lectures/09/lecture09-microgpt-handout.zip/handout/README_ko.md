# Lecture 09 — microGPT, 6 step으로 처음부터 만들기

> "Counting → MLP → autograd → attention → multi-head → Adam.
> 6개의 revision, 6개의 commit, 하나의 transformer."

이 hands-on에서 당신은 **완전한 GPT-2 스타일 transformer language model**
을 순수 Python으로 만든다 — NumPy도, PyTorch도, JAX도 없다. 6개의
step은 Karpathy의 [`build_microgpt.py`](https://gist.github.com/karpathy/561ac2de12a47cc06a23691e1be9543a)
gist의 6개 revision을 그대로 따라간다. 각 step에서 **바깥 골격은 동일**
하다 (dataset → tokenizer → forward → backward → update → sample);
"모델" 박스 안만 바뀐다.

## 6개의 step

| Step | 추가되는 것 | 난이도 | 대략 줄 수 |
|------|----------|:------:|---------:|
| [0 — Bigram counting](step0_bigram_count/README_ko.md) | Count table, NN 없음 | Trivial | 80 |
| [1 — MLP, 손 gradient](step1_mlp_manual/README_ko.md) | MLP, 손으로 유도한 backprop, gradient check | Medium | 180 |
| [2 — Autograd Value 클래스](step2_autograd/README_ko.md) | 50줄짜리 autograd engine | Medium | 160 |
| [3 — Attention + RMSNorm + residual](step3_attention/README_ko.md) | 첫 번째 진짜 transformer block | Hard | 190 |
| [4 — Multi-head + layer loop](step4_multihead/README_ko.md) | GPT-2와 동일한 architecture | Medium | 200 |
| [5 — Adam optimizer](step5_adam/README_ko.md) | 마지막 조각 — 이것이 train.py | Easy | 200 |

각 step은 자기 하위 디렉터리에 `README_en.md` (영어), `README_ko.md`
(한국어), `scaffold.py` (채워야 할 파일)를 가진다. 각 step 후에는
스크립트를 실행하고 손실을 확인 — 모든 README에 명시적인 체크포인트가
있다.

## 학습 흐름

**Progression의 핵심은: bigram count table과 진짜 GPT 사이에서 바뀌는
유일한 것은 모델 클래스라는 사실이다.** Dataset, tokenizer, training
loop, inference loop — Step 0부터 모두 동일하다. 이 사실 하나가 "bigram을
이해한다"와 "transformer를 이해한다" 사이의 거대해 보이는 격차를 5개의
구체적이고 검토 가능한 변화로 무너뜨린다.

이 progression은 동시에 **실용적인 autodiff 강의**다. Step 1에서
backprop을 손으로 유도하고, Step 2에서 자동화하고, Step 3–5에서 그
같은 기계가 attention, RMSNorm, transformer block stack까지 한 줄의
추가 코드 없이 조용히 처리하는 것을 본다. 이것이 autograd가 중요한
가장 깊은 이유다.

## 환경

설치 필요 없음. 스크립트는 순수 Python (3.8+)이고, 첫 실행 시 학습
데이터 (`names.txt`, ~228 KB)를 자동으로 다운로드한다.

```bash
cd handout/step0_bigram_count
python scaffold.py    # input.txt 다운로드 + bigram 모델 실행
```

각 step은 노트북에서 몇 분 걸린다. Step 3–5가 가장 느리다 — sequence의
모든 위치마다 Value computation graph를 순수 Python으로 만들기 때문.

## Copilot과 일하는 법

이 hands-on은 **VS Code + GitHub Copilot Agent mode** 용으로 설계되었다.
Step 별 작업 흐름:

1. **해당 step의 `README_*.md`**를 `scaffold.py`와 함께 VS Code에서 연다.
2. **"What changes"와 수식을 읽어라** — 건너뛰지 말 것; 본문 자체가
   강의다.
3. **Copilot Chat을 Agent mode로 열고** "Copilot 프롬프트" 섹션의
   문구를 붙여 넣어라. TODO 하나씩.
4. **Copilot이 작성한 모든 줄을 읽고**, 주석 블록의 레시피와 일치하는지
   확인하라. 지름길을 쓰거나 NumPy를 쓰면 거절하고 다시 요청.
5. **스크립트 실행** (`python scaffold.py`).
6. README의 **체크포인트 확인**.
7. 짧은 메시지로 **커밋**: `git commit -am "Step N done"`.

### 좋은 프롬프트의 팁

- **제약을 명시하라**: "NumPy 금지, 순수 Python list만, 기존 `Value`
  클래스 사용".
- **파일 구조를 참조하라**: "`scaffold.py`의 `analytic_gradient` 안의
  TODO 2를 채워줘".
- **레시피를 인용하라**: 따르길 원하는 주석 블록의 몇 줄을 직접 붙여 넣기.
- **틀렸으면 이유를 말하라**: "이건 `n_embd`로 나누는데 `head_dim`으로
  나눠야 해, 고쳐줘".

## 제출 & 평가

- 완성된 코드를 `sogang-physics/2026-ml-{name}` 저장소에 push.
- 평가는 단순한 결과보다 **과정** (step 별 incremental commit)을 중시한다.
- 모든 체크포인트를 통과한 작동하는 Step 5 = 만점.
- 추가 점수: script를 벗어나는 시도 — 2-layer 모델, 다른 데이터셋
  (Shakespeare, 좋아하는 물리 논문), 6개 step 전체의 step별 손실 비교 그래프.

## 참고

step에서 정말 막히면 완성된 코드는 `../solution/step{0..5}_*.py`에 있다.
**최소 15분 동안 직접 시도한 후에야 보라** — 강의의 본질은 그 고생이다.
