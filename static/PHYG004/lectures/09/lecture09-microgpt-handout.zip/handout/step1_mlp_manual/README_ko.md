# Step 1 — Bigram MLP, 손으로 미분한 Gradient

> "손으로 유도한 chain rule을 Step 2의 autograd가 대신 처리해 준다.
> 하지만 그 고통을 먼저 느껴봐야 한다."

## Step 0 → Step 1 변화

| Step 0 | Step 1 |
|--------|--------|
| Count table | 1-hidden-layer MLP |
| Closed-form (counting) | Gradient descent (SGD) |
| update 한 줄 | 손으로 유도한 backprop |
| 같은 손실, 일반화 안 됨 | 약간 더 나쁜 손실, 그러나 일반화 가능 |

이제 모델은

$$\text{token\_id} \xrightarrow{\text{wte lookup}} x \xrightarrow{W_1} \text{ReLU} \xrightarrow{W_2} \text{logits} \xrightarrow{\text{softmax}} \text{probs}$$

`wte`, `mlp_fc1`, `mlp_fc2` 세 개의 weight matrix를 가진다. Training
loop는 Step 0과 **동일**하지만, "update the model" 부분만 "gradient
계산 후 SGD step"으로 바뀐다.

## 왜 gradient를 두 가지 방법으로 계산?

우리는 gradient를 **두 가지 방법**으로 계산한다:

1. **Numerical (수치)** — 각 파라미터에 $\varepsilon$만큼 섭동을 주고
   forward를 다시 돌려 finite difference를 취한다. 자명하게 옳지만
   파라미터 하나당 forward 한 번이 필요해 $O(P)$. 파라미터 수가
   100 이상이면 학습용으로는 못 쓴다.
2. **Analytic (해석적)** — chain rule을 손으로 layer마다 유도한다.
   step당 forward 한 번 + backward 한 번, 즉 $O(1)$. 빠르지만 틀리기
   쉽다.

그리고 **gradient check**: 두 방법의 결과가 ~$10^{-5}$ 이내로 일치하는지
확인한다. 일치하지 않으면 analytic 쪽이 버그다. 이건 매우 중요한 습관이다:
**손으로 새 layer를 구현할 때마다 gradient check를 돌려라.**

## Layer 별 chain rule

위치 $(t, t{+}1)$에서의 per-position 손실은

$$L_t = -\log p_{t+1} = -\log \mathrm{softmax}(\text{logits})_{t+1}$$

고전적인 "softmax + cross-entropy 단축식"은

$$\frac{\partial L_t}{\partial \text{logits}_i} = p_i - \mathbb{1}[i = t{+}1].$$

여기서부터 `mlp_fc2`, ReLU, `mlp_fc1`, embedding lookup 순서로 거꾸로
전파한다:

$$\frac{\partial L}{\partial W_2[i,j]} = \delta^{(2)}_i \cdot h_j, \qquad \delta^{(1)} = (W_2^\top \delta^{(2)}) \odot \mathbb{1}[h_{\text{pre}} > 0]$$

$$\frac{\partial L}{\partial W_1[i,j]} = \delta^{(1)}_i \cdot x_j, \qquad \frac{\partial L}{\partial \text{wte}[\text{token\_id}, j]} \mathrel{+}= (W_1^\top \delta^{(1)})_j.$$

전체 레시피는 `scaffold.py`의 `analytic_gradient` 함수 안에 주석으로
적혀 있다.

## 채워야 할 부분

| # | 함수 | 무엇을 |
|---|----|------|
| 1a | `linear(x, w)` | 순수 Python으로 행렬–벡터 곱 |
| 1b | `softmax(logits)` | 수치 안정성을 위한 max 빼기 |
| 1c | `mlp(token_id)` | wte lookup → fc1 → ReLU → fc2 |
| 2 | `numerical_gradient` | 각 스칼라에 $+\varepsilon$ 섭동, finite-difference |
| 3 | `analytic_gradient` | per-position forward + 손으로 유도한 backward |

## Copilot 프롬프트

> "`scaffold.py`에서 TODO 1a, 1b, 1c를 채워줘: `linear(x, w)`는
> 순수 Python 행렬–벡터 곱, `softmax(logits)`는 max를 빼서 수치적으로
> 안정한 형태, `mlp(token_id)`는 `wte` lookup → `mlp_fc1` → ReLU →
> `mlp_fc2`로 구현해."

> "이제 TODO 2 `numerical_gradient`를 구현해줘: `state_dict`의 모든
> 스칼라 파라미터를 순회하면서 `+eps`만큼 섭동하고, forward loss를
> 다시 계산하고, 원래 값을 복구하고, `(loss_plus - loss) / eps`를
> flat list에 넣어줘."

> "TODO 3 `analytic_gradient`를 주석에 적힌 layer 별 레시피를 따라
> 구현해. 평균 loss에 대응하는 gradient가 되도록 `dlogits`를 `n`으로
> 나누는 걸 잊지 마."

Copilot이 작성한 후에는 **반드시 한 줄씩 읽어보고** chain rule과
일치하는지 확인하라. 그 다음 실행.

## 실행

```bash
python scaffold.py
```

## 체크포인트

- [ ] `gradient check` 줄에서 `max diff` < `1e-4`
- [ ] 첫 training step의 `loss`가 **3.6** 부근
- [ ] 마지막 step의 `loss`가 **2.4** 부근 (≈ Step 0 — 이렇게 고생했는데
      손실은 같다. *진짜 이득*은 모델이 미분 가능해졌다는 것이고,
      counting으로는 안 되는 architecture로 확장 가능해졌다는 것이다)
- [ ] 샘플링된 이름이 이름답게 보임
- [ ] 커밋: `git add -A && git commit -m "Step 1 done"`

## 회고

5,520개 파라미터의 MLP에 대해 backprop을 손으로 짠 셈이다. 이걸 1-layer
transformer에 대해 한다고 상상해 보라. GPT-2에 대해 한다고 상상해 보라.
우주의 열사 이전엔 못 끝낸다. 정확히 이 문제를 해결하는 것이 **autograd**
이고, 그게 Step 2다.

→ 다음: **Step 2**. `analytic_gradient` 함수 전체가 `loss.backward()`
한 줄로 사라진다.
