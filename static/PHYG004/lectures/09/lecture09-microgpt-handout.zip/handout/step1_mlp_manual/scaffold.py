"""
Step 1 — Bigram MLP trained by gradient descent (with manual gradients).

What changed from Step 0:
  - The "model" is no longer a count table; it is a 1-hidden-layer MLP:
        token_id → embedding → linear → relu → linear → logits → softmax → probs
  - Training is gradient descent (SGD), not counting.
  - You will derive backpropagation BY HAND (no autograd yet) and verify
    it against numerical differentiation.

The point is to feel how painful manual backprop is, so that the autograd
class in Step 2 feels like a real liberation.

Fill in the TODOs and run:
    python scaffold.py
"""

import os
import math
import random
random.seed(42)

# -----------------------------------------------------------------------------
# Dataset + Tokenizer (provided — same as Step 0)
# -----------------------------------------------------------------------------
if not os.path.exists('input.txt'):
    import urllib.request
    names_url = 'https://raw.githubusercontent.com/karpathy/makemore/refs/heads/master/names.txt'
    urllib.request.urlretrieve(names_url, 'input.txt')
docs = [l.strip() for l in open('input.txt').read().strip().split('\n') if l.strip()]
random.shuffle(docs)
print(f"num docs: {len(docs)}")

uchars = sorted(set(''.join(docs)))
BOS = len(uchars)
vocab_size = len(uchars) + 1
print(f"vocab size: {vocab_size}")

# -----------------------------------------------------------------------------
# Parameters (provided): three matrices initialised with N(0, 0.08^2)
# -----------------------------------------------------------------------------
n_embd = 16
matrix = lambda nout, nin: [[random.gauss(0, 0.08) for _ in range(nin)] for _ in range(nout)]
state_dict = {
    'wte':     matrix(vocab_size, n_embd),
    'mlp_fc1': matrix(4 * n_embd, n_embd),
    'mlp_fc2': matrix(vocab_size, 4 * n_embd),
}
params = [(row, j) for mat in state_dict.values() for row in mat for j in range(len(row))]
print(f"num params: {len(params)}")

# -----------------------------------------------------------------------------
# TODO 1 — building blocks
# -----------------------------------------------------------------------------
# Implement three small functions. They are pure Python — no NumPy.
#
#   linear(x, w):    x is a list of length nin, w is a list-of-lists of shape
#                    (nout, nin). Return a list of length nout where
#                    out[i] = sum_j w[i][j] * x[j].
#
#   softmax(logits): subtract the max for numerical stability, exponentiate,
#                    normalize. Return a list of probabilities.
#
#   mlp(token_id):   pick the embedding row state_dict['wte'][token_id],
#                    apply mlp_fc1, ReLU, then mlp_fc2, return logits.
def linear(x, w):
    raise NotImplementedError("TODO 1a: linear layer")

def softmax(logits):
    raise NotImplementedError("TODO 1b: numerically stable softmax")

def mlp(token_id):
    raise NotImplementedError("TODO 1c: 1-hidden-layer MLP forward pass")

# -----------------------------------------------------------------------------
# Forward pass over a sequence (provided once mlp/softmax exist)
# -----------------------------------------------------------------------------
def forward(tokens, n):
    losses = []
    for pos_id in range(n):
        token_id, target_id = tokens[pos_id], tokens[pos_id + 1]
        logits = mlp(token_id)
        probs = softmax(logits)
        losses.append(-math.log(probs[target_id]))
    return (1 / n) * sum(losses)

# -----------------------------------------------------------------------------
# TODO 2 — numerical gradient (slow but obviously correct)
# -----------------------------------------------------------------------------
# For each scalar parameter p, compute (forward(p + eps) - forward(p)) / eps.
# This is the textbook definition of a derivative. It's O(num_params * cost
# of forward pass), so it is unusably slow for training, but it is the
# ground truth we will check the analytic gradient against.
def numerical_gradient(tokens, n):
    loss = forward(tokens, n)
    eps = 1e-5
    grad = []
    # TODO: walk through every (row, j) in state_dict, perturb row[j] by +eps,
    # measure (loss_plus - loss) / eps, restore the original value, and append.
    raise NotImplementedError("TODO 2: finite-difference gradient")

# -----------------------------------------------------------------------------
# TODO 3 — analytic gradient (fast, derived by hand)
# -----------------------------------------------------------------------------
# Derive the chain rule for our 3-layer MLP and accumulate gradients into
# `grad` (same shape as state_dict). The hint is the layer-by-layer recipe:
#
#   forward (per position):
#       x      = wte[token_id]            # length n_embd
#       h_pre  = mlp_fc1 @ x              # length 4*n_embd
#       h      = relu(h_pre)              # length 4*n_embd
#       logits = mlp_fc2 @ h              # length vocab_size
#       probs  = softmax(logits)
#       loss_t = -log(probs[target])
#
#   backward (per position):
#       dlogits   = (probs - one_hot(target)) / n     # softmax+CE shortcut
#       grad['mlp_fc2'][i][j] += dlogits[i] * h[j]
#       dh[j]                 += sum_i mlp_fc2[i][j] * dlogits[i]
#       dh_pre[j]              = dh[j] * (h_pre[j] > 0)         # ReLU bw
#       grad['mlp_fc1'][i][j] += dh_pre[i] * x[j]
#       dx[j]                 += sum_i mlp_fc1[i][j] * dh_pre[i]
#       grad['wte'][token_id][j] += dx[j]
#
# Return (loss, grad_flat) where grad_flat is a flat list in the same order
# as `params` so the SGD update below works.
def analytic_gradient(tokens, n):
    grad = {k: [[0.0] * len(row) for row in mat] for k, mat in state_dict.items()}
    losses = []
    for pos_id in range(n):
        token_id, target_id = tokens[pos_id], tokens[pos_id + 1]
        # TODO: forward + per-position backward, accumulating into `grad`.
        pass
    raise NotImplementedError("TODO 3: hand-derived analytic gradient")

# -----------------------------------------------------------------------------
# Gradient check (provided): numerical and analytic gradients must agree
# -----------------------------------------------------------------------------
doc = docs[0]
tokens = [BOS] + [uchars.index(ch) for ch in doc] + [BOS]
n = len(tokens) - 1
loss_n, grad_n = numerical_gradient(tokens, n)
loss_a, grad_a = analytic_gradient(tokens, n)
grad_diff = max(abs(gn - ga) for gn, ga in zip(grad_n, grad_a))
print(f"gradient check | loss_n {loss_n:.6f} | loss_a {loss_a:.6f} | max diff {grad_diff:.8f}")
assert grad_diff < 1e-4, "Gradient check FAILED — your backward pass is buggy"

# -----------------------------------------------------------------------------
# Train the model (provided)
# -----------------------------------------------------------------------------
num_steps = 1000
learning_rate = 1.0
for step in range(num_steps):
    doc = docs[step % len(docs)]
    tokens = [BOS] + [uchars.index(ch) for ch in doc] + [BOS]
    n = len(tokens) - 1
    loss, grad = analytic_gradient(tokens, n)
    lr_t = learning_rate * (1 - step / num_steps)
    for i, (row, j) in enumerate(params):
        row[j] -= lr_t * grad[i]
    if step < 5 or step % 200 == 0:
        print(f"step {step+1:4d} / {num_steps:4d} | loss {loss:.4f}")

# -----------------------------------------------------------------------------
# Inference (provided)
# -----------------------------------------------------------------------------
temperature = 0.5
print("\n--- inference (new, hallucinated names) ---")
for sample_idx in range(20):
    token_id = BOS
    sample = []
    for _ in range(16):
        logits = mlp(token_id)
        probs = softmax([l / temperature for l in logits])
        token_id = random.choices(range(vocab_size), weights=probs)[0]
        if token_id == BOS:
            break
        sample.append(uchars[token_id])
    print(f"sample {sample_idx+1:2d}: {''.join(sample)}")
