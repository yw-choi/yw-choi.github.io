# Step 1 — Bigram MLP with Manual Gradients

> "The hand-derived chain rule is what autograd will replace in Step 2.
> But you have to feel the pain first."

## What changes from Step 0

| Step 0 | Step 1 |
|--------|--------|
| Count table | 1-hidden-layer MLP |
| Closed-form (counting) | Gradient descent (SGD) |
| 1 line of update | Hand-derived backprop |
| Same loss, no generalization | Slightly worse loss, but generalizes |

The model is now

$$\text{token\_id} \xrightarrow{\text{wte lookup}} x \xrightarrow{W_1} \text{ReLU} \xrightarrow{W_2} \text{logits} \xrightarrow{\text{softmax}} \text{probs}$$

with three weight matrices `wte`, `mlp_fc1`, `mlp_fc2`. The training
loop is **identical** to Step 0 except that "update the model" is now
"compute gradients and take an SGD step".

## Why two ways to compute the gradient?

We compute the gradient **two different ways**:

1. **Numerical** — perturb each parameter by $\varepsilon$, re-run the
   forward pass, take a finite difference. Trivially correct, but
   $O(P)$ forward passes per training step. Unusably slow for $P > 100$.
2. **Analytic** — derive the chain rule by hand, layer by layer. $O(1)$
   forward passes per step (one forward, one backward), but easy to get
   wrong.

Then we **gradient-check**: assert that the two agree to ~$10^{-5}$. If
they don't, the analytic version is buggy. This is a critical habit:
**every time you implement a new layer by hand, gradient-check it.**

## The chain rule, layer by layer

For a single position $(t, t{+}1)$ the per-position loss is

$$L_t = -\log p_{t+1} = -\log \mathrm{softmax}(\text{logits})_{t+1}$$

The classical "softmax + cross-entropy shortcut" gives

$$\frac{\partial L_t}{\partial \text{logits}_i} = p_i - \mathbb{1}[i = t{+}1].$$

From there, propagate backwards through `mlp_fc2`, ReLU, `mlp_fc1`, and
the embedding lookup:

$$\frac{\partial L}{\partial W_2[i,j]} = \delta^{(2)}_i \cdot h_j, \qquad \delta^{(1)} = (W_2^\top \delta^{(2)}) \odot \mathbb{1}[h_{\text{pre}} > 0]$$

$$\frac{\partial L}{\partial W_1[i,j]} = \delta^{(1)}_i \cdot x_j, \qquad \frac{\partial L}{\partial \text{wte}[\text{token\_id}, j]} \mathrel{+}= (W_1^\top \delta^{(1)})_j.$$

The full recipe is laid out as comments inside `analytic_gradient` in
`scaffold.py`.

## What you fill in

| # | Function | What to write |
|---|----------|---------------|
| 1a | `linear(x, w)` | matrix–vector multiply, pure Python |
| 1b | `softmax(logits)` | numerically stable softmax (subtract max) |
| 1c | `mlp(token_id)` | wte lookup → fc1 → ReLU → fc2 |
| 2 | `numerical_gradient` | perturb each scalar by $+\varepsilon$, finite-difference |
| 3 | `analytic_gradient` | per-position forward + hand-derived backward |

## Ask Copilot

> "In `scaffold.py`, fill in TODO 1a, 1b, 1c: implement `linear(x, w)`
> as a pure-Python matrix–vector multiply, `softmax(logits)` with the
> subtract-max trick for numerical stability, and `mlp(token_id)` as
> `wte` lookup → `mlp_fc1` → ReLU → `mlp_fc2`."

> "Now implement TODO 2 `numerical_gradient`: walk through every scalar
> parameter in `state_dict`, perturb it by `+eps`, recompute the
> forward loss, restore the value, and append `(loss_plus - loss) / eps`
> to a flat list."

> "Implement TODO 3 `analytic_gradient` following the layer-by-layer
> recipe in the comments. Don't forget to divide `dlogits` by `n` so
> that the gradient corresponds to the average loss."

After Copilot writes it, **read it line by line** and convince yourself
it matches the chain rule. Then run.

## Run

```bash
python scaffold.py
```

## Checkpoint

- [ ] `gradient check` line prints `max diff` < `1e-4`
- [ ] First training step prints `loss` around **3.6**
- [ ] Final training step prints `loss` around **2.4** (≈ Step 0 — yes,
      we did all this work for the same loss; the *win* is that the
      model is now differentiable and will scale to architectures where
      counting doesn't work)
- [ ] Sampled names look name-like
- [ ] Commit: `git add -A && git commit -m "Step 1 done"`

## Reflection

You just wrote backprop by hand for an MLP with 5,520 parameters. Now
imagine doing this for a 1-layer transformer. Imagine doing it for
GPT-2. You would not finish before the heat death of the universe. This
is exactly the problem that **autograd** solves — and that is Step 2.

→ Next: **Step 2**, where we replace the entire `analytic_gradient`
function with `loss.backward()`.
