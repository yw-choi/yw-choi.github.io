# Step 5 — Adam Optimizer (the final step)

> "Adam tracks per-parameter running averages of the gradient (momentum)
> and squared gradient (adaptive learning rate), so each parameter gets
> its own effective step size. This is the final piece."

## What changes from Step 4

**Only the optimizer.** The architecture, the dataset, the tokenizer,
the autograd engine, the forward pass, the loss — *everything* — is
identical to Step 4. We only swap SGD for Adam in the inner loop.

## Why Adam?

SGD treats every parameter the same: `p -= lr * g`. But different
parameters have very different gradient magnitudes — some weights see
large, frequent updates; others see tiny, rare ones. **Adam adapts the
step size per-parameter** by tracking two exponential moving averages:

$$m_i \leftarrow \beta_1 m_i + (1 - \beta_1) g_i \qquad \text{(first moment, "momentum")}$$

$$v_i \leftarrow \beta_2 v_i + (1 - \beta_2) g_i^2 \qquad \text{(second moment, "energy")}$$

Then it uses bias-corrected versions

$$\hat m_i = \frac{m_i}{1 - \beta_1^{t+1}}, \qquad \hat v_i = \frac{v_i}{1 - \beta_2^{t+1}}$$

(which compensate for the fact that $m$ and $v$ start at zero) to
take the update

$$p_i \leftarrow p_i - \mathrm{lr}_t \cdot \frac{\hat m_i}{\sqrt{\hat v_i} + \varepsilon}.$$

The intuition: $\hat m_i$ is the **direction** (smoothed gradient),
$\sqrt{\hat v_i}$ is the **scale** (RMS gradient magnitude), and
dividing the two gives an update that is "approximately one $\mathrm{lr}_t$
in size, no matter how big the raw gradient is". This is why Adam
works almost out of the box on a huge variety of architectures —
the per-parameter normalization removes most of the need for hand-tuning.

## What you fill in

| # | What |
|---|------|
| 1 | Initialize Adam state buffers `m` and `v` as zero lists |
| 2 | The Adam update step inside the training loop |

The final hyperparameters are already set: `lr=0.01`, `beta1=0.85`,
`beta2=0.99`, `eps=1e-8`. (Note `beta1=0.85` is slightly lower than the
classical 0.9 — Karpathy chose this for the small-data regime.)

## Ask Copilot

> "In `scaffold.py`, fill in TODO 1: initialize `m` and `v` as lists
> of `len(params)` zeros — these are Adam's first and second moment
> buffers, one entry per parameter."

> "Now fill in TODO 2: implement the Adam update inside the training
> loop. For each parameter index `i`, read `g = p.grad`, update
> `m[i] = beta1 * m[i] + (1 - beta1) * g`, update
> `v[i] = beta2 * v[i] + (1 - beta2) * g**2`, compute the
> bias-corrected `m_hat = m[i] / (1 - beta1**(step+1))` and
> `v_hat = v[i] / (1 - beta2**(step+1))`, then take the step
> `p.data -= lr_t * m_hat / (v_hat**0.5 + eps_adam)`. Don't forget
> to zero `p.grad` after the update."

## Run

```bash
python scaffold.py
```

Same speed as Step 4 — Adam is essentially free compared to the cost
of the forward/backward pass in pure Python.

## Checkpoint

- [ ] First step prints `loss` around **3.6**
- [ ] Loss drops **noticeably faster** in the first 50 steps than in
      Step 4 (this is the Adam advantage — the bias correction makes
      early steps aggressive)
- [ ] Final step prints `loss` around **2.0–2.1** — *better* than Step
      4's ~2.3 with the same architecture, same data, same number of
      steps. **This is the value of a good optimizer.**
- [ ] Sampled names are recognizably name-like — short, alternating,
      no nonsense
- [ ] Commit: `git add -A && git commit -m "Step 5 done — microGPT complete!"`

## You're done

Compare your finished `scaffold.py` to `solution/step5_adam.py` — they
should match line-for-line. This file IS `train.py` from Karpathy's
`microgpt`. **You just built a working transformer language model in
~200 lines of pure Python, from a count table to GPT-2, with no
third-party dependencies.**

Take a moment to scroll back and look at how short the whole thing is.
The full algorithmic content of a modern LLM — dataset loading,
tokenization, autograd, GPT-2 architecture, Adam, training loop,
inference — fits in a single screen if you arrange it in three columns.
Everything else in production LLM code (PyTorch, CUDA kernels, FlashAttention,
distributed training, mixed precision, weight tying, dropout, KV cache
optimization, ...) is **efficiency**, not algorithm.

## Where to go next

- **Scale it up**: replace the Python `Value` graph with PyTorch
  tensors; you can run the *exact same logic* on a GPU at thousands of
  tokens per second.
- **Replace the dataset**: try Shakespeare or your favorite physics
  paper. Adjust `block_size` accordingly.
- **Read the original**: <https://karpathy.ai/microgpt.html> or the
  Colab notebook linked from the gist.
- **Read `nanoGPT`**: <https://github.com/karpathy/nanoGPT> — same
  architecture, real data, real GPU.
