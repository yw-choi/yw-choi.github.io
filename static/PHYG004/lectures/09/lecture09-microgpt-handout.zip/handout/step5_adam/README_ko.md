# Step 5 — Adam Optimizer (마지막 step)

> "Adam은 파라미터마다 gradient (momentum)와 gradient² (adaptive
> learning rate)의 running average를 추적해서, 각 파라미터에 자기만의
> 유효 step size를 부여한다. 마지막 조각이다."

## Step 4 → Step 5 변화

**오직 optimizer만.** Architecture, dataset, tokenizer, autograd
engine, forward pass, loss — *모든 것*이 Step 4와 동일하다. 안쪽 loop
에서 SGD를 Adam으로 바꿀 뿐.

## Adam은 왜?

SGD는 모든 파라미터를 똑같이 다룬다: `p -= lr * g`. 하지만 파라미터마다
gradient 크기가 매우 다르다 — 어떤 weight는 크고 잦은 업데이트를 받고,
어떤 weight는 작고 드문 업데이트를 받는다. **Adam은 두 개의 지수
이동평균을 추적해서 step size를 파라미터별로 적응**시킨다:

$$m_i \leftarrow \beta_1 m_i + (1 - \beta_1) g_i \qquad \text{(first moment, "momentum")}$$

$$v_i \leftarrow \beta_2 v_i + (1 - \beta_2) g_i^2 \qquad \text{(second moment, "에너지")}$$

그다음 bias-correction을 적용한 버전

$$\hat m_i = \frac{m_i}{1 - \beta_1^{t+1}}, \qquad \hat v_i = \frac{v_i}{1 - \beta_2^{t+1}}$$

($m, v$가 0에서 시작하기 때문에 초반 step의 0 쪽 편향을 보정)으로
업데이트한다:

$$p_i \leftarrow p_i - \mathrm{lr}_t \cdot \frac{\hat m_i}{\sqrt{\hat v_i} + \varepsilon}.$$

직관: $\hat m_i$는 **방향** (smoothed gradient), $\sqrt{\hat v_i}$는
**스케일** (RMS gradient magnitude). 두 개를 나누면 결과가 "raw gradient
크기에 상관없이 대략 $\mathrm{lr}_t$ 정도"가 된다. Adam이 다양한
architecture에서 거의 그대로 잘 작동하는 이유 — 파라미터별 정규화가
hand-tuning의 필요를 대부분 없애기 때문.

## 채워야 할 부분

| # | 무엇을 |
|---|------|
| 1 | Adam state 버퍼 `m`, `v`를 0으로 채워진 list로 초기화 |
| 2 | training loop 안에서 Adam update step |

마지막 하이퍼파라미터는 이미 설정되어 있다: `lr=0.01`, `beta1=0.85`,
`beta2=0.99`, `eps=1e-8`. (`beta1=0.85`는 고전적인 0.9보다 약간 낮은데,
Karpathy가 작은 데이터 regime에서 고른 값이다.)

## Copilot 프롬프트

> "`scaffold.py`에서 TODO 1을 채워줘: `m`과 `v`를 `len(params)` 길이의
> 0으로 채워진 list로 초기화해 — Adam의 first/second moment 버퍼이고
> 파라미터당 한 entry."

> "TODO 2를 채워줘: training loop 안에서 Adam update를 구현해. 각
> 파라미터 index `i`에 대해 `g = p.grad`를 읽고,
> `m[i] = beta1 * m[i] + (1 - beta1) * g`,
> `v[i] = beta2 * v[i] + (1 - beta2) * g**2`,
> bias-corrected `m_hat = m[i] / (1 - beta1**(step+1))`과
> `v_hat = v[i] / (1 - beta2**(step+1))`을 계산한 다음
> `p.data -= lr_t * m_hat / (v_hat**0.5 + eps_adam)`로 step.
> 업데이트 후 `p.grad`를 0으로 두는 거 잊지 마."

## 실행

```bash
python scaffold.py
```

Step 4와 같은 속도. 순수 Python에서 forward/backward 비용에 비하면
Adam은 사실상 공짜다.

## 체크포인트

- [ ] 첫 step의 `loss`가 **3.6** 부근
- [ ] 처음 50 step에서 손실이 Step 4보다 **눈에 띄게 빨리** 떨어진다
      (Adam의 이점 — bias correction 덕분에 초반 step이 공격적)
- [ ] 마지막 step의 `loss`가 **2.0–2.1** — 같은 architecture, 같은
      데이터, 같은 step 수에서 Step 4의 ~2.3보다 *낮다*. **이것이
      좋은 optimizer의 가치다.**
- [ ] 샘플링된 이름이 알아볼 수 있게 이름답다 — 짧고, 자모음 교차,
      난센스 없음
- [ ] 커밋: `git add -A && git commit -m "Step 5 done — microGPT complete!"`

## 끝

완성된 `scaffold.py`를 `solution/step5_adam.py`와 비교해 보라 — 줄
단위로 같아야 한다. 이 파일이 바로 Karpathy의 `microgpt`의
`train.py`다. **당신은 외부 라이브러리 없이 ~200줄의 순수 Python으로,
count table에서 GPT-2까지, 작동하는 transformer language model을
직접 만들었다.**

위로 한참 스크롤해서 전체가 얼마나 짧은지 봐 보라. 현대 LLM의 알고리즘
내용 전체 — dataset 로딩, tokenization, autograd, GPT-2 architecture,
Adam, training loop, inference — 가 3 열로 배치하면 한 화면에 들어간다.
실제 production LLM 코드의 나머지 (PyTorch, CUDA kernel,
FlashAttention, distributed training, mixed precision, weight tying,
dropout, KV cache 최적화, ...)는 모두 **효율**이지 알고리즘이 아니다.

## 다음 단계

- **Scale up**: Python `Value` graph를 PyTorch tensor로 바꿔라; *완전히
  같은 로직*을 GPU에서 초당 수천 토큰으로 돌릴 수 있다.
- **데이터셋 교체**: Shakespeare나 좋아하는 물리 논문으로 시도. `block_size`도
  맞춰서 조절.
- **원본 읽기**: <https://karpathy.ai/microgpt.html> 또는 gist에 링크된
  Colab.
- **`nanoGPT` 읽기**: <https://github.com/karpathy/nanoGPT> — 같은
  architecture, 진짜 데이터, 진짜 GPU.
