# Step 2 — 50줄짜리 Autograd

> "이 `Value` 클래스를 이해하면, PyTorch를 이해한 것이다."

## Step 1 → Step 2 변화

MLP architecture는 **동일**. Training loop도 **거의 동일**. 바뀌는 것은
오직 *gradient를 계산하는 방식*이다:

| Step 1 | Step 2 |
|--------|--------|
| `loss, grad = analytic_gradient(...)` (손으로 짠 40+줄 chain rule) | `loss.backward()` (한 줄) |
| Layer 별 미분을 손으로 작성 | Operation 별 미분을 자동 기록 |
| 버그 하나면 조용한 실패 | 각 op이 자기 local 미분만 알면 되므로 보편적으로 정확 |

이것이 **reverse-mode automatic differentiation**의 본질이다: 각
elementary operation을 자기 입력에 대한 **local 미분**을 아는 노드로
표현하고, 그 graph를 거꾸로 순회해서 chain rule을 적용한다. 현대의 모든
deep learning framework (PyTorch, JAX, TensorFlow)는 이 아이디어 위에
tensor 지원, GPU kernel, graph 최적화를 얹은 것이다.

## `Value` 클래스가 동작하는 방식

`Value`는 하나의 스칼라를 감싸고 두 가지를 기억한다:

- **`_children`**: 이 값을 만드는 데 쓰인 `Value`들
- **`_local_grads`**: 각 child에 대한 $\partial \text{self} / \partial \text{child}$

예: `c = a * b`라고 쓰면 `__mul__`은

```python
Value(a.data * b.data, children=(a, b), local_grads=(b.data, a.data))
```

를 반환한다. $\partial(ab)/\partial a = b$ 이고 $\partial(ab)/\partial b = a$ 이기
때문이다.

`loss.backward()`를 호출하면:

1. **Topological sort**: `loss`를 root로 하는 graph를 정렬해서, 모든
   노드가 자기 children *뒤*에 오도록 한다.
2. **Seed**: `loss.grad = 1` (loss의 자기 자신에 대한 미분).
3. 정렬된 리스트를 **거꾸로** 순회. 각 노드 `v`에 대해 children에 gradient를
   밀어 넣는다:
   ```python
   for child, local in zip(v._children, v._local_grads):
       child.grad += local * v.grad
   ```

이것이 chain rule 전부다. 약 10줄.

## 채워야 할 부분

`Value` 클래스 안에 세 개의 TODO:

| # | 메서드 | 무엇을 |
|---|------|------|
| 1a | `__add__`, `__mul__` | 결과를 wrap하고 `_children`, `_local_grads` 기록 |
| 1b | `backward` | topo sort + 역순 traversal |

나머지 (`__pow__`, `log`, `exp`, `relu`, 편의용 reverse-op들, 모델,
학습 loop)는 모두 같은 템플릿이라서 **이미 제공**되어 있다.

## Copilot 프롬프트

> "`scaffold.py`에서 TODO 1a를 채워줘: `Value.__add__`와 `Value.__mul__`을
> 구현해. 각각 `other`가 Value가 아니면 `Value(other)`로 감싸고, 결과를
> `_children=(self, other)`, `_local_grads`에는 결과를 각 child로
> 미분한 값으로 채운 새 Value를 반환해. 덧셈은 둘 다 `1`, 곱셈은
> `other.data`와 `self.data`."

> "이제 TODO 1b: `Value.backward()`를 구현해. `self`를 root로 하는
> computation graph를 재귀적 DFS로 topological sort해 — 노드는 모든
> children을 방문한 *후*에 order에 추가. 그 다음 `self.grad = 1`로
> 두고 order를 역순으로 순회하면서, 각 노드 `v`에 대해 모든 child에
> `child.grad += local * v.grad`를 적용해."

## 실행

```bash
python scaffold.py
```

첫 training step이 **Step 1보다 눈에 띄게 느리다**. 모든 산술 연산이
이제 `Value`를 새로 할당하고 graph에 연결하기 때문이다. 순수 Python
autograd의 비용이고, 실제 framework가 C++/CUDA를 쓰는 이유다.

## 체크포인트

- [ ] 첫 training step의 `loss`가 **3.6** 부근
- [ ] 마지막 step의 `loss`가 **2.4** 부근 (Step 1과 같음)
- [ ] `torch`, `jax` 등 외부 autograd를 import하지 않음
- [ ] 코드가 Step 1보다 *훨씬* 짧음 (`analytic_gradient`가 사라짐)
- [ ] 샘플링된 이름이 이름답게 보임
- [ ] 커밋: `git add -A && git commit -m "Step 2 done"`

## Topo sort 검증

스크립트를 한 번 돌린 뒤 Python REPL에서 시도해 보라:

```python
a = Value(2.0)
b = Value(3.0)
c = a * b + a   # = 8.0
c.backward()
# dc/da = b + 1 = 4
# dc/db = a    = 2
print(a.grad, b.grad)   # 4.0 3.0
```

`backward()`가 맞다면 `4.0 3.0`을 출력한다. `3.0 2.0`이 나오면
`a`를 그 두 사용처보다 *나중*에 traverse하지 못한 것이다.

## 회고

50줄로 PyTorch의 핵심 아이디어를 직접 만들었다. 과장 아니다. PyTorch의
autograd engine은 본질적으로 이 `Value` class를 tensor로 일반화한 것이다.
지적인 내용은 같다.

→ 다음: **Step 3**. 드디어 모델이 transformer가 된다 — position
embedding, attention, RMSNorm, residual connection.
