# Step 2 — Autograd in 50 Lines

> "If you understand this `Value` class, you understand PyTorch."

## What changes from Step 1

The MLP architecture is **identical**. The training loop is **almost
identical**. The only thing that changes is *how the gradient is
computed*:

| Step 1 | Step 2 |
|--------|--------|
| `loss, grad = analytic_gradient(...)` (40+ lines of hand-derived chain rule) | `loss.backward()` (one line) |
| Per-layer derivatives written by hand | Per-operation derivatives recorded automatically |
| One bug = silent failure | Universally correct because each op only knows its own local derivative |

This is the essence of **reverse-mode automatic differentiation**: write
each elementary operation as a node that knows its **local derivative**
w.r.t. its inputs, then walk the graph backward to apply the chain
rule. Every modern deep learning framework (PyTorch, JAX, TensorFlow)
is built on this idea — they just add tensor support, GPU kernels, and
graph optimizations on top.

## How the `Value` class works

A `Value` wraps a single scalar and remembers two things:

- **`_children`**: the `Value`s that were combined to make this one
- **`_local_grads`**: $\partial \text{self} / \partial \text{child}$ for each child

For example, when you write `c = a * b`, the `__mul__` method returns

```python
Value(a.data * b.data, children=(a, b), local_grads=(b.data, a.data))
```

because $\partial(ab)/\partial a = b$ and $\partial(ab)/\partial b = a$.

When you call `loss.backward()`:

1. **Topological sort** the graph rooted at `loss` so that every node
   appears *after* its children.
2. **Seed**: `loss.grad = 1`  (the derivative of the loss w.r.t. itself).
3. Walk the topo list **in reverse**. For each node `v`, push its
   gradient onto each child:
   ```python
   for child, local in zip(v._children, v._local_grads):
       child.grad += local * v.grad
   ```

That's the entire chain rule. ~10 lines of code.

## What you fill in

Three TODOs, all inside the `Value` class:

| # | Method | What |
|---|--------|------|
| 1a | `__add__`, `__mul__` | wrap result, record `_children` and `_local_grads` |
| 1b | `backward` | topo sort + reverse traversal |

The rest of the file (`__pow__`, `log`, `exp`, `relu`, the convenience
reverse-ops, the model, the training loop) is **provided** because they
all reduce to the same template.

## Ask Copilot

> "In `scaffold.py`, fill in TODO 1a: implement `Value.__add__` and
> `Value.__mul__`. Each should wrap `other` in `Value(other)` if it
> isn't already a Value, then return a new `Value` whose `_children` is
> `(self, other)` and whose `_local_grads` records the derivative of
> the result w.r.t. each child. For addition both local derivatives
> are `1`; for multiplication they are `other.data` and `self.data`."

> "Now fill in TODO 1b: implement `Value.backward()`. Build a topological
> order of the computation graph rooted at `self` using a recursive DFS
> that appends a node to the order *after* visiting all its children.
> Then set `self.grad = 1` and iterate the order in reverse, for each
> node `v` doing `child.grad += local * v.grad` for each child."

## Run

```bash
python scaffold.py
```

The first training step will be **noticeably slower than Step 1**
because every arithmetic operation now allocates a `Value` and stitches
it into a graph. This is the cost of autograd in pure Python — and
exactly why real frameworks use C++/CUDA.

## Checkpoint

- [ ] First training step prints `loss` around **3.6**
- [ ] Final training step prints `loss` around **2.4** (same as Step 1)
- [ ] You did not import `torch`, `jax`, or any third-party autograd
- [ ] The code is *much* shorter than Step 1 (no `analytic_gradient`)
- [ ] Sampled names look name-like
- [ ] Commit: `git add -A && git commit -m "Step 2 done"`

## Sanity check on the topo sort

Try this in a Python REPL after running the script once:

```python
a = Value(2.0)
b = Value(3.0)
c = a * b + a  # = 8.0
c.backward()
# dc/da = b + 1 = 4
# dc/db = a    = 2
print(a.grad, b.grad)   # should print 4.0 3.0
```

If your `backward()` is correct, this prints `4.0 3.0`. If it prints
`3.0 2.0`, you forgot to traverse `a` *after* its multiple children.

## Reflection

You just built PyTorch's core idea in ~50 lines. This is not an
exaggeration. PyTorch's autograd engine is essentially this `Value`
class generalized to tensors. The intellectual content is the same.

→ Next: **Step 3**, where the model finally becomes a transformer —
position embeddings, attention, RMSNorm, residual connections.
