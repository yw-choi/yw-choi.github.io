"""
Step 2 — Same MLP, but now with autograd (the `Value` class).

What changed from Step 1:
  - The hand-derived `analytic_gradient` is GONE.
  - Every parameter and intermediate quantity is wrapped in a `Value`.
  - During the forward pass, each operation records its local derivatives.
  - `loss.backward()` walks the computation graph in reverse topological
    order and applies the chain rule for you.

The model architecture and the training loop are essentially the same as
Step 1. The only thing that changes is HOW gradients are computed.

Fill in the TODOs and run:
    python scaffold.py
"""

import os
import math
import random
random.seed(42)

# -----------------------------------------------------------------------------
# Dataset + Tokenizer (provided — same as Step 0/1)
# -----------------------------------------------------------------------------
if not os.path.exists('input.txt'):
    import urllib.request
    names_url = 'https://raw.githubusercontent.com/karpathy/makemore/refs/heads/master/names.txt'
    urllib.request.urlretrieve(names_url, 'input.txt')
docs = [l.strip() for l in open('input.txt').read().strip().split('\n') if l.strip()]
random.shuffle(docs)
print(f"num docs: {len(docs)}")

uchars = sorted(set(''.join(docs)))
BOS = len(uchars)
vocab_size = len(uchars) + 1
print(f"vocab size: {vocab_size}")

# -----------------------------------------------------------------------------
# TODO 1 — the autograd engine
# -----------------------------------------------------------------------------
# A `Value` wraps a scalar `data` and remembers:
#   - the children (Values) that were used to compute it
#   - the local derivative w.r.t. each child  (∂self/∂child)
#
# Then `backward()` does a topological sort of the graph rooted at `self`
# and propagates gradients in reverse: for each node v, for each (child,
# local) pair, child.grad += local * v.grad.
#
# That's it. That's autograd. ~50 lines.
class Value:
    __slots__ = ('data', 'grad', '_children', '_local_grads')

    def __init__(self, data, children=(), local_grads=()):
        self.data = data
        self.grad = 0
        self._children = children       # tuple of Value
        self._local_grads = local_grads # tuple of float, same length as _children

    # ---- TODO 1a: __add__, __mul__ ------------------------------------------
    # For addition c = a + b: ∂c/∂a = 1,         ∂c/∂b = 1
    # For multiply c = a * b: ∂c/∂a = b.data,    ∂c/∂b = a.data
    # Make sure to wrap a non-Value `other` in Value(other) so that
    # constants can be mixed with Values.
    def __add__(self, other):
        raise NotImplementedError("TODO 1a: implement Value addition")

    def __mul__(self, other):
        raise NotImplementedError("TODO 1a: implement Value multiplication")

    # ---- Provided: powers, log, exp, relu (the unary operations) -----------
    def __pow__(self, other): return Value(self.data**other, (self,), (other * self.data**(other-1),))
    def log(self):            return Value(math.log(self.data), (self,), (1/self.data,))
    def exp(self):            return Value(math.exp(self.data), (self,), (math.exp(self.data),))
    def relu(self):           return Value(max(0, self.data), (self,), (float(self.data > 0),))

    # ---- Provided: convenience reverse-ops so 1 - x, 2 * x etc. work -------
    def __neg__(self):       return self * -1
    def __radd__(self, o):   return self + o
    def __sub__(self, o):    return self + (-o)
    def __rsub__(self, o):   return o + (-self)
    def __rmul__(self, o):   return self * o
    def __truediv__(self, o):  return self * o**-1
    def __rtruediv__(self, o): return o * self**-1

    # ---- TODO 1b: backward --------------------------------------------------
    # 1. Build a topological order of the graph rooted at `self`. The standard
    #    trick is a DFS that pushes a node ONTO the topo list AFTER visiting
    #    all of its children.
    # 2. Set self.grad = 1  (the seed: dL/dL = 1).
    # 3. Iterate the topo list in REVERSE. For each node v, for each
    #    (child, local) in zip(v._children, v._local_grads):
    #            child.grad += local * v.grad
    # That's the chain rule, applied automatically.
    def backward(self):
        raise NotImplementedError("TODO 1b: implement reverse-mode backward()")

# -----------------------------------------------------------------------------
# Parameters: same shapes as Step 1, but each scalar is now a Value
# -----------------------------------------------------------------------------
n_embd = 16
matrix = lambda nout, nin: [[Value(random.gauss(0, 0.08)) for _ in range(nin)] for _ in range(nout)]
state_dict = {
    'wte':     matrix(vocab_size, n_embd),
    'mlp_fc1': matrix(4 * n_embd, n_embd),
    'mlp_fc2': matrix(vocab_size, 4 * n_embd),
}
params = [p for mat in state_dict.values() for row in mat for p in row]
print(f"num params: {len(params)}")

# -----------------------------------------------------------------------------
# Model (provided): notice it is essentially identical to Step 1, the only
# difference is that arithmetic on Value builds a computation graph.
# -----------------------------------------------------------------------------
def linear(x, w):
    return [sum(wi * xi for wi, xi in zip(wo, x)) for wo in w]

def softmax(logits):
    max_val = max(val.data for val in logits)
    exps = [(val - max_val).exp() for val in logits]
    total = sum(exps)
    return [e / total for e in exps]

def mlp(token_id):
    x = state_dict['wte'][token_id]
    x = linear(x, state_dict['mlp_fc1'])
    x = [xi.relu() for xi in x]
    logits = linear(x, state_dict['mlp_fc2'])
    return logits

# -----------------------------------------------------------------------------
# Training loop (provided)
# -----------------------------------------------------------------------------
num_steps = 1000
learning_rate = 1.0
for step in range(num_steps):
    doc = docs[step % len(docs)]
    tokens = [BOS] + [uchars.index(ch) for ch in doc] + [BOS]
    n = len(tokens) - 1

    # Forward pass — builds a Value graph
    losses = []
    for pos_id in range(n):
        token_id, target_id = tokens[pos_id], tokens[pos_id + 1]
        logits = mlp(token_id)
        probs = softmax(logits)
        losses.append(-probs[target_id].log())
    loss = (1 / n) * sum(losses)

    # Backward pass — autograd does all the work
    loss.backward()

    # SGD update + zero grads
    lr_t = learning_rate * (1 - step / num_steps)
    for p in params:
        p.data -= lr_t * p.grad
        p.grad = 0

    if step < 5 or step % 200 == 0:
        print(f"step {step+1:4d} / {num_steps:4d} | loss {loss.data:.4f}")

# -----------------------------------------------------------------------------
# Inference (provided)
# -----------------------------------------------------------------------------
temperature = 0.5
print("\n--- inference (new, hallucinated names) ---")
for sample_idx in range(20):
    token_id = BOS
    sample = []
    for _ in range(16):
        logits = mlp(token_id)
        probs = softmax([l / temperature for l in logits])
        token_id = random.choices(range(vocab_size), weights=[p.data for p in probs])[0]
        if token_id == BOS:
            break
        sample.append(uchars[token_id])
    print(f"sample {sample_idx+1:2d}: {''.join(sample)}")
