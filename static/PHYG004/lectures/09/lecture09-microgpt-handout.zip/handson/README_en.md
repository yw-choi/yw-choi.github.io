# microgpt hands-on: build a GPT in 6 steps

We follow Andrej Karpathy's `build_microgpt.py` progression. Each `trainN.py`
adds **one** new idea on top of the previous file. Read it, run it, then diff
it against the previous step.

> Pre-reading: [Karpathy's microgpt blog post](https://karpathy.ai/microgpt.html).
> Read it before Wednesday's class.

## Setup

```bash
cd handson
python --version    # 3.10+
python train0.py    # downloads input.txt (names dataset) on first run
```

No dependencies. Pure Python. CPU only. No PyTorch, no NumPy.

## The 6 steps

| File        | What it adds                                                          | Lines |
|-------------|-----------------------------------------------------------------------|-------|
| `train0.py` | Bigram **count table**. No neural net, no gradients.                  | ~80   |
| `train1.py` | **MLP** + **manual gradients** (numerical & analytic) + **SGD**.      | ~180  |
| `train2.py` | **Autograd** (`Value` class). Manual gradients are gone.              | ~160  |
| `train3.py` | **Position embeddings**, **single-head attention**, **rmsnorm**, **residual**. | ~190 |
| `train4.py` | **Multi-head attention** + **layer loop**. Full GPT architecture.     | ~200  |
| `train5.py` | **Adam optimizer**. This is `train.py`.                               | ~205  |

## How to work through each step

For each `trainN.py`:

1. **Read the docstring** at the top — it tells you exactly what's new.
2. **Read the code** end to end. Don't skip.
3. **Run it**: `python trainN.py`. Note the final loss and a few sample outputs.
4. **Diff against the previous step**: `diff trainN-1.py trainN.py | less`.
   The diff is the lesson.
5. **Predict before you run** the next step: what do you expect the diff to contain?

## Expected loss progression

Loss decreases as we add expressivity. Approximate values (yours may differ):

| Step | Final loss | What it means                                |
|------|-----------|-----------------------------------------------|
| `train0` | ~2.45 | Bigram count baseline (just P(next \| prev)) |
| `train1` | ~2.45 | MLP matches bigram counts (same info)         |
| `train2` | ~2.45 | Same model, different gradient mechanism      |
| `train3` | ~2.40 | Attention sees full prefix, not just prev     |
| `train4` | ~2.38 | Multi-head + deeper                           |
| `train5` | ~2.37 | Adam converges faster than SGD                |

The big jumps come from **architecture** (train2→train3) and **optimization**
(train4→train5). Counting and SGD-MLP are the same model class as a bigram, so
they hit the same floor.

## Diff exercises

Run these and read the output:

```bash
diff -u train0.py train1.py    # what does "make it differentiable" cost?
diff -u train1.py train2.py    # what does autograd save?
diff -u train2.py train3.py    # what is a transformer block, in code?
diff -u train3.py train4.py    # what does multi-head and a layer loop look like?
diff -u train4.py train5.py    # what does Adam add over SGD?
```

The `train2 → train3` diff is the largest and most important. That's where
the model becomes a GPT.

## Checkpoints

After each step, you should be able to answer:

- **train0**: Why does counting solve the bigram model exactly? Why doesn't it
  scale to longer context?
- **train1**: For one parameter, write the chain rule by hand and check it
  matches the analytic gradient in the code.
- **train2**: Pick one operation in `Value` (e.g. `__mul__`). What does its
  `_backward` do? Why?
- **train3**: Where in the code does causality (no peeking at the future) get
  enforced? What would break if you removed it?
- **train4**: How are the heads combined? Why split into heads instead of one
  big attention?
- **train5**: What two running averages does Adam keep per parameter? Why
  each one?

## Attribution

All `trainN.py` files are from Karpathy's gist, unmodified. See `ATTRIBUTION.md`.
