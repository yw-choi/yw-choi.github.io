# Attribution

The six `trainN.py` files in this directory are taken verbatim from Andrej
Karpathy's `build_microgpt.py` gist. They are used here for educational purposes
in PHYG004 (Sogang University, 2026 Spring).

- **Source gist**: https://gist.github.com/karpathy/561ac2de12a47cc06a23691e1be9543a
- **Author**: Andrej Karpathy
- **Companion blog post**: https://karpathy.ai/microgpt.html
- **Final single-file gist**: https://gist.github.com/karpathy/8627fe009c40f57531cb18360106ce95

Each `trainN.py` corresponds to one revision of the gist. The build_microgpt
gist is structured as a sequence of revisions you can step through; we have
captured each revision as a separate file so students can read, run, and diff
them in order.

| File       | Gist revision hash                          |
|------------|---------------------------------------------|
| `train0.py` | `9ac26e42deebd3373e51a418c33a84dac23fba2f` |
| `train1.py` | `ec80fc13fa1023c739ef60c9b145feb567771fc3` |
| `train2.py` | `6fbff742bfd2d9bea38c07c668c1f706f1bfaa53` |
| `train3.py` | `7532d658f53db95252ea3846d7c05c71768b15e9` |
| `train4.py` | `677f60ea5b2b5026d8ecffa26ff16c0a239cf2b6` |
| `train5.py` | `7d9f00faeaef1eebf8dfa8df162f86b9dafdff40` |

To view any revision in the original gist:
`https://gist.github.com/karpathy/561ac2de12a47cc06a23691e1be9543a/{hash}`

All credit for the code goes to Andrej Karpathy. No modifications have been
made to the source files.
