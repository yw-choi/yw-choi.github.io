# microgpt 실습: 6단계로 GPT 만들기

Andrej Karpathy의 `build_microgpt.py` 진행 순서를 그대로 따른다. 각 `trainN.py`는
바로 이전 파일 위에 **새로운 아이디어 하나**만 추가한다. 읽고, 실행하고, 이전 단계와
diff를 떠라.

> 사전 읽기: [Karpathy microgpt 블로그](https://karpathy.ai/microgpt.html).
> 수요일 수업 전에 읽고 와라.

## 환경

```bash
cd handson
python --version    # 3.10+
python train0.py    # 첫 실행 시 input.txt (names dataset) 자동 다운로드
```

의존성 없음. 순수 Python. CPU만. PyTorch도 NumPy도 안 씀.

## 6단계

| 파일        | 추가되는 것                                                              | 줄 수 |
|-------------|--------------------------------------------------------------------------|-------|
| `train0.py` | **Bigram count table**. 신경망 없음, 그래디언트 없음.                   | ~80   |
| `train1.py` | **MLP** + **수동 그래디언트** (수치/해석) + **SGD**.                     | ~180  |
| `train2.py` | **Autograd** (`Value` 클래스). 수동 그래디언트 사라짐.                   | ~160  |
| `train3.py` | **Position embedding**, **single-head attention**, **rmsnorm**, **residual**. | ~190 |
| `train4.py` | **Multi-head attention** + **layer loop**. 완전한 GPT 구조.              | ~200  |
| `train5.py` | **Adam optimizer**. 이게 `train.py`다.                                    | ~205  |

## 각 단계 진행 방법

각 `trainN.py`에 대해:

1. 파일 맨 위 **docstring을 읽어라**. 무엇이 새로운지 거기 다 적혀있다.
2. **코드를 처음부터 끝까지 읽어라**. 건너뛰지 마라.
3. **실행해라**: `python trainN.py`. 최종 loss와 샘플 출력 몇 개를 기록해라.
4. **이전 단계와 diff를 떠라**: `diff trainN-1.py trainN.py | less`.
   diff 자체가 그날의 강의 내용이다.
5. 다음 단계로 가기 전에 **diff를 예측해봐라**: 무엇이 추가될 것 같은가?

## Loss 변화

표현력이 늘어날수록 loss가 감소한다. 대략적인 값 (실행마다 다를 수 있음):

| 단계 | 최종 loss | 의미                                              |
|------|-----------|---------------------------------------------------|
| `train0` | ~2.45 | Bigram 카운트 베이스라인 (P(next \| prev)만 사용) |
| `train1` | ~2.45 | MLP가 bigram count와 같은 정보를 학습             |
| `train2` | ~2.45 | 모델은 동일, gradient 계산 방식만 변경             |
| `train3` | ~2.40 | Attention이 전체 prefix를 봄                       |
| `train4` | ~2.38 | Multi-head + 더 깊음                                |
| `train5` | ~2.37 | Adam이 SGD보다 빨리 수렴                            |

큰 점프는 **구조 변화** (train2→train3) 와 **최적화** (train4→train5) 에서 나온다.
Counting과 SGD-MLP는 같은 모델 클래스 (bigram) 이라 같은 바닥에 닿는다.

## Diff 연습

다음을 실행하고 출력을 읽어라:

```bash
diff -u train0.py train1.py    # "미분 가능하게 만든다"의 비용은?
diff -u train1.py train2.py    # autograd가 무엇을 절약해주는가?
diff -u train2.py train3.py    # transformer block을 코드로 보면?
diff -u train3.py train4.py    # multi-head와 layer loop는 어떻게 생겼나?
diff -u train4.py train5.py    # Adam이 SGD에 더하는 것은?
```

`train2 → train3` diff가 가장 크고 가장 중요하다. 모델이 GPT가 되는 지점이다.

## 체크포인트

각 단계 후 다음에 답할 수 있어야 한다:

- **train0**: 왜 counting이 bigram 모델의 exact solution인가? 왜 긴 context로
  확장이 안 되는가?
- **train1**: 파라미터 하나에 대해 chain rule을 손으로 써보고 코드의 analytic
  gradient와 일치하는지 확인해라.
- **train2**: `Value`의 연산 하나 (예: `__mul__`)를 골라라. `_backward`가
  무엇을 하는가? 왜 그렇게 하는가?
- **train3**: 코드 어디서 causality (미래를 못 보게 하는 것)가 강제되는가?
  그걸 빼면 무엇이 깨지는가?
- **train4**: head들은 어떻게 합쳐지는가? 왜 큰 attention 하나가 아니라 여러
  head로 나누는가?
- **train5**: Adam은 파라미터마다 어떤 두 가지 running average를 유지하는가?
  각각 왜 필요한가?

## 출처

모든 `trainN.py`는 Karpathy gist에서 그대로 가져온 것이다. `ATTRIBUTION.md` 참고.
