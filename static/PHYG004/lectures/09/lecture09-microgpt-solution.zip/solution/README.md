# microGPT — Solution (Instructor Reference)

Six progressive build steps that culminate in a full GPT transformer.
Extracted from the revisions of Karpathy's
[`build_microgpt.py`](https://gist.github.com/karpathy/561ac2de12a47cc06a23691e1be9543a)
gist (commit history → 6 revisions).

| File | Lines | What it adds |
|------|------:|--------------|
| `step0_bigram_count.py` |  79 | Bigram count table — no NN, no gradients (closed-form) |
| `step1_mlp_manual.py`   | 178 | MLP + manual gradients (numerical & analytic check) + SGD |
| `step2_autograd.py`     | 156 | `Value` autograd class — replaces hand-derived chain rule |
| `step3_attention.py`    | 191 | Position embeddings + single-head attention + RMSNorm + residuals |
| `step4_multihead.py`    | 200 | Multi-head attention + layer loop — full GPT architecture |
| `step5_adam.py`         | 203 | Adam optimizer — this is the final `train.py` |

Each script is **self-contained, dependency-free** (pure Python stdlib),
and downloads its own training data (`names.txt`) on first run.

## Run

```bash
python step0_bigram_count.py
python step1_mlp_manual.py
...
python step5_adam.py
```

Each run takes a couple of minutes (Step 4 and Step 5 are slowest because
they actually build a real transformer in pure Python). Final loss should
go from ~3.3 (Step 0) down to ~2.3 (Step 5), and inference samples should
look increasingly name-like.

## Pedagogical narrative

The point of the progression is that **the only thing that changes between
the bigram count table and a real GPT is the model class** — dataset,
tokenizer, training loop and inference loop are fixed from Step 0.

- **Step 0 → 1**: replace closed-form counting with gradient descent on a
  differentiable parameterization (MLP). Show that numerical and analytic
  gradients agree.
- **Step 1 → 2**: replace hand-derived backprop with autograd. The MLP
  doesn't change; only the *mechanism* for computing gradients changes.
- **Step 2 → 3**: change the model from "bigram MLP" to "transformer block"
  — attention lets each token see the whole prefix instead of just itself.
- **Step 3 → 4**: split attention into multiple heads, wrap the block in a
  `for` loop over `n_layer`. The architecture is now identical to GPT-2.
- **Step 4 → 5**: replace SGD with Adam. The model is unchanged; the only
  difference is per-parameter momentum and adaptive step size.

## Source

All six files are verbatim copies of the corresponding revision of
Karpathy's gist (Feb 13 2026). Docstrings and comments are preserved
because they are pedagogically excellent and the point of this lecture
is to read them carefully.
